const importAll =  (r) =>{
    let files = {};
    r.keys().map((item, index) => { return files[item.replace('./', '')] = r(item); });
    return files;
 }
 
 export const audioUrl = importAll(require.context('./assets/audio', true, /\.(mp3)$/));
const Images = importAll(require.context('./assets/images', true, /\.(png|jpe?g|svg)$/));

export default Images;
import {audioUrl} from './preload';
let narrationAudio = new Audio();
let effectAudio = new Audio();
let extraAudio = new Audio();

let audioPlayer=(callback)=>{
    narrationAudio.addEventListener('ended',function(){ self.onEndedNarration() })
    let self={};
    self.play=(src,isPlayedOnceCheckNeeded)=>{
        self.changeSrc(src);
        narrationAudio.load();
        
       if((window.App.state.isVoiceEnabled && (window.App.state.narrations[src].playedOnce === 'undefined' || !window.App.state.narrations[src].playedOnce))||isPlayedOnceCheckNeeded){
           window.App.state.narrations[src].playedOnce = true;
          let playPromise = narrationAudio.play();
          if (playPromise !== undefined) {
            playPromise.then(function() {}).catch(function() {});
         }
       }
        
    }
    self.pause=()=>{
        if (!isNaN(narrationAudio.duration)) {
            narrationAudio.currentTime = 0;
        }
        narrationAudio.pause();
    }
    self.extraAudioPause=()=>{
        if (!isNaN(extraAudio.duration)) {
            extraAudio.currentTime = 0;
        }
        extraAudio.pause();
    }
    self.changeSrc=(src)=>{
        narrationAudio.src = audioUrl[window.App.state.narrations[src].audio];
    }
    self.onEndedNarration=()=>{
        if(typeof callback == 'function'){
            callback();
        }
       
    }

    self.effectAudio = (src)=>{
        self.effectChangeSrc(src);
        effectAudio.load();
        if(window.App.state.isSoundEnabled){
            let playPromise = effectAudio.play();
            if (playPromise !== undefined) {
            playPromise.then(function() {}).catch(function() {});
         }
        }
    }
    self.extraAudio = (src)=>{
        self.extraChangeSrc(src);
        extraAudio.load();
        if(window.App.state.isVoiceEnabled){
            let playPromise = extraAudio.play();
            if (playPromise !== undefined) {
            playPromise.then(function() {}).catch(function() {});
         }
        }
    }
    self.effectChangeSrc = (src)=>{
        effectAudio.src = audioUrl[src];
    }
    self.extraChangeSrc = (src)=>{
        extraAudio.src = audioUrl[src];
    }
    self.btnClk = ()=>{
        self.effectAudio('button_click.mp3');
    }

    return self;

}

export default audioPlayer;
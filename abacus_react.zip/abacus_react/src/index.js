import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from "react-redux";
import store from "./redux/Store/index";
import { soundChange,voiceChange } from "./redux/Actions/action";
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import $ from 'jquery';

store.subscribe(() => console.log('Look ma, Redux!!'));
store.dispatch( soundChange({ name: 'React Redux Tutorial for Beginners', id: 1 }) )
store.dispatch( voiceChange({ name: 'React Redux Tutorial for Beginners', id: 2 }) )
store.dispatch( voiceChange({ name: 'React Redux Tutorial for Beginners', id: 2 }) )
console.log(store.getState());
ReactDOM.render(<Provider store={store}> 
                <App ref={(App)=> window.App = App}/>
                </Provider>, 
                document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();

$("body").on("mousedown click touchstart", "*", function(e) {
    if (($(this).is(":focus") || $(this).is(e.target)) && $(this).css("outline-style") == "none") {
            $(this).css("outline", "none").on("blur", function() {
            $(this).off("blur").css("outline", "");
        });
    }
    
});

$("body").on('focus','*',function(e){
    console.log(this)
    var attr = $(this).attr('tabindex');
    var tagName = $(this).prop('tagName');
    if((tagName != 'BUTTON' && tagName !='INPUT') && (typeof attr == typeof undefined || attr < 0)){			
       
        $(this).css("outline", "none");
    }
    if((tagName != 'BUTTON' && tagName !='INPUT') && (typeof attr != typeof undefined && attr > -1)){
        $(this).css("outline", "black dotted 3px");
    }
   
   
});
$("body").on('blur','*',function(e){
    var attr = $(this).attr('tabindex');
    var tagName = $(this).prop('tagName');
    if((tagName != 'BUTTON' && tagName !='INPUT') && (typeof attr == typeof undefined || attr >= -1)){
        $(this).css("outline", "none");
    }
   
});

var browserPrefixes = ['moz', 'ms', 'o', 'webkit'],
			isVisible = true; // internal flag, defaults to true

		// get the correct attribute name
		function getHiddenPropertyName(prefix) {
			return (prefix ? prefix + 'Hidden' : 'hidden');
		}

		// get the correct event name
		function getVisibilityEvent(prefix) {
			return (prefix ? prefix : '') + 'visibilitychange';
		}

		// get current browser vendor prefix
		function getBrowserPrefix() {
			for (var i = 0; i < browserPrefixes.length; i++) {
				if(getHiddenPropertyName(browserPrefixes[i]) in document) {
				// return vendor prefix
				return browserPrefixes[i];
				}
		}

		// no vendor prefix needed
		return null;
		}

		// bind and handle events
		var browserPrefix = getBrowserPrefix(),
			hiddenPropertyName = getHiddenPropertyName(browserPrefix),
			visibilityEventName = getVisibilityEvent(browserPrefix);

		function onVisible() {
			// prevent double execution
			if(isVisible) {
				return;
			}
			$('*:focus').not('#game-btn,.effect-btn').blur();
				if ("activeElement" in document){
					if($('*:focus').not('#game-btn,.effect-btn').length != 0){
						document.activeElement.blur();
					}
			}
			// change flag value
			isVisible = true;
		}

		function onHidden() {
			// prevent double execution
			if(!isVisible) {
				return;
			}
			if ("activeElement" in document){
				document.activeElement.blur();
			}

			// change flag value
			isVisible = false;
		}

		function handleVisibilityChange(forcedFlag) {
		// forcedFlag is a boolean when this event handler is triggered by a
		// focus or blur eventotherwise it's an Event object
		if(typeof forcedFlag === "boolean") {
			if(forcedFlag) {
			return onVisible();
			}

			return onHidden();
		}

		if(document[hiddenPropertyName]) {
			return onHidden();
		}

			return onVisible();
		}

		document.addEventListener(visibilityEventName, handleVisibilityChange, false);

		// extra event listeners for better behaviour
		document.addEventListener('focus', function() {
			handleVisibilityChange(true);
		}, false);

		document.addEventListener('blur', function() {
			handleVisibilityChange(false);
		}, false);

		window.addEventListener('focus', function() {
			handleVisibilityChange(true);
		}, false);

		window.addEventListener('blur', function() {
			handleVisibilityChange(false);
		}, false);
	
import React, { Component } from "react";
import Howtoplay from './helpCreate';
import audioPlayer from '../../audio';
import {audioUrl} from '../../preload.js';
import $ from "jquery";
import './HowtoPlayScreen.css';

const importAll =  (r) =>{
    let files = {};
    r.keys().map((item, index) => { return files[item.replace('./', '')] = r(item); });
    return files;
 }
 var lib, images, createjs, ss, AdobeAn;
 
 var frSound, currSound,  isPrevDoubleClicked,isNextDoubleClicked,screen,canvasTimeLine,chapterFrames,playSound,currPos = 0;
 canvasTimeLine = window.canvasTimeLine;
export default class HowtoPlayScreen extends Component{
    constructor(props){
        super(props)
        this.hideSoundVoiceBtn.bind(this);
    }
    hideSoundVoiceBtn(value){
        let header = this.props.data;
         header.sound.style.display=value;
         header.voice.style.display=value;
    }
    updateActivity(){
        this.hideSoundVoiceBtn('block');
        this.props.pageSelection();
    }
    componentDidMount() {
        this.audio = audioPlayer();
        screen = 'howtoplay';
        Howtoplay(lib = window.lib||{}, images = window.images||{}, createjs = window.createjs||{}, ss = window.ss||{}, AdobeAn = AdobeAn||{});
        // const jsUrl = importAll(require.context('./help', false, /\.(js)$/));
       //  const js = importAll(require.context('./', false, /\.(js)$/))
        this.hideSoundVoiceBtn('none');
        


        $(document).ready(function() {
            var ishelpDevice;
                ishelpDevice = (navigator.userAgent.indexOf("iPad") != -1 || navigator.userAgent.indexOf("Android") != -1 || navigator.userAgent.indexOf("Macintosh") != -1) ? true : false;
            //alert(ishelpDevice)
            function addDeviceClass(){
                if(ishelpDevice){
                    $('.page').addClass('helpdevice')
                }
            }
            addDeviceClass();
            //chapterFrames
            var audioElement = document.createElement('audio');
            audioElement.setAttribute('src', audioUrl['button-click.mp3']);
            var audioElement1 = document.createElement('audio');
            audioElement1.setAttribute('src', audioUrl['button-click.mp3']);
            var touchtime = 0;
            $("#prev").attr("disabled", true);
            $("#next").attr("disabled", true);
            $("#pause").attr('tabindex',-1);
            //$("#pause").hide();
            $("#pause").css('opacity',0);
            $("#pause").css('pointer-events','none');


            document.getElementById("instCont").style.display = 'none';
            window.initButtons('hidden');
            window.init(AdobeAn);   
        
            $("body").on("click",'#pause', function(e) {
                canvasTimeLine = window.canvasTimeLine;
                audioElement.play();
                //$("#pause").hide();
                //$("#play").show();
                $("#pause").css('opacity',0);
                $("#pause").attr('tabindex',-1);
                $("#play").attr('tabindex',0);
                $("#pause").css('pointer-events','none');
                $("#play").css('opacity',1);
                $("#play").css('pointer-events','auto');
                $("#play").find("img").attr('src', "../assets/images/help/play_btn_up.png");
                frSound = window.frSound;
                
                if(frSound){
                    currPos = frSound.position;
                    frSound.stop();
                }
                
                canvasTimeLine.stop();
               
                if(e.clientX == 0){
                    $('#play').focus()
                }
            });
        
            $("body").on("click",'#play', function(e) {
                canvasTimeLine = window.canvasTimeLine;
                
                $("#video-alert").html('<span class="sr-only">The alternate of video is provided within help-keyboard instructions</span>');
                audioElement.play();
                $("#prev").attr("disabled", false);
                $("#prev").addClass("enabled");
                $("#next").attr("disabled", false);
                $("#next").addClass("enabled");
                $("#pause").attr('tabindex',0);
                $("#play").attr('tabindex',-1);
                $("#next").find("img").attr('src', "../assets/images/help/forward_btn_up.png");
                $("#prev").find("img").attr('src', "../assets/images/help/replay_btn_up.png");
                if (canvasTimeLine.currentFrame >= canvasTimeLine.totalFrames-1) {
                    canvasTimeLine.gotoAndPlay(1);
                } else {
                    canvasTimeLine.play();
                }
                $("#pause").find("img").attr('src', "../assets/images/help/pause_btn_up.png");
                //$("#pause").show();
                //$("#play").hide();
                $("#pause").css('opacity',1);
                $("#pause").css('pointer-events','auto');
                $("#play").css('opacity',0);
                $("#play").css('pointer-events','none');
                frSound = window.frSound;
                playSound = window.playSound;
                currSound = window.currSound;
                if(currPos != 0) {
                    frSound = playSound(currSound, 0, currPos);
                }
                prevChapter = false;
                if(e.clientX ==0){
                    $("#pause").focus();
                }
                
            });
            $("#pause").find("img").attr('src', "../assets/images/help/pause_btn_up.png");
                $("#pause").on('mouseenter',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/pause_btn_over.png");
                    }).on('mouseleave',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/pause_btn_up.png");
                    }).on('mousedown',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/pause_btn_down.png");
                    });
        
                $("#play").find("img").attr('src', "../assets/images/help/play_btn_up.png");
                $("#play").on('mouseenter',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/play_btn_over.png");
                    }).on('mouseleave',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/play_btn_up.png");
                    }).on('mousedown',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/play_btn_down.png");
                    });
        
        
        
                $("#next").find("img").attr('src', "../assets/images/help/forward_btn_inactive.png");
                $("#next").on('mouseenter',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/forward_btn_over.png");
                    }).on('mouseleave',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/forward_btn_up.png");
                    }).on('mousedown',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/forward_btn_down.png");
                    });
        
                $("#prev").find("img").attr('src', "../assets/images/help/replay_btn_inactive.png");
                $("#prev").on('mouseenter',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/replay_btn_over.png");
                    }).on('mouseleave',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/replay_btn_up.png");
                    }).on('mousedown',function() {
                            var elem = $(this).find("img")[0];
                            $(elem).attr('src', "../assets/images/help/replay_btn_down.png");
                    });
            function singleClick(){
                //audioElement.play();
                setTimeout(function() {
                    if(!isPrevDoubleClicked) {
                        //$("#pause").show();
                        //$("#play").hide();
                        $("#pause").css('opacity',1);
                        $("#play").css('opacity',0);
                        $("#pause").attr('tabindex',0);
                        $("#play").attr('tabindex',-1);
                        $("#pause").css('pointer-events','auto');
                        $("#play").css('pointer-events','none');
                        frSound = window.frSound;
                        if(frSound)
                        frSound.stop();
                    gotoChapter(getChapter());
                    prevChapter = false;
                    }
                }, 500);
        
            }
        
        
            function doubleClick(){
                isPrevDoubleClicked = true;
                setTimeout(function() {
                    isPrevDoubleClicked = false;
                }, 600);
                //$("#pause").show();
                //$("#play").hide();
                $("#pause").css('opacity',1);
                $("#play").css('opacity',0);
                $("#pause").attr('tabindex',0);
                $("#play").attr('tabindex',-1);
                $("#pause").css('pointer-events','auto');
                $("#play").css('pointer-events','none');
                frSound = window.frSound;
                if(frSound)
                frSound.stop();
                var i = getChapter();
                if(i >= 1) {i--;}
                gotoChapter(i);
                prevChapter = false;
            }
        
            var prevChapter = false;
            function nextSingleClick(){
                //audioElement.play();
                setTimeout(function() {
                    if(!isNextDoubleClicked) {
                        //$("#pause").show();
                        //$("#play").hide();
                        $("#pause").css('opacity',1);
                        $("#play").css('opacity',0);
                        $("#pause").attr('tabindex',0);
                        $("#play").attr('tabindex',-1);
                        $("#pause").css('pointer-events','auto');
                        $("#play").css('pointer-events','none');
                        var chap = getChapter()+1;
                        /*Added*/				
                        frSound = window.frSound;
                            if(!prevChapter && frSound) {
                              frSound.stop();				
                              gotoChapter(chap);				  
                            }
                            if(chap == chapterFrames.length-1) {prevChapter = true;}
                        /*Added*/	
                    }
                }, 500);
        
            }
        
        
            function nextDoubleClick(){
                isNextDoubleClicked = true;
                setTimeout(function() {
                    isNextDoubleClicked = false;
                }, 600);
                //$("#pause").show();
                //$("#play").hide();
                $("#pause").css('opacity',1);
                $("#play").css('opacity',0);
                $("#pause").css('pointer-events','auto');
                $("#play").css('pointer-events','none');
                var i = getChapter();
                frSound = window.frSound;
                if(i > 1) {i--;}
                var chap = i+2;
                // if(i >= 1) {i++;}
                /*Added*/
                    if(!prevChapter && frSound) {
                        
                         frSound.stop();					
                         gotoChapter(chap);				  
                     }
                    if(chap == chapterFrames.length-1) {prevChapter = true;}	
                /*Added*/
            }
        
            $("body").on("mousedown touchstart", "*", function(e) {
                if (($(this).is(":focus") || $(this).is(e.target)) && $(this).css("outline-style") == "none") {
                    $(this).css("outline", "none").on("blur", function() {
                        $(this).off("blur").css("outline", "");
                    });
                }
            });
            $("body").on("click",'#prev', function() {
                if (touchtime == 0) {
                    audioElement.play();
                    singleClick()
                    touchtime = new Date().getTime();
                } else {
                    // compare first click to this click and see if they occurred within double click threshold
                    if (((new Date().getTime()) - touchtime) < 800) {
                        // double click occurred
                       audioElement1.play();
                       setTimeout(function(){ audioElement.play();}, 200);
                        doubleClick();
                        touchtime = 0;
                    } else {
                        // not a double click so set as a new first click
                        audioElement.play();
                        singleClick()
                        touchtime = new Date().getTime();
                    }
                }
            });
        
            $("body").on("click",'#next', function() {
                if (touchtime == 0) {
                    audioElement.play();
                        nextSingleClick();
                        touchtime = new Date().getTime();
                } else {
                        // compare first click to this click and see if they occurred within double click threshold
                        if (((new Date().getTime()) - touchtime) < 800) {
                                // double click occurred
                     audioElement1.play();
                     setTimeout(function(){ audioElement.play();}, 200);
                    nextDoubleClick();
                                touchtime = 0;
                        } else {
                                // not a double click so set as a new first click
                    audioElement.play();
                    nextSingleClick();
                                touchtime = new Date().getTime();
                        }
                }
            });
        
            function gotoChapter(n) {
                try {
                    canvasTimeLine.gotoAndPlay(chapterFrames[n].start);
                } catch (e) {	}
            }
        
            function getChapter() {
                chapterFrames = window.chapterFrames;
                for (var i = 0; i < chapterFrames.length; i++) {
                    if (canvasTimeLine.currentFrame > chapterFrames[i].start && canvasTimeLine.currentFrame < chapterFrames[i].end) {
                        return i;
                    }
                }
            }
        
        /******************************************************************/
            var shifted;
            var keyPressed;
            $(document).on('keyup keydown', function(e) {
                shifted = e.shiftKey;
                keyPressed = e.keyCode;
                setTimeout(function(){
                    keyPressed = "";
                },100);
            });
        
            $(".help-clicked").hide();
            $(".help_button").on("click", function(e) {
                audioElement.play();
                //$(".page").attr("aria-hidden", true);
                $(".dis-ass").attr("aria-hidden", true);
                $(".dis-ass").attr("tabindex",-1);
                var instContEle = document.getElementById("instCont").style.visibility = "visible";
                document.getElementById("game-btn").style.visibility = "hidden";
                document.getElementById("rootCloseBtn").setAttribute("aria-hidden", true);
                document.getElementById("rootCloseBtn").setAttribute("tabindex", -1);
                $(".help-clicked").show();
                $("#game-button").css("display","block");
                if(keyPressed) {
                    setTimeout(function(){
                        $("#helpbox").focus();
                    },100);
        
                }
            });
        
        $(".help-box").on('blur',function(e){
            if(shifted) {
                $(".no_btn").focus();
            }})
        
        var mouseClicked=true;
        $(".no_btn").on("mousedown",function(){
            mouseClicked=false;
        });
        
        $("body").on("click",'.no_btn',function(event){
            if(screen == 'howtoplay'){
                audioElement.play();
                //$(".page").attr("aria-hidden", false);
                $(".dis-ass").attr("aria-hidden", false);
                var instContEle = document.getElementById("instCont").style.visibility = "hidden";
                document.getElementById("game-button").style.visibility = "visible";
                $(".dis-ass").attr("tabindex",0);
                document.getElementById("rootCloseBtn").setAttribute("aria-hidden", false);
                document.getElementById("rootCloseBtn").setAttribute("tabindex", 0);
            // $("#game-button").css("display","none");
                $(".help-clicked").hide();
                // $(this).css("outline", "none");
                // $(this).find('span').css("outline", "none");
                if(mouseClicked){
                    $(".help_button").focus();
                }
            
                mouseClicked = true;
        }
        });
        
        });



       
    }
   componentWillUnmount() {
       if(window.frSound){
         window.frSound.stop();
         canvasTimeLine.stop();
       }
       screen = 'other';
       createjs.Sound.removeAllSounds();
        
   }
    render(){
         return (<div style={{margin:"0px",overflow:"hidden"}} className="help-container page">
        <h1 className="sr-only">Help: How to play the game</h1>
        <div id="animation_container">
            <canvas id="canvas" width="1024" height="660"></canvas>
            <div id="dom_overlay_container">
            </div>
        </div>
    
        <div className="loader"><span>Loading Graphics</span></div>
        <button className="help_button dis-ass" id="helpInst" ><div>Help</div>
                <span className="sr-only">Keyboard Instructions. It has a popup</span>
            </button>
            <div className="help-clicked" id="instCont">
                <div className="overlay"></div>
                <div>
                    <div className="help-box" id="helpbox" role="dialog" aria-describedby="dialogContent">
    
                        <div id="dialogContent" style={{overflowY: "scroll"}}>
                            <h1>Keyboard instructions</h1>	
                            <ul>
                               <li>Press the Tab key to select a number.</li>
                               <li>To move the current number to an answer circle, press Alt and 5, then use the Up and Down Arrow keys to select a location, then press Enter.</li>
                               <li>To move a number from an answer circle, press Alt and 5, then use the Up and Down Arrow keys to select a new location, then press Enter.</li>
                            </ul>						
                            <h1>How to play</h1>
                            <ul>
                               <li>You need to move numbers into the circles so that numbers that are next to each other have a difference of 11.</li>
                               <li>One of you can move the blue numbers, and the other the green.</li>
                               <li>Talk about where to put the numbers.</li>
                               <li>When you have finished, you need to arrange the numbers in a different way.</li>						   
                            </ul>
                            <h1 className="sr-only"> Help: How to play the game</h1>						
                        </div>
                        <button className="no_btn"><div>Close Instruction</div></button>
                        
                    </div>
                </div>
            </div>
        <button id="play" className="dis-ass" aria-label="Play instructions" tabIndex="0">
            
        </button>
        <button id="pause" className="dis-ass" tabIndex="0" aria-label="Pause instructions"></button>
        <button id="prev" className="dis-ass"  tabIndex="0" aria-label="Rewind instructions"></button>
        <button id="next" className="dis-ass"  tabIndex="0" aria-label="Fast-forward instructions"></button>
        <button id="game-button" style={{display:"none"}} onClick={()=>{this.updateActivity();this.audio.btnClk()}}> <div>Go to game</div> </button>
        <div id="video-alert" className="sr-only" aria-live="polite" aria-atomic="true"></div>
        </div>
   );
    }
}

import React, { Component } from "react";
import {data} from '../../data/data.json';
import Images, { audioUrl } from '../../preload';
import audioPlayer from '../../audio';
import "./activity.css";

class ActivityScreen extends Component{
    
    constructor(props){
        super(props);
        this.state ={
            numbersLength:[0,1,2,3,4,5,6,7,8,9],
            narationAudioImg:Images['vot_bg.png'],
            nextClueToggle:false,
            allUnits:data.mysteryNumberUnits,
            showFinishBtn:false,
            showCheckBtn:false,
            clueContent:null,
            answers:data.answers[0]
        };
        this.checkTaskCount = 0;    
        this.narrationId = 0;
        this.clueCount = 0;
        this.triggerClueEnabled = false;
        this.initialAudio = true;
    }
    componentWillMount(){
        let {answers,allUnits,clueContent} = this.state;
        allUnits.forEach((val,i)=>{val.addShaded='';val.disabled=false});
        answers = data.answers[this.props.data.currentActivity];
        clueContent = data.clueContent[this.props.data.currentActivity];
        this.setState({allUnits,answers,clueContent},()=>{console.log(this.state.answers)});
        this.audio = audioPlayer(this.onEnded.bind(this));
        
        if(this.props.data.isVoiceEnabled){
            this.disableNumbers(true);
            this.props.updateDisable(true);
            this.props.disableSndVceBtn(true);
            this.changeNaration(0);
        }else{
            this.initialAudio = false;
            this.disableNumbers(false);
            this.changeNaration(0);
            this.props.updateDisable(false);
            this.props.disableSndVceBtn(false);
        }
        
        

    }
    disableNumbers(checkState){
        let {allUnits} = this.state;
        allUnits.forEach((val)=>val.disabled = checkState);
        this.setState({allUnits});
    }
    onEnded(){
        if(this.initialAudio){
            this.initialAudio = false;
            this.disableNumbers(false);
            this.props.updateDisable(false);
            this.props.disableSndVceBtn(false);
         }
        
    }

    changeClue(){
        this.clueCount++;
        if(this.clueCount >= this.state.clueContent.length){
            this.clueCount = 0;
        }
        this.forceUpdate();
    }
    createNumbers(){
        let {allUnits} = this.state;
       return this.state.numbersLength.map((numb,i) =>{             
            return (<tr key = {i}>                    
             {Object.keys(this.state.allUnits).map((number,j)=>{
                 return (<td key={j}><button tabIndex="1" disabled={allUnits[number].disabled} className={`shadeChild ${allUnits[number].addShaded}`}
                 id={"btn"+i+"_"+j} onClick={(e)=>{this.numberBtnClick(e,j, i);this.audio.btnClk()}}
                 data-number={i}>{i} <span className="sr-only">of the hundreds place </span>
                 <span className="sr-only shadeInfo">{allUnits[number].addShaded==='unSelect'?<React.Fragment>shaded</React.Fragment>:<React.Fragment>unshaded</React.Fragment>}</span><span className="modifyHeader sr-only">
                 </span></button></td>)})}</tr>)});
    }
    createHeaders(){
        let {allUnits} = this.state;
       return Object.keys(this.state.allUnits).map((number,i) =>{
           return <th key={i}><button 
                onMouseOver={(e)=>{e.stopPropagation();changeSrc(e,Images['redbutton1_1.png'])}}
                onMouseDown={(e)=>{e.stopPropagation();changeSrc(e,Images['redbutton1_2.png'])}}
                onMouseUp={(e)=>{e.stopPropagation();changeSrc(e,Images['redbutton1.png'])}}
                onMouseOut={(e)=>{e.stopPropagation();changeSrc(e,Images['redbutton1.png'])}}
                onClick={(e)=>{this.addShaded(i,e); this.audio.btnClk()}}
                disabled={allUnits[number].disabled} tabIndex="1" id={"headerbtn_"+i}  className="shadeHeader acc_btn" 
                aria-label="Shades all numbers in the hundreds column of the grid" 
                ><span className="headBtn">{allUnits[number].unit}</span> 
                <span className="sr-only update_column"></span></button>{allUnits[number].isDecimalRequire?<span className="decimalPoint">.</span>:null}</th>
        })
    }

    readOnlyInputs(){
        let {allUnits} = this.state;
        return Object.keys(this.state.allUnits).map((number,i) =>{
            return <td key={i}><input tabIndex="-1" className="readonlyInput" id={"txt_"+(i)} type="text" defaultValue="?" readOnly="" disabled/>{allUnits[number].isDecimalRequire?<span className="decimalPoint">.</span>:null}</td>
        })
    }
  
    toggleNextClue(condition){
            this.setState({nextClueToggle: condition});        
    }
    changeNaration(id){
        this.narrationId = id;
        this.audio.play(id);
        this.forceUpdate();
    }
    numberBtnClick(ev,index,parentIndex){

        let el = ev.currentTarget,count=[],inputBoxValue=[];   
        this.changeNaration(2);
        let selectedEl;     
        el.classList.toggle('unSelect');
        el.querySelector('.shadeInfo').innerText=el.classList.contains('unSelect')?'shaded':'unShaded';
        this.state.numbersLength.forEach((value,parentIndex)=>{
            let id = document.getElementById('btn'+parentIndex+'_'+index);
            if(id.classList.contains('unSelect')) { count.push(true)}else selectedEl = id;             
        })
        let inputBox = document.getElementById('txt_'+index);
        (count.length === 9) ? inputBox.value = selectedEl.dataset.number:inputBox.value = "?";
        this.state.allUnits.forEach((value,i)=>{
            if(document.getElementById('txt_'+i).value !== '?'){
                inputBoxValue.push(true);
            }
        });
      
        if (inputBoxValue.length === this.state.allUnits.length){
            this.setState({showCheckBtn:true}); 
            this.changeNaration(1) ;
         }else{ this.setState({showCheckBtn:false})}
     }

    addShaded(index,e){
        this.changeNaration(2);
        let {allUnits} = this.state,count=[] ;
        document.getElementById('txt_'+index).value = '?';

         this.state.numbersLength.forEach((value,parentIndex)=>{
            let id = document.getElementById('btn'+parentIndex+'_'+index);
             if(id.classList.contains('unSelect')) { count.push(true)};             
         })
         if(count.length !==0 && count.length < this.state.numbersLength.length){
            allUnits[index].addShaded = '';
             this.setState({allUnits},()=>{allUnits[index].addShaded = 'unSelect';this.setState({allUnits})})
        }else{
           let check = (allUnits[index].addShaded==='') ? "unSelect":'';
           allUnits[index].addShaded = check;   
           this.setState({allUnits});
        }
        
        
    }
    validateAnswers(){        
        this.setState({showCheckBtn:false});
        let {allUnits,showFinishBtn} = this.state;
        let validCount = 0;
        this.state.answers.forEach((val,i)=>{
           let inputBox = document.getElementById('txt_'+i);
            if(val === parseInt(inputBox.value)){
                validCount++;                
                if(this.checkTaskCount === 1){
                    inputBox.classList.add('grad');
                    allUnits[i].disabled = true;
                   
                }                
            }
            if(this.checkTaskCount === 2){
                inputBox.value = val;
                inputBox.classList.add('grad');
                allUnits[i].disabled = true;
                showFinishBtn = true;
                this.triggerClueEnabled = true;
            }            
        });
        if(validCount === this.state.answers.length){
            this.audio.effectAudio('sound_success.mp3');
            allUnits.map((val,i)=>{val.disabled = true;document.getElementById('txt_'+i).classList.add('grad') })
            showFinishBtn = true;
            this.changeNaration(3) ;
        }else{
            this.audio.effectAudio('sound_failure.mp3');
            if(this.checkTaskCount === 0) this.changeNaration(4);
            if(this.checkTaskCount === 1) this.changeNaration(5);
            if(this.checkTaskCount === 2) this.changeNaration(6);           
        }
        this.setState({allUnits,showFinishBtn});
        this.checkTaskCount++;
    }
    
    componentWillUnmount() {
        this.audio.pause();
        this.audio.extraAudioPause();
    }

    render(){        
        let nextClueClass = ["Nextclues", "acc_btn"];
        if(this.state.nextClueToggle){
            nextClueClass.push('highlight');
        }
        let showCheckBtn = {
            display: this.state.showCheckBtn ? "block" : "none"
        };
        
        let showFinishBtn = {
            display: this.state.showFinishBtn ? "block" : "none"
        }
       
        return (
            
            <section className="play-screen page">
                <div className="narration-container " style={{backgroundImage:'url('+this.state.narationAudioImg+')'}} >
                <div className="narration-inner">
                <button 
                onMouseOver={(e)=>{e.currentTarget.querySelector('img').src = Images['vo_o.png']}}
                onMouseDown={(e)=>{e.currentTarget.querySelector('img').src = Images['vo_d.png']}}
                onMouseOut={(e)=>{e.currentTarget.querySelector('img').src = Images['vo_n.png']}}
                onClick={(e)=>{this.initialAudio = false; this.audio.extraAudioPause();this.audio.play(data.narrations[this.narrationId].id,true)}}
                tabIndex="1" disabled={this.props.data.isDisableAll} aria-label="listen to instructions" className="audio-btn"><span className="sr-only">Instruction audio</span><img className="audio-btn1" src={Images['vo_n.png']} alt=''/>
                </button>
                <p aria-live="polite" aria-atomic="true" click="narationClick()" className="">{data.narrations[this.narrationId].content}</p>
            </div>
        </div>

         <div className="workArea">
            <div className="clueBoxArea">
				<div className="blueBox" role="region" aria-labelledby="region1">
					<h2 id="region1" className="sr-only">Clue of Blue player</h2>		
                    <button 
                     onMouseOver={(e)=>{e.currentTarget.querySelector('img').src = Images['vo_o.png']}}
                     onMouseDown={(e)=>{e.currentTarget.querySelector('img').src = Images['vo_d.png']}}
                     onMouseOut={(e)=>{e.currentTarget.querySelector('img').src = Images['vo_n.png']}}
                     onClick={(e)=>{this.audio.extraAudio(this.state.clueContent[this.clueCount].blueAudio);this.audio.pause()}}
                     tabIndex="1" disabled={this.props.data.isDisableAll} className="blue acc_btn" aria-label="Listen to the clue of Blue player" aria-describedby="blue_describtion">
                        <img src={Images['vo_n.png']} className="audiobtn1"  alt="Listen to the clue of Blue player"/>
						<p className="noMargin noPadding calloutNum" aria-hidden="true">{(this.clueCount+1)}</p>
                        <p className="noMargin noPadding audioDescription" id="blueText" aria-hidden="true">{this.state.clueContent[this.clueCount].blue}</p> 
					</button>
					<span className="sr-only" id="blue_describtion">{(this.clueCount+1) + this.state.clueContent[this.clueCount].blue}</span>
				</div>
                <div className="greenBox" role="region" aria-labelledby="region1">
					<h2 id="region1" className="sr-only">Clue of Blue player</h2>		
                    <button 
                     onMouseOver={(e)=>{e.currentTarget.querySelector('img').src = Images['vo_o.png']}}
                     onMouseDown={(e)=>{e.currentTarget.querySelector('img').src = Images['vo_d.png']}}
                     onMouseOut={(e)=>{e.currentTarget.querySelector('img').src = Images['vo_n.png']}}
                     onClick={(e)=>{this.audio.extraAudio(this.state.clueContent[this.clueCount].greenAudio);this.audio.pause()}}
                     tabIndex="1" disabled={this.props.data.isDisableAll} className="blue acc_btn" aria-label="Listen to the clue of Blue player" aria-describedby="blue_describtion">
                           <img className="audiobtn1" src={Images['vo_n.png']} alt="Listen to the clue of Green player"/>
						<p className="noMargin noPadding calloutNum" aria-hidden="true">{(this.clueCount+1)}</p>
                        <p className="noMargin noPadding audioDescription" id="greenText" aria-hidden="true">{this.state.clueContent[this.clueCount].green}</p> 
					</button>
					<span className="sr-only" id="blue_describtion">{(this.clueCount+1) + this.state.clueContent[this.clueCount].green}</span>
				</div>
                <button
                 onMouseOver={(e)=>{changeSrc(e,Images['link_o.png']);this.toggleNextClue(true)}}
                 onMouseDown={(e)=>{changeSrc(e,Images['link_d.png']);this.toggleNextClue(true)}}
                 onMouseUp={(e)=>{changeSrc(e,Images['link_up.png']);this.toggleNextClue(false)}}
                 onMouseOut={(e)=>{changeSrc(e,Images['link_up.png']);this.toggleNextClue(false)}}
                 onClick = {(e)=>{this.changeClue();this.audio.btnClk()}}
                 tabIndex="1" className={nextClueClass.join(' ')} highlight="highlight" disabled={this.triggerClueEnabled || this.props.data.isDisableAll}>Next Clues</button>
			
		</div>
        <div className="tableArea">
			<h2 id="region3" className="sr-only">Number grid region</h2>
			<div className="sr-only" id="numberRegionText" aria-live="polite" aria-atomic="true"></div>
				<table>
				    <caption><span className="sr-only">Select the number as per the clue &amp; find the mystery number</span></caption>
        		<tbody>
                    <tr>{this.readOnlyInputs()}</tr>
                    <tr className="tableRow">{this.createHeaders()}</tr>        
                   {this.createNumbers()}					
				</tbody></table>
			</div>

		</div>
        <footer>
            <button 
            style={showCheckBtn}
            onMouseOver={(e)=>{changeSrc(e,Images['check_o.png'])}}
            onMouseDown={(e)=>{changeSrc(e,Images['check_d.png'])}}
            onMouseUp={(e)=>{changeSrc(e,Images['check_n.png'])}}
            onMouseOut={(e)=>{changeSrc(e,Images['check_n.png'])}}
            tabIndex="5"  className="checkBtn enabled" onClick={()=>{this.validateAnswers()}}>Check</button>	
            <button 
             style={showFinishBtn}
             onMouseOver={(e)=>{changeSrc(e,Images['finish_btn_over.png'])}}
             onMouseDown={(e)=>{changeSrc(e,Images['finish_btn_down.png'])}}
             onMouseUp={(e)=>{changeSrc(e,Images['finish_btn_up.png'])}}
             onMouseOut={(e)=>{changeSrc(e,Images['finish_btn_up.png'])}}
             onClick={()=>{this.props.updateActivity();this.audio.btnClk()}}
            tabIndex="5"  aria-label="Finish" className="finish-btn enabled">
				<div>Finish</div><span className="sr-only">click finish to leave the game </span></button>
            <button 
             onMouseOver={(e)=>{changeSrc(e,Images['how_to_play_o.png'])}}
             onMouseDown={(e)=>{changeSrc(e,Images['how_to_play_d.png'])}}
             onMouseUp={(e)=>{changeSrc(e,Images['how_to_play_n.png'])}}
             onMouseOut={(e)=>{changeSrc(e,Images['how_to_play_n.png'])}}
             onClick={()=>{this.props.updateActivity('HowToPlayPage');this.audio.btnClk()}}
             disabled={this.props.data.isDisableAll}
            tabIndex="5" aria-label="How to play" className="how-btn enabled">
				<div>How to play</div><span className="sr-only">click to go How to play page</span></button>
		</footer>
            </section>
        )
    }
}


const changeSrc = (el,image) =>{
    el.currentTarget.style.backgroundImage='url('+image+')';
}


export default ActivityScreen;

import React, { Component } from 'react';
import './Header.css';
import audioPlayer from '../../audio';
class Header extends Component {
    constructor(props){
        super(props);
        this.state = {
            isPopupEnabled : false
        }
        this.popUpOpenClose.bind(this);
    }
    
    popUpOpenClose(e){
        e.preventDefault();
       this.setState({ isPopupEnabled: !this.state.isPopupEnabled });   
    }
    componentDidMount() {
        this.props.headerValue(this.refs);
    }
    
  render() {
      let audio = audioPlayer();
    return (
        <div className='Header-container'>
            <header className="App-header">
                <div className='Header-logo'></div>
                <button ref='sound' tabIndex="1" disabled={this.props.data.disableSndVceBtn} className="effect-btn dis-ass " aria-pressed="false" onClick={(e)=>{this.props.trigger('isSoundEnabled');audio.btnClk()}} >{this.props.data.isSoundEnabled ? <React.Fragment>Sound: <b>on</b></React.Fragment>:<React.Fragment>Sound: <b>off</b></React.Fragment>}</button>
                <button ref='voice' tabIndex="1" disabled={this.props.data.disableSndVceBtn} className="effect-btn dis-ass voice-btn" aria-pressed="false" onClick={(e)=>{this.props.trigger('isVoiceEnabled');audio.btnClk();audio.pause()}} > {this.props.data.isVoiceEnabled ? <React.Fragment>Voice: <b>on</b></React.Fragment>:<React.Fragment>Voice: <b>off</b></React.Fragment>} </button>
                <button tabIndex="1" id="rootCloseBtn" onClick={(e)=>{this.popUpOpenClose(e)}} className="close_button dis-ass"> <span className="sr-only">Close It has a popup</span></button>
            </header>
            {this.state.isPopupEnabled ? <PopUp popUpClose = {this.popUpOpenClose.bind(this)} />:null}
         </div>   
    );
  }
}

class PopUp extends Component{
    constructor(props){
        super(props);
        this.closePage.bind(this);
    }
    
    closePage(){
        window.open('', '_self', '').close();
    }
    render(){
       
        return(
         <div className="close-clicked">
                <div className="sr-only" id="inst_txt" aria-live="polite" aria-atomic="true">Are you sure you want to leave the game ?</div>
                <div className="overlay"></div>
                <div>
                    <div className="close-box" id="closebox">
                        <span id="dialogContent">Are you sure you want to leave the game?</span>
                        <button className="no_btn"  onClick={(e)=>{this.props.popUpClose(e)}}>
                            <div>Keep playing</div>
                        </button>
                        <button className="yes_btn"onClick={(e)=>{this.closePage()}}>
                            <div>Exit</div>
                        </button>
                    </div>
                </div>
            </div>
        
        )
    }
}

export default Header;
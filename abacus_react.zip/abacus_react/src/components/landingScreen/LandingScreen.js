import React, { Component }from 'react';
import Images from '../../preload';
import  audioPlayer  from "../../audio";
import {data} from '../../data/data.json';
class Landingscreen extends Component {
    render(){
        let audio = audioPlayer();
        return(
            <section className="home-screen homepage page" style={{outline:' none'}}>
            <h1>{data.courseTitle} </h1>
                <button className="how-btn ng-isolate-scope" aria-label="How to play"
                    onClick = { ()=> { this.props.pageSelection('HowToPlayPage');audio.btnClk()}}
                onMouseOver={(e)=>{changeSrc(e,Images['how_to_play_o.png'])}}
                onMouseDown={(e)=>{changeSrc(e,Images['how_to_play_d.png'])}}
                onMouseOut={(e)=>{changeSrc(e,Images['how_to_play_n.png'])}}>   
                <div>How to play</div><span className="sr-only">click to go How to play page</span>
            </button>
            <button className="play-btn ng-isolate-scope" aria-label="Play"
            onClick = { ()=> { this.props.pageSelection('activityPage');audio.btnClk()}}
            onMouseOver={(e)=>{changeSrc(e,Images['play_o.png'])}}
            onMouseDown={(e)=>{changeSrc(e,Images['play_d.png'])}}
            onMouseOut={(e)=>{changeSrc(e,Images['play_n.png'])}}>   
                <div>Play</div><span className="sr-only">click to play the lesson</span>
            </button>
      </section>
        )
    }
}


const changeSrc = (el,image) =>{
     el.currentTarget.style.backgroundImage='url('+image+')';
}


export default Landingscreen;
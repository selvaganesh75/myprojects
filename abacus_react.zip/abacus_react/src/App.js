import React, { Component } from 'react';
import Header from './components/header/Header';
import spinner48px from './spinner48px.gif';
import Landingscreen from './components/landingScreen/LandingScreen';
import ActivityScreen from './components/activityScreen/ActivityScreen';
import HowtoPlayScreen from './components/howtoPlayScreen/HowtoPlayScreen';
import {data} from "./data/data.json";
import Images,{audioUrl} from './preload.js';
import './App.css';

class App extends Component {
  constructor(props){
      super();
      this.state = {
        isLandingScreen:true,
        isActivityScreen:false,
        isHowtoPlayScreen:false,
        currentActivity:null,
        totalActivity:null,
        currentActivityIndex:-1,
        preloader:"none",
        isSoundEnabled:true,
        isVoiceEnabled:true,
        narrations:data.narrations,
        isDisableAll:false,
        disableSndVceBtn:false,
        headerBtn:null
      }
      this.pageSelection.bind(this);
      this.updateSoundToggle.bind(this);
      this.updateDisable.bind(this);
      this.headerComponent.bind(this);
  }
  randomizeActivity(array)
    {
        let currentIndex = array.length, temporaryValue, randomIndex;
        // While there remain elements to shuffle...
        while (0 !== currentIndex) {
  
          // Pick a remaining element...
          randomIndex = Math.floor(Math.random() * currentIndex);
          currentIndex -= 1;
          
          // And swap it with the current element.
          temporaryValue = array[currentIndex];
          array[currentIndex] = array[randomIndex];
          array[randomIndex] = temporaryValue;
          
    }
    return array; 
    }
    updateDisable(value){
      this.setState({isDisableAll:value})

    }
    disableSndVceBtn(value){
      this.setState({disableSndVceBtn:value})
    }
    updateActivity(page){   
        let {currentActivityIndex,totalActivity,currentActivity} = this.state;
          (currentActivityIndex >= totalActivity.length-1) ? currentActivityIndex=0 : currentActivityIndex++;
          currentActivity = totalActivity[currentActivityIndex];
          this.setState({currentActivityIndex,currentActivity})
       
       this.state.narrations.forEach((val)=>{val.playedOnce=false});
       this.pageSelection(page);
    }

    updateSoundToggle(isSoundVoice){
        this.setState({[isSoundVoice]:!this.state[isSoundVoice]})
    }
    headerComponent(data){
      this.setState({headerBtn:data})
    }
  
  preloader(){
     let count = 0,OverAllCount = Object.keys(audioUrl).length;
     Object.keys(audioUrl).forEach((value)=>{
         let preloadAudio = new Audio()
         preloadAudio.src = audioUrl[value];
         preloadAudio.addEventListener('canplaythrough', loadedAudio.bind(this), false);
         function loadedAudio(){
            count++;
            if(count === OverAllCount-5){ 
               this.setState({preloader:"none"});
          }}
     });
     Object.keys(Images).forEach((value)=>{
         let image = new Image(); image.src = Images[value];
     })
  }
  pageSelection(currentPage){
    switch (currentPage) {
      case "activityPage":
          this.setState({ isLandingScreen:false, isActivityScreen:true, isHowtoPlayScreen:false });
        break;
      case "HowToPlayPage":
          this.setState({ isLandingScreen:false, isActivityScreen:false, isHowtoPlayScreen:true});
          break;
      default:
         this.setState({ isLandingScreen:true, isActivityScreen:false, isHowtoPlayScreen:false });
        break;
    } 
  }
  componentDidMount(){   
   
    this.preloader();  
    let {totalActivity} = this.state;  
    totalActivity = this.randomizeActivity(data.activity);
    this.setState({totalActivity},()=>{this.updateActivity();})
 }
  render() {
    return (
      <div className="App" id="student-edition">
        <div className="activity" id="activity-wrapper">
          <Header data= {this.state} trigger={this.updateSoundToggle.bind(this)} headerValue={this.headerComponent.bind(this)}/>
         {this.state.isLandingScreen ? <Landingscreen pageSelection = {this.pageSelection.bind(this)} data={this.state}/> : this.state.isActivityScreen ? <ActivityScreen disableSndVceBtn={this.disableSndVceBtn.bind(this)}updateDisable = {this.updateDisable.bind(this)}updateActivity = {this.updateActivity.bind(this)} data={this.state}/> : <HowtoPlayScreen pageSelection = {this.pageSelection.bind(this)} data={ this.state.headerBtn}/>} 
        </div>
        <Preloader preloader={this.state.preloader}/>      
      </div>
    );
  }
}


const Preloader = ({preloader}) => (
  
  <div className="preloadContainer" style={{display:preloader}}>
    <div className="pre-loader" id="preloader-element" >
	      	<img alt="loading" src={spinner48px}/>
    	</div>
    </div>
   );
 

export default App;

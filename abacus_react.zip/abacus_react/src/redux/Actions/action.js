import { ISSOUND_ENABLED,ISVOICE_ENABLED } from "../Constants/actiontypes";
export const soundChange = isSound => ({ type: ISSOUND_ENABLED, payload: isSound });
export const voiceChange = isVoice => ({ type: ISVOICE_ENABLED, payload: isVoice });
import { ISVOICE_ENABLED,ISSOUND_ENABLED } from "../Constants/actiontypes";
const initialState = {
  isSoundVoice: []
};
const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    case ISVOICE_ENABLED:
      return { ...state, isSoundVoice: [...state.isSoundVoice, action.payload] };
    case ISSOUND_ENABLED:
        return {...state,isSoundVoice:[...state.isSoundVoice, action.payload]};
    default:
      return state;
  }
};
export default rootReducer;
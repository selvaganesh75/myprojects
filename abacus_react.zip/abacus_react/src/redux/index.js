import store from "./Store/index";
import { soundChange,voiceChange } from "./Actions/action";
window.store = store;
window.selectNumber = selectNumber;
console.log(store.getState());
store.subscribe(() => console.log('Look ma, Redux!!'));
store.dispatch( soundChange({ name: 'React Redux Tutorial for Beginners', id: 1 }) )
store.dispatch( voiceChange({ name: 'React Redux Tutorial for Beginners', id: 2 }) )
console.log(store.getState());
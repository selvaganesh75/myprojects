import $ from "jquery";
import {audioUrl} from '../../preload.js';
var frSound,canvasTimeLine,i,currSound,currPos;
var lib, images, createjs, ss, AdobeAn;
(function (lib, img, cjs, ss, an) {
var p; // shortcut to reference prototypes
lib.ssMetadata = [];

console.log(lib)
// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.harconsoleControlShadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CC3333").s().p("AToBqQgbAAghgFIhCgJIhfgMQhFgHhpgKQhqgKiHgIQiGgJidgGQicgGitAAQiqAAidAGQieAGiHAJQiGAIhpAKQhqAKhFAHIheAMIhEAJQggAFgbAAQggABgZgMQgZgNgOghIg3iaQAKARAPAVQAPAVAWAUQAXATAhALQAhAMAuABQAYAAAdgEQBlgOB3gLQB4gKB/gHQB+gGB+gEQB8gEBxgBIDIgBIDKABQBxABB8AEQB9AEB+AGQCAAHB2AKQB4ALBmAOQAcAEAYAAQAuAAAigNQAggLAYgTQAWgUAPgVQAOgVAKgRIg2CaQgQAhgYANQgXALgdAAIgFAAg");
	this.shape.setTransform(140.7,10.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,281.3,21.3);


(lib.harconsoleControlHighlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD445").s().p("AXqB8QgChAgdgpQgegogzgWQg0gXhCgKIjqglQiFgVihgTQihgUi9gNQi+gMjYgBQjXABi9AMQi9ANiiAUQihATiFAVIjrAlQhCAKgzAXQgzAWgdAoQgeApgCBAQgCA9AcBWIhZj/QgQgrASgeQARgdAugTQAugTBDgMIBngSQBQgPCCgTQCBgTCpgTQCogTDIgMQDHgMDcgBQDdABDIAMQDHAMCpATQCpATCBATQCBATBRAPIBmASQBDAMAuATQAuATARAdQASAegRArIhZD/QAdhWgCg9g");
	this.shape.setTransform(158.5,27.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,317,54.2);


(lib.harbkgframe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9AD400").s().p("EAvjAKaInTAAInaAAInRAAIm4AAImPAAIlUAAIkLAAIiwAAIhEAAIgBAAIhFAAIiwAAIkKAAIlUAAImPAAIm4AAInRAAInaAAInSAAIlPgBQC8gECxgPQDkgTDVggQDUghDIgoQB4gZBNgVQBOgXAugVQAtgWAWgUQAXgVAHgVQAIgVACgWQADgVgJgoQgJgogRg1QgRg2gVg6IgqhzIgnhpIgdhQQgTg+AGgkQAGgkAXgSQAXgSAdgIIBlgdQBUgXCZghQCYghDgghQDfgfEngWQEngUFxgCIABAAQFwACEnAUQEoAWDfAfQDfAhCZAhQCZAhBUAXIBlAdQAdAIAXASQAXASAGAkQAGAkgUA+IgcBQIgoBpIgqBzQgUA6gRA2QgRA1gJAoQgJAoACAVQADAWAIAVQAHAVAWAVQAXAUAtAWQAtAVBOAXQBOAVB3AZQDIAoDVAhQDVAgDkATQDkATD1ABIm6AAg");
	this.shape.setTransform(359.3,66.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(10.8,0,697,133.1);


(lib.harbackgroundpanel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9AD400").s().p("EhQGA4AMAAAhv/MCgNAAAMAAABv/g");
	this.shape.setTransform(400,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-112.7,-58.4,1025.4,716.9);


(lib.harscreenshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Egu3AjKMAAAhGTMBdvAAAMAAABGTg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-300,-225,600,450);


(lib.harcontrolpanelshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ASTHeQg7gJh0gOQh1gNivgNQivgLjogHQiDgDiVAAQkzAAjsANQjrAMifAQQiZAPhPALIhPANQgegBgegPQgdgPgVgYQgQgTgHgVIg8imIibmtQgEgLAAgKQgIgeATgcQAVgfAygTQAQgGATgFIA1gKQA1gLBjgQQBigQCKgTQCKgTCrgQQCrgQDGgLQDGgKDZgBQDLAACqAHQCqAGCKALQDZARCTAVQCTAXBXATQBXATAmAKQBJATAYAiQAPAWAAAZIACAJQACARgKAaQgpBvgoBuIhPDeIg2CYQgJAYgSAUQgVAXgdANQgcAOgdABIg7gKg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-158.6,-48.7,317.3,97.5);


(lib.Path = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.Path, null, null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.Group, null, null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.Symbol2, null, null);


(lib.HM_mcmystnumdigitbackwhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C56400").s().p("AhvANIgcgZIEXAAIgdAZg");
	this.shape.setTransform(14,1.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF99").s().p("AiLANIAcgZIDeAAIAdAZg");
	this.shape_1.setTransform(14,35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF8D00").s().p("AgNi0IAbAaIAAE1IgbAag");
	this.shape_2.setTransform(1.4,18.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#F3F3F3","#FFFFFF","#FFFFFF","#F3F3F3","#E6E6E6"],[0,0.157,0.58,0.863,1],0,-15.5,0,15.5).s().p("AhuCbIAAk1IDdAAIAAE1g");
	this.shape_3.setTransform(14,18.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFC038").s().p("AgOCbIAAk1IAdgaIAAFpg");
	this.shape_4.setTransform(26.6,18.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.HM_mcmystnumdigitbackwhite, new cjs.Rectangle(0,0,28.1,36.3), null);


(lib.HM_mcclipwhite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah0BpQgKAAgIgIQgIgHAAgLIAAidQAAgLAIgHQAIgIAKAAIDoAAQALAAAIAIQAIAHAAALIAACdQAAALgIAHQgIAIgLAAg");
	this.shape.setTransform(15.7,11.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-12.7,-12.7,12.8,12.8).s().p("Ah6B2QgOAAgKgJQgKgJAAgOIAAiqQAAgOAKgKQAKgKAOAAID1AAQAOAAAKAKQAJAKABAOIAACqQgBAOgJAJQgKAJgOAAg");
	this.shape_1.setTransform(15.7,11.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.HM_mcclipwhite, new cjs.Rectangle(0,0,31.3,23.7), null);


(lib.HM_Headinghilite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(4.5,1,1).p("Ao8hwIR5AAIAADhIx5AAg");
	this.shape.setTransform(57.1,11,0.997,0.978);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.2,-2.2,118.6,26.5);


(lib.HM_harVoicebutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACcAuQgJgEgFgJQgFgJAAgMQAAgKAFgIQAFgJAIgEQAJgFALAAQAQAAALALQAKAKAAAQQAAAQgKALQgLALgQAAQgKAAgJgFgACigDQgFAFAAALQAAALAFAFQAFAGAIAAQAHAAAFgGQAGgFAAgLQAAgLgGgFQgFgFgHAAQgIAAgFAFgAgGApQgJgKAAgRQAAgSAJgKQAJgKAPAAQAOAAAKAKQAJAKAAARIAAADIg1AAQAAAMAFAGQAGAHAKAAQAGAAAFgEQAFgDADgIIAMABQgDAMgIAGQgIAGgNAAQgPAAgJgKgAAEgIQgFAFgBAJIAoAAQgBgIgEgFQgGgHgJAAQgJAAgFAGgAhMApQgJgKAAgSQAAgMAEgHQAEgJAIgFQAIgEAJAAQAMAAAIAGQAHAGACALIgMABQgBgGgFgEQgEgEgGAAQgKAAgFAHQgGAGAAAOQAAAPAFAGQAGAHAJAAQAHAAAFgFQAFgEABgJIAMABQgCANgIAHQgIAHgMAAQgPAAgJgKgAi5ApQgKgKAAgSQAAgTAMgKQAJgIANAAQAPAAAKAKQAJAKAAAQQAAAOgEAIQgEAIgIAEQgIAFgKAAQgPAAgJgKgAiwgHQgGAHAAANQAAAOAGAHQAGAHAJAAQAKAAAGgHQAGgHAAgOQAAgNgGgHQgGgHgKAAQgJAAgGAHgAESAxIAAglQAAgMgBgCQgBgDgDgCQgDgCgEAAQgFAAgEACQgEADgBAEQgCAEAAAMIAAAhIgTAAIAAhHIASAAIAAAKQAKgMAOAAQAGAAAGACQAFADADADQACAEABAEIABAMIAAAtgABFAxIAAgOIAOAAIAAAOgAhwAxIAAhHIAMAAIAABHgAj9AxIgnhjIAOAAIAaBIIAGAQIAFgQIAbhIIAOAAIgoBjgABFgIIAAgOIAOAAIAAAOgAhwgkIAAgOIAMAAIAAAOg");
	this.shape.setTransform(43.9,12.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(14.6,7.7,58.7,10.2);


(lib.HM_harSymbol74 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BA0000").s().p("AglAeQgIgWgBgVQgBgWADgPQAEgPAHgDQABArAMAYQAMAYAPAKQAQAKAMACIAMACIgSAGQgSAGgZAKQgPgQgIgXg");
	this.shape.setTransform(4.7,6.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9.4,13.9);


(lib.HM_harSymbol73 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BA0000").s().p("AAOBkIgQgdQgJgRgIgSQgHgRgDgNQgCgLgBgTQgBgTABgUQABgTADgNQACgOADgBQgCARAAAXQgBAWAFAVQAFAVANALQAOANAJARQAIARADAPQADAPgCAJIgDANQgBAGgDABIAAAAQgDAAgIgLg");
	this.shape.setTransform(3.3,11.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,6.7,22.3);


(lib.HM_harSymbol12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai4gRQAzgqA7gTQA8gSA6gBQA8AAAxALQAyAKAgAQQAgAQAGAOQgWgQgrgLQgrgMg7gCQg7gBhBAPQhBAPhBAlQhCAlg6BCQAkhJA0gqg");
	this.shape.setTransform(27.3,9.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,54.5,19.6);


(lib.HM_harSymbol11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhCCwQg1gBgwgMQgxgLgkgXQgkgYgQgkQAfAiAuAWQAvAXA6AIQA5AJA/gIQBUgNBAglQA/gmAgg1QAgg0gKg7QgCgNABgPIAAgcQgBgOgHgLQAQASAOAXQAOAWAFAXQAIAsgRArQgQAqglAkQglAlg0AZQg0AZhAAJQgoAGgqAAIgUgBg");
	this.shape.setTransform(30.5,17.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,61.1,35.4);


(lib.HM_harspeakershadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ABeByQgBAAAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAIgDgBIgDgBIgDgBIgEgCIgMgHIgxgkIgTAGIggALIgfAKIgNAFIgDAAIgBAAQgHgBgHgKQgHgLgFgRQgEgRgBgSIgBgIIAAgPIABgcQABgPAHgHQACgEAGgBIAOAAIAhAAIAgAAIARAAIAOgRIAVgYIAOgPIABgCQAFgBAFAEQAMAHANAdQAMAcAJApIAIArIABAKIAAADIAAAEIABAbIgBAHQAAAHgDAGQgDAGgFADQgDADgEAAIgCAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.5,-11.4,23.1,22.9);


(lib.HM_harSoundbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AC0AvQgJgEgEgJQgFgJAAgMQAAgKAFgIQAEgJAJgEQAJgFAKAAQARAAAKALQALAKAAAQQAAAQgLALQgKALgRAAQgKAAgJgFgAC7gCQgFAFAAALQAAALAFAFQAFAGAHAAQAIAAAFgGQAFgFAAgLQAAgLgFgFQgFgFgIAAQgHAAgFAFgAAXAvQgHgFgEgIQgEgJAAgLQAAgLAEgIQADgJAIgEQAHgFAJAAQAGAAAFADQAGADADAEIAAgkIAMAAIAABjIgLAAIAAgJQgHALgOAAQgIAAgIgFgAAagGQgFAGAAAOQAAAOAGAHQAFAHAIAAQAJAAAFgHQAGgGAAgOQAAgPgGgGQgGgHgIAAQgIAAgGAHgAiCAxQgGgCgCgEQgDgDgBgGIgBgLIAAgsIANAAIAAAnIAAANQABAFAEADQAEACAFAAQAGAAAFgDQAFgCACgFQACgFAAgJIAAgmIAMAAIAABHIgLAAIAAgKQgIAMgPAAQgGAAgGgDgAjYAqQgJgKAAgSQAAgTALgKQAJgIAOAAQAPAAAJAKQAKAKAAAQQAAAOgEAIQgEAIgIAEQgJAFgJAAQgPAAgKgKgAjOgGQgGAGAAAOQAAAOAGAHQAGAHAJAAQAJAAAGgHQAGgHAAgOQAAgOgGgGQgGgHgJAAQgJAAgGAHgAkpAwQgJgEgFgIQgGgIAAgKIANgBQAAAHAEAFQADAFAHADQAHADAIAAQAIAAAGgCQAFgCADgEQADgEAAgFQAAgFgDgDQgCgEgHgCIgSgFQgNgDgGgCQgHgEgEgGQgDgFAAgHQAAgIAEgGQAEgHAJgDQAIgEAKAAQALAAAJAEQAIAEAFAGQAEAHABAJIgNABQgBgJgGgFQgGgFgLAAQgMAAgGAEQgFAFAAAGQAAAFAEAEQADADARAEQAQAEAGACQAIAEAFAGQAEAGAAAIQAAAIgFAHQgEAHgJAEQgJAEgKAAQgOAAgJgEgAErAyIAAglQAAgMgCgCQgBgDgDgCQgCgCgEAAQgFAAgEACQgEADgCAEQgBAEAAAMIAAAhIgTAAIAAhHIASAAIAAAKQAJgMAOAAQAHAAAFACQAFADADADQADAEABAEIABAMIAAAtgABeAyIAAgOIAOAAIAAAOgAgSAyIAAgsQAAgGgBgEQgCgEgDgCQgEgCgFAAQgIAAgFAFQgGAFAAANIAAAnIgNAAIAAhHIAMAAIAAAKQAIgMAPAAQAGAAAGACQAFADADAEQADADABAGIAAALIAAAsgABegHIAAgOIAOAAIAAAOg");
	this.shape.setTransform(44.2,12.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(12.5,7.5,63.6,10.4);


(lib.HM_harovalshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAAEvQi3AAiChZQiChZAAh9QAAh8CChZQCChZC3AAQC3AACCBZQCDBZAAB8QAAB9iDBZQiBBZi4AAIAAAAg");
	this.shape.setTransform(-8.6,-1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.9,-32.2,88.8,60.6);


(lib.HM_harovalshadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAAEvQi3AAiChZQiChZAAh9QAAh8CChZQCChZC3AAQC3AACCBZQCDBZAAB8QAAB9iDBZQiBBZi4AAIAAAAg");
	this.shape_1.setTransform(-8.6,-1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.9,-32.2,88.8,60.6);


(lib.HM_harHowtoplayhighlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.HM_harSymbol12_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ai4gRQAzgqA7gTQA8gSA6gBQA8AAAxALQAyAKAgAQQAgAQAGAOQgWgQgrgLQgrgMg7gCQg7gBhBAPQhBAPhBAlQhCAlg6BCQAkhJA0gqg");
	this.shape_1.setTransform(27.3,9.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,54.5,19.6);


(lib.HM_harSymbol11_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhCCwQg1gBgwgMQgxgLgkgXQgkgYgQgkQAfAiAuAWQAvAXA6AIQA5AJA/gIQBUgNBAglQA/gmAgg1QAgg0gKg7QgCgNABgPIAAgcQgBgOgHgLQAQASAOAXQAOAWAFAXQAIAsgRArQgQAqglAkQglAlg0AZQg0AZhAAJQgoAGgqAAIgUgBg");
	this.shape_1.setTransform(30.5,17.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,61.1,35.4);


(lib.HM_harSymbol74_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA0000").s().p("AglAeQgIgWgBgVQgBgWADgPQAEgPAHgDQABArAMAYQAMAYAPAKQAQAKAMACIAMACIgSAGQgSAGgZAKQgPgQgIgXg");
	this.shape_1.setTransform(4.7,6.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,9.4,13.9);


(lib.HM_harSymbol73_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BA0000").s().p("AAOBkIgQgdQgJgRgIgSQgHgRgDgNQgCgLgBgTQgBgTABgUQABgTADgNQACgOADgBQgCARAAAXQgBAWAFAVQAFAVANALQAOANAJARQAIARADAPQADAPgCAJIgDANQgBAGgDABIAAAAQgDAAgIgLg");
	this.shape_1.setTransform(3.3,11.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,6.7,22.3);


(lib.HM_harSymbol12_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ai4gRQAzgqA7gTQA8gSA6gBQA8AAAxALQAyAKAgAQQAgAQAGAOQgWgQgrgLQgrgMg7gCQg7gBhBAPQhBAPhBAlQhCAlg6BCQAkhJA0gqg");
	this.shape_2.setTransform(27.3,9.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,54.5,19.6);


(lib.HM_harSymbol11_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhCCwQg1gBgwgMQgxgLgkgXQgkgYgQgkQAfAiAuAWQAvAXA6AIQA5AJA/gIQBUgNBAglQA/gmAgg1QAgg0gKg7QgCgNABgPIAAgcQgBgOgHgLQAQASAOAXQAOAWAFAXQAIAsgRArQgQAqglAkQglAlg0AZQg0AZhAAJQgoAGgqAAIgUgBg");
	this.shape_2.setTransform(30.5,17.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,61.1,35.4);


(lib.HM_harspeakershadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ABeByQgBAAAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAIgDgBIgDgBIgDgBIgEgCIgMgHIgxgkIgTAGIggALIgfAKIgNAFIgDAAIgBAAQgHgBgHgKQgHgLgFgRQgEgRgBgSIgBgIIAAgPIABgcQABgPAHgHQACgEAGgBIAOAAIAhAAIAgAAIARAAIAOgRIAVgYIAOgPIABgCQAFgBAFAEQAMAHANAdQAMAcAJApIAIArIABAKIAAADIAAAEIABAbIgBAHQAAAHgDAGQgDAGgFADQgDADgEAAIgCAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.5,-11.4,23.1,22.9);


(lib.HM_harovalshadow_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAAEvQi3AAiChZQiChZAAh9QAAh8CChZQCChZC3AAQC3AACCBZQCDBZAAB8QAAB9iDBZQiBBZi4AAIAAAAg");
	this.shape_2.setTransform(-8.6,-1.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.9,-32.2,88.8,60.6);


(lib.HM_HAR_harnextcluesbuttonhilite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAmIgMgBIgKgDIgCgDIgBgDIACgJIABgCIACgBIAEABIAGADQADABAGAAQAEAAACgBQADgBAAgDQAAgDgEgCIgMgFQgIgDgFgEQgEgFAAgJQAAgHAEgFQAEgGAHgCQAHgCAIAAIAKABQAFAAAFACIACACQABABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAIgCAJIgBACIgDABIgEgBIgFgCIgHgBQgDAAgCACQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAIAFADIAJADQAJAEAEAEQAEAGAAAHQAAAJgFAFQgEAFgIADQgGACgGAAIgDAAg");
	this.shape.setTransform(14,-1.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAEAmQgSAAgLgKQgKgKAAgSQgBgLAFgIQAFgJAJgEQAIgFAKAAQANAAAIAGQAIAFADAJQAEAKAAAKQAAAAgBABQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAAAAAQgBAAgBAAQAAAAgBAAIgqAAQACAHAFADQAEAFAJAAIAIgBIAGgDIAEAAIACAAIABAEIABAIIgBACQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAIgIACIgHABIgIAAgAAOgGQAAgHgDgEQgDgDgGgBQgFABgDADQgEAEgBAHIAZAAIAAAAg");
	this.shape_1.setTransform(6.5,-1.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAlQgKAAgGgEQgGgEgDgHQgDgHABgJIAAglIAAgEQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAIAPAAQABAAABAAQAAAAABAAQAAAAABABQAAAAABAAIABAEIAAAeQAAAJACAEQADAFAFgBQAGABADgGQAEgFAAgKIAAgbQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAIAQAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABIAAA+QAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABIgDABIgQAAIgDgBIgBgEIAAgFIgBAAQgEAGgGADQgDACgGAAIgCAAg");
	this.shape_2.setTransform(-2.2,-1.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMAxQgFgFgCgIQgBgIAAgJIAAhEIABgDQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAIAPAAQAAAAAAAAQABAAAAABQABAAAAAAQABAAAAABIABADIAABGIABALQABADAEAAIAFAAIACAAIADABIABADIAAAJIgBADIgDACIgHABIgGABQgKgBgGgFg");
	this.shape_3.setTransform(-8.8,-3.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGAxQgJgCgHgHQgJgGgEgLQgFgJAAgNQAAgMAEgKQAEgKAHgHQAHgGAKgEQAJgDAMAAIAHAAIAJABIAHACQABABAAAAQABAAAAAAQABABAAAAQAAAAABABIAAADIgBAMIAAADIgDABIgEgBIgFgCIgGgCIgHAAQgHAAgFADQgEACgEAEQgEAFgCAFQgBAGAAAHQAAAHACAGQACAGAEAEQAEAEAFACQAFACAHAAIAGAAIAFgBIAGgCIADAAIADAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAIABAMQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAIgDACIgLADIgNAAQgLAAgIgDg");
	this.shape_4.setTransform(-16.2,-2.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgDAtQgGgDgCgHQgCgHAAgIIAAgbIgJAAIgEgBIgBgEIAAgIIABgEQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAAAIAJAAIAAgSQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAIAEgBIAOAAIAEABIABADIAAASIALAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAAAIABAEIAAAIIgBAEIgDABIgLAAIAAAZQAAAGACADQACADAEAAIADgBIADAAIACABIABADIAAAJIgBADIgCACIgGABIgHAAQgKABgFgEg");
	this.shape_5.setTransform(11.8,-17.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AARAlIgFgBIgDgFIgJgQIgJAQIgEAFIgFABIgPAAIgDgBIgBgDIAAgBIABgBIAXgfIgWgeIAAgCIAAAAIABgCIADgBIARAAIAFABIADAEIAHANIAHgNIADgEIAFgBIAPAAIAEABIABACIAAAAIgBACIgVAdIAYAgIAAABIAAABIgBADIgDABg");
	this.shape_6.setTransform(4.8,-16.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAFAmQgTAAgLgKQgLgKAAgSQABgLAEgIQAFgJAIgEQAJgFAKAAQAOAAAHAFQAIAGAEAJQACAKAAAKQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAIgpAAQABAHAFAEQAEADAIAAIAJAAIAGgCIAEgBIACABIABACIABAJIgBACQAAABAAAAQgBABAAAAQgBAAAAAAQgBABgBAAIgHACIgIABIgGAAgAAOgGQAAgHgDgEQgDgDgGgBQgFABgEADQgDADAAAIIAYAAIAAAAg");
	this.shape_7.setTransform(-3.4,-16.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARAyQgDAAgCgBQgBAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAgBIgdhAIAABAIgBAEQgBAAAAAAQAAABgBAAQgBAAAAAAQgBAAAAAAIgMAAQgBAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAIgBgEIAAhZIABgEIAFgBIAWAAIAFABQACABABADIAcA+IAAg+IABgEIAEgBIAMAAIAEABQABAAAAABQAAAAAAAAQABABAAABQAAAAAAABIAABZQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAgBAAQgBAAAAAAg");
	this.shape_8.setTransform(-12.9,-17.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// oval
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#612D76").s().p("AiSBNQg/gQgsgjQBlAtB/gOQBegKBNgoQBKgnAig3QgSBChHAvQhJAyhiAKQgXACgWAAQgxAAgugLg");
	this.shape_9.setTransform(1.6,-0.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.149)").s().p("AikgZQBKgyBhgKQBKgIBCARQBAAQArAjQhlgth/AOQheAKhNAoQhKAngiA3QARhCBIgvg");
	this.shape_10.setTransform(-3.9,-21);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#7C3A97").s().p("AjRCuQhkg0gJhZQgJhWBXhJQBWhHCFgOQCDgOBkA0QBkA0AJBZQAJBWhXBIQhXBJiEAOQgaACgbAAQhjAAhPgpg");
	this.shape_11.setTransform(-1.3,-10);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#B856C7").s().p("Aj4DdQg5gggiguQgjgwgGg3QgFg2AYg2QAYg0AxgrQBnhbCdgRQCdgRB4BEQB4BEALBxQAGA3gYA1QgYA0gxArQhnBcidAQQgeADgdAAQh5AAhhg2g");
	this.shape_12.setTransform(-1.6,-7.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// Layer 5
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF0000").s().p("AkeEOQhCgogog4Qgog6gHhDQgHhDAdhBQAbhAA5g1QB3hvC2gVQC1gUCLBTQCLBTANCKQAHBDgcBBQgcBAg4A1Qh3Bvi2AVQgjAEgiAAQiMAAhvhDg");
	this.shape_13.setTransform(-1.7,-7.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45.8,-41.4,88.3,67.4);


(lib.HM_HAR_harnextcluesbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgDAmIgMgBIgKgDIgCgDIgBgDIACgJIABgCIACgBIAEABIAGADQADABAGAAQAEAAACgBQADgBAAgDQAAgDgEgCIgMgFQgIgDgFgEQgEgFAAgJQAAgHAEgFQAEgGAHgCQAHgCAIAAIAKABQAFAAAFACIACACQABABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAIgCAJIgBACIgDABIgEgBIgFgCIgHgBQgDAAgCACQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAIAFADIAJADQAJAEAEAEQAEAGAAAHQAAAJgFAFQgEAFgIADQgGACgGAAIgDAAg");
	this.shape.setTransform(14,-1.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAEAmQgSAAgLgKQgKgKAAgSQgBgLAFgIQAFgJAJgEQAIgFAKAAQANAAAIAGQAIAFADAJQAEAKAAAKQAAAAgBABQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAAAAAQgBAAgBAAQAAAAgBAAIgqAAQACAHAFADQAEAFAJAAIAIgBIAGgDIAEAAIACAAIABAEIABAIIgBACQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAIgIACIgHABIgIAAgAAOgGQAAgHgDgEQgDgDgGgBQgFABgDADQgEAEgBAHIAZAAIAAAAg");
	this.shape_1.setTransform(6.5,-1.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAlQgKAAgGgEQgGgEgDgHQgDgHABgJIAAglIAAgEQABAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAIAPAAQABAAABAAQAAAAABAAQAAAAABABQAAAAABAAIABAEIAAAeQAAAJACAEQADAFAFgBQAGABADgGQAEgFAAgKIAAgbQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAIAQAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABIAAA+QAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABIgDABIgQAAIgDgBIgBgEIAAgFIgBAAQgEAGgGADQgDACgGAAIgCAAg");
	this.shape_2.setTransform(-2.2,-1.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMAxQgFgFgCgIQgBgIAAgJIAAhEIABgDQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAIAPAAQAAAAAAAAQABAAAAABQABAAAAAAQABAAAAABIABADIAABGIABALQABADAEAAIAFAAIACAAIADABIABADIAAAJIgBADIgDACIgHABIgGABQgKgBgGgFg");
	this.shape_3.setTransform(-8.8,-3.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGAxQgJgCgHgHQgJgGgEgLQgFgJAAgNQAAgMAEgKQAEgKAHgHQAHgGAKgEQAJgDAMAAIAHAAIAJABIAHACQABABAAAAQABAAAAAAQABABAAAAQAAAAABABIAAADIgBAMIAAADIgDABIgEgBIgFgCIgGgCIgHAAQgHAAgFADQgEACgEAEQgEAFgCAFQgBAGAAAHQAAAHACAGQACAGAEAEQAEAEAFACQAFACAHAAIAGAAIAFgBIAGgCIADAAIADAAQAAAAAAABQABAAAAAAQAAABAAAAQAAABAAAAIABAMQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAIgDACIgLADIgNAAQgLAAgIgDg");
	this.shape_4.setTransform(-16.2,-2.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgDAtQgGgDgCgHQgCgHAAgIIAAgbIgJAAIgEgBIgBgEIAAgIIABgEQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAAAIAJAAIAAgSQAAAAAAgBQAAAAAAgBQAAAAABgBQAAAAAAAAIAEgBIAOAAIAEABIABADIAAASIALAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAAAIABAEIAAAIIgBAEIgDABIgLAAIAAAZQAAAGACADQACADAEAAIADgBIADAAIACABIABADIAAAJIgBADIgCACIgGABIgHAAQgKABgFgEg");
	this.shape_5.setTransform(11.8,-17.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AARAlIgFgBIgDgFIgJgQIgJAQIgEAFIgFABIgPAAIgDgBIgBgDIAAgBIABgBIAXgfIgWgeIAAgCIAAAAIABgCIADgBIARAAIAFABIADAEIAHANIAHgNIADgEIAFgBIAPAAIAEABIABACIAAAAIgBACIgVAdIAYAgIAAABIAAABIgBADIgDABg");
	this.shape_6.setTransform(4.8,-16.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAFAmQgTAAgLgKQgLgKAAgSQABgLAEgIQAFgJAIgEQAJgFAKAAQAOAAAHAFQAIAGAEAJQACAKAAAKQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAIgpAAQABAHAFAEQAEADAIAAIAJAAIAGgCIAEgBIACABIABACIABAJIgBACQAAABAAAAQgBABAAAAQgBAAAAAAQgBABgBAAIgHACIgIABIgGAAgAAOgGQAAgHgDgEQgDgDgGgBQgFABgEADQgDADAAAIIAYAAIAAAAg");
	this.shape_7.setTransform(-3.4,-16.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARAyQgDAAgCgBQgBAAAAgBQgBAAAAgBQAAAAgBgBQAAAAAAgBIgdhAIAABAIgBAEQgBAAAAAAQAAABgBAAQgBAAAAAAQgBAAAAAAIgMAAQgBAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAIgBgEIAAhZIABgEIAFgBIAWAAIAFABQACABABADIAcA+IAAg+IABgEIAEgBIAMAAIAEABQABAAAAABQAAAAAAAAQABABAAABQAAAAAAABIAABZQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAAAgBAAQAAABgBAAQAAAAgBAAQgBAAAAAAg");
	this.shape_8.setTransform(-12.9,-17.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// oval
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#612D76").s().p("AiSBNQg/gQgsgjQBlAtB/gOQBegKBNgoQBKgnAig3QgSBChHAvQhJAyhiAKQgXACgWAAQgxAAgugLg");
	this.shape_9.setTransform(1.6,-0.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(255,255,255,0.149)").s().p("AikgZQBKgyBhgKQBKgIBCARQBAAQArAjQhlgth/AOQheAKhNAoQhKAngiA3QARhCBIgvg");
	this.shape_10.setTransform(-3.9,-21);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#7C3A97").s().p("AjRCuQhkg0gJhZQgJhWBXhJQBWhHCFgOQCDgOBkA0QBkA0AJBZQAJBWhXBIQhXBJiEAOQgaACgbAAQhjAAhPgpg");
	this.shape_11.setTransform(-1.3,-10);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#B856C7").s().p("Aj4DdQg5gggiguQgjgwgGg3QgFg2AYg2QAYg0AxgrQBnhbCdgRQCdgRB4BEQB4BEALBxQAGA3gYA1QgYA0gxArQhnBcidAQQgeADgdAAQh5AAhhg2g");
	this.shape_12.setTransform(-1.6,-7.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// shadow
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(0,0,0,0.4)").s().p("Aj4DdQg5gggiguQgjgwgGg3QgFg2AYg2QAYg0AxgrQBnhbCdgRQCdgRB4BEQB4BEALBxQAGA3gYA1QgYA0gxArQhnBcieAQQgdADgeAAQh4AAhhg2g");
	this.shape_13.setTransform(2.7,-2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_13).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.8,-35.2,80.7,60.4);


(lib.HM_HAR_harmystnumgreenclue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#225501").ss(1,1,1).p("A0KDZIAAmxQAAgMAJgJQAIgJANAAMAnZAAAQANAAAIAJQAJAJAAAMIAAGxQAAAMgJAJQgIAJgNAAMgnZAAAQgNAAgIgJQgJgJAAgMg");
	this.shape.setTransform(0.5,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#6ADB0E","#28A900"],[0,1],0,-24.6,0,24.7).s().p("AgRD3IAAntIAiAAIAAHtg");
	this.shape_1.setTransform(-98.8,-0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FFFFFF","#C5FFC5"],[0,1],0,-24.6,0,24.7).s().p("AgRD3IAAntIAiAAIAAHtg");
	this.shape_2.setTransform(-95.3,-0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#A4FF86","#6EDC12"],[0,1],0,-24.6,0,24.7).s().p("AhtD3QgMAAgJgJQgJgJAAgMIAAmxQAAgMAJgJQAJgJAMAAID5AAIAAHtg");
	this.shape_3.setTransform(-114.6,-0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#FFFFFF","#AFFE8D"],[0,1],0,-24.9,0,24.9).s().p("AxejzMAifgAFQAMAAAJAJQAJAIAAANIAAGwQAAANgJAIQgJAJgMAAMgifAAFg");
	this.shape_4.setTransform(17.8,0.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#009F00","#A6FDAD"],[0,1],-8.5,-48.3,8.6,48.4).s().p("Az8ERQgRAAgLgMQgMgLAAgRIAAnRQAAgRAMgMQALgLARAAMAn5AAAQAQAAAMALQAMAMAAARIAAHRQAAARgMALQgMAMgQAAg");
	this.shape_5.setTransform(0.5,-0.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#81E551","#3AD42B"],[0,1],-81.4,-81.4,81.4,81.4).s().p("AzuE8QhhAAAAhgIAAm3QAAhgBhAAMAndAAAQBhAAgBBgIAAG3QABBghhAAg");
	this.shape_6.setTransform(0.5,-0.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#C5FFC5","#1CAC00"],[0,1],-82.1,-82.1,82.1,82.1).s().p("AzuFHQhrAAAAhrIAAm3QAAhrBrAAMAndAAAQBrAAAABrIAAG3QAABrhrAAg");
	this.shape_7.setTransform(0.5,-0.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#225501").ss(1,1,1).p("A2BD4IAAnwQAAgyAjgkQAkgjAyAAMAoRAAAQAyAAAkAjQAjAkAAAyIAAHwQAAAzgjAjQgkAkgyAAMgoRAAAQgyAAgkgkQgjgjAAgzg");
	this.shape_8.setTransform(0.5,0);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#C1FDAB","#199F00"],[0,1],-10.2,-58.1,10.3,58.1).s().p("A0IFyQgyAAgkgkQgjgkAAgxIAAnxQAAgyAjgjQAkgkAyAAMAoRAAAQAyAAAkAkQAjAjAAAyIAAHxQAAAxgjAkQgkAkgyAAg");
	this.shape_9.setTransform(0.5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-141.5,-38,284.1,76);


(lib.HM_HAR_harmystnumgamepanel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFB500","#FF9000"],[0,1],-120,-120,120.1,120.1).s().p("Aq8Z7QgogBgdgcQgdgcAAgpMAAAgwxQAAgoAdgdQAdgdAoAAIV6AAQAoAAAdAdQAcAdAAAoMAAAAwxQAAApgcAcQgdAcgoABg");
	this.shape.setTransform(0.5,-0.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FFF258","#FFBB00"],[0,1],-121.1,-121.1,121.1,121.1).s().p("Aq8aKQgvAAghghQghghAAgvMAAAgwxQAAgvAhghQAhghAvAAIV6AAQAuAAAhAhQAhAhAAAvMAAAAwxQAAAvghAhQghAhguAAg");
	this.shape_1.setTransform(0.5,-0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#720D09").ss(1,1,1).p("ALUbKI2nAAQg+AAgsgsQgsgtAAg+MAAAgxmQAAg+AsgsQAsgsA+AAIWnAAQA/AAArAsQAsAsAAA+MAAAAxmQAAA/gsAsQgsAsg+AAg");
	this.shape_2.setTransform(0.5,-0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFC038","#FF8D00"],[0,1],-126.2,-126.2,126.2,126.2).s().p("ArTbJQg+AAgsgsQgsgsAAg+MAAAgxlQAAg/AsgrQAsgsA+gBIWnAAQA/ABArAsQAsArAAA/MAAAAxlQAAA/gsArQgsAsg+AAg");
	this.shape_3.setTransform(0.5,-0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#BC9A85","#FFFFCC"],[0,1],-130.3,-130.2,130.3,130.4).s().p("ArbcCQhQAAg6g5Qg5g5AAhRMAAAgx9QAAhQA5g6QA6g5BQAAIW2AAQBRAAA6A5QA5A6AABQMAAAAx9QAABRg5A5Qg6A5hRAAg");
	this.shape_4.setTransform(0.5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-92.1,-179.4,185.4,358.8);


(lib.HM_HAR_harmystnumcluepanelhilite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#720D09").ss(1,1,1).p("EA1zAFPQgkAjgyAAMho5AAAQgyAAgkgjQgjgkAAgyIAAnwQAAgzAjgjQAkgkAyAAMBo5AAAQAyAAAkAkQAjAjAAAzIAAHwQAAAygjAkg");
	this.shape.setTransform(0.3,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFCC").s().p("Eg0cAFyQgyAAgjgjQgkgkAAgyIAAnwQAAgzAkgkQAjgjAyAAMBo4AAAQAzAAAkAjQAjAkAAAzIAAHwQAAAygjAkQgkAjgzAAg");
	this.shape_1.setTransform(0.3,-0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#BC9A85","#FFFFCC"],[0,1],-194.5,-194.5,194.6,194.6).s().p("Eg02AG4QhEAAgvgwQgwgwAAhEIAAonQAAhEAwgwQAvgwBEAAMBptAAAQBDAAAwAwQAwAwAABEIAAInQAABEgwAwQgwAwhDAAg");
	this.shape_2.setTransform(0.5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("Eg02AG4QhEAAgvgwQgwgwAAhEIAAonQAAhEAwgwQAvgwBEAAMBptAAAQBDAAAwAwQAwAwAABEIAAInQAABEgwAwQgwAwhDAAg");
	this.shape_3.setTransform(0.5,0,1.017,1.135);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-360.3,-50,721.7,100);


(lib.HM_HAR_harmystnumcluepanel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#720D09").ss(1,1,1).p("EA1zAFPQgkAjgyAAMho5AAAQgyAAgkgjQgjgkAAgyIAAnwQAAgzAjgjQAkgkAyAAMBo5AAAQAyAAAkAkQAjAjAAAzIAAHwQAAAygjAkg");
	this.shape.setTransform(0.3,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFCC").s().p("Eg0cAFyQgyAAgjgjQgkgkAAgyIAAnwQAAgzAkgkQAjgjAyAAMBo4AAAQAzAAAkAjQAjAkAAAzIAAHwQAAAygjAkQgkAjgzAAg");
	this.shape_1.setTransform(0.3,-0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#BC9A85","#FFFFCC"],[0,1],-194.5,-194.5,194.6,194.6).s().p("Eg02AG4QhEAAgvgwQgwgwAAhEIAAonQAAhEAwgwQAvgwBEAAMBptAAAQBDAAAwAwQAwAwAABEIAAInQAABEgwAwQgwAwhDAAg");
	this.shape_2.setTransform(0.5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-354.1,-44,709.3,88.1);


(lib.HM_HAR_harmystnumblueclue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#002A4C").ss(1,1,1).p("ATtD3MgnZAAAQgNAAgJgJQgIgJAAgMIAAmxQAAgMAIgJQAJgJANAAMAnZAAAQANAAAIAJQAJAJAAAMIAAGxQAAAMgJAJQgIAJgNAAg");
	this.shape.setTransform(0.5,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#74C7FF","#037CDC"],[0,1],0,-24.6,0,24.7).s().p("AgRD3IAAntIAiAAIAAHtg");
	this.shape_1.setTransform(-98.8,-0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FFFFFF","#E5FDFF"],[0,1],0,-24.6,0,24.7).s().p("AgRD3IAAntIAiAAIAAHtg");
	this.shape_2.setTransform(-95.3,-0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#A9E6FF","#1C9AFF"],[0,1],0,-24.6,0,24.7).s().p("AhtD3QgMAAgJgJQgJgJAAgMIAAmxQAAgMAJgJQAJgJAMAAID5AAIAAHtg");
	this.shape_3.setTransform(-114.6,-0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#FFFFFF","#B7EFFF"],[0,1],0,-24.9,0,24.9).s().p("AxejzMAifgAFQAMAAAJAJQAJAIAAANIAAGwQAAANgJAIQgJAJgMAAMgifAAFg");
	this.shape_4.setTransform(17.8,0.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#0360DC","#A9E6FF"],[0,1],-8.5,-48.3,8.6,48.4).s().p("Az8ERQgRAAgLgMQgMgLAAgRIAAnRQAAgRAMgMQALgLARAAMAn5AAAQARAAALALQAMAMAAARIAAHRQAAARgMALQgLAMgRAAg");
	this.shape_5.setTransform(0.5,-0.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#1C9AFF","#71C5FF"],[0,1],-81.4,-81.4,81.4,81.4).s().p("AzuE8QhgAAgBhgIAAm3QABhgBgAAMAndAAAQBhAAgBBgIAAG3QABBghhAAg");
	this.shape_6.setTransform(0.5,-0.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#B8F0FF","#68B1FF"],[0,1],-82.1,-82.1,82.1,82.1).s().p("AzuFHQhqAAAAhrIAAm3QAAhrBqAAMAndAAAQBqAAAABrIAAG3QAABrhqAAg");
	this.shape_7.setTransform(0.5,-0.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#002A4C").ss(1,1,1).p("AVfFOQgkAkgyAAMgoRAAAQgyAAgkgkQgjgjAAgzIAAnwQAAgyAjgkQAkgjAyAAMAoRAAAQAyAAAkAjQAjAkAAAyIAAHwQAAAzgjAjg");
	this.shape_8.setTransform(0.5,0);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#74C7FF","#037CDC"],[0,1],-85.4,-85.4,85.5,85.5).s().p("A0HFyQgzAAgkgkQgjgkAAgxIAAnxQAAgyAjgjQAkgkAzAAMAoPAAAQAzAAAkAkQAjAjAAAyIAAHxQAAAxgjAkQgkAkgzAAg");
	this.shape_9.setTransform(0.5,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-141.5,-38,284,76);


(lib.HM_HAR_harcolumnidle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#8A0000").ss(0.7,1,1).p("AiYBNIAAiZQAAgQALgLQALgLAPAAIDnAAQAPAAALALQALALAAAQIAACZQAAAQgLALQgLALgPAAIjnAAQgPAAgLgLQgLgLAAgQg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FF8080","#FFCCCC"],[0,1],-10.1,-10,10.1,10.2).s().p("AhvBRQgJABgHgHQgGgGAAgKIAAh1QAAgKAGgGQAHgHAJAAIDfAAQAJAAAHAHQAGAGAAAKIAAB1QAAAKgGAGQgHAHgJgBg");
	this.shape_1.setTransform(0,-1.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FFFFFF","#FF8080"],[0,1],-12.2,-11,12.3,11.1).s().p("AhyBkQgQAAgKgLQgLgLAAgPIAAh9QAAgPALgLQAKgLAQAAIDlAAQAQAAAKALQALALAAAPIAAB9QAAAPgLALQgKALgQAAg");
	this.shape_2.setTransform(0,-1.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFB3B3","#FF4C4C"],[0,1],-15.2,0,15.3,0).s().p("AhyBkQgQAAgKgLQgLgLAAgPIAAh9QAAgPALgLQAKgLAQAAIDlAAQAQAAAKALQALALAAAPIAAB9QAAAPgLALQgKALgQAAg");
	this.shape_3.setTransform(0,1.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.4,32.5,24.9);


(lib.HM_digithilite5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(4.5,1,1).p("ACHnzIAAPnIkNAAIAAvng");
	this.shape.setTransform(13.4,49,0.992,0.978,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.2,-2.2,31.3,102.3);


(lib.harSymbol63 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.harfeedbackpanely4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;


(lib.grfeedbackpaneloutliney4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = getMCSymbolPrototype(lib.grfeedbackpaneloutliney4, null, null);


(lib.mcfeedbackgfxpanelYG4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.grfeedbackpaneloutliney4();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1,1,0,0,0,251,39.5);
	this.instance.filters = [new cjs.ColorFilter(0.85, 0.85, 0.85, 1, 38.25, 38.25, 38.25, 0)];

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF99").s().p("AgCgCIABgBIAEAGIgFgFg");
	this.shape.setTransform(-239.6,-30.9);

	this.instance_1 = new lib.harfeedbackpanely4("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-249.4,-38,1.04,1.04);
	this.instance_1.alpha = 0.379;

	this.instance_2 = new lib.harSymbol63("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-249.4,-38,1.04,1.04);
	this.instance_2.alpha = 0.059;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mcfeedbackgfxpanelYG4, new cjs.Rectangle(-239.9,-31.3,0.6,0.7), null);


(lib.harYr4instructionboxbkg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.instance = new lib.Path();
	this.instance.parent = this;
	this.instance.setTransform(7.4,-36,1,1,0,0,0,259.8,3.6);
	this.instance.alpha = 0.301;

	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#3C3C3D","#1F1F1F","#2A2828"],[0,0.827,1],-253.5,0,253.6,0).s().p("EghVAF8Qg0gBgogdQgngdgRgvQgEgGgCgNIAAgBIAAgDIgCgUIgGg3QgDgfgJggQgIghgRgcQgRgdgcgUQgngYgdgWQgegWgUgZQgUgZgKgfQgKggABgsQABgoAagkQAagjAqgXQAqgWAygBIArAAIAuAAIDIAAIEnAAIFxAAIGrAAIHQAAIHlAAIHkAAIHUAAIGxAAIF7AAIExAAIDXAAIBpAAIAHAAIABAAQArABAkAVQAjAVAVAjQAPAZAEAeQACAMAAAMIAAG9QAAAsgVAjQgVAkgjAUQgkAVgrABg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-253.5,-37.9,507.1,76);


(lib.HM_mcnumberToggle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{active:0});

	// timeline functions:
	this.frame_0 = function() {
		/* 
		clipStatus = "active"
		numberDisplay = this._name.charAt(4)
		
		//get vars used when calling _root function
		colName = _parent._name
		col = colName.charAt(3)
		numberValue = numberDisplay
		
		stop()
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// number
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgaBJIgNgDQgBAAAAgBQgBAAAAAAQgBAAAAgBQAAAAAAAAIgBgEIABgKIABgCIACgBQADAAADACIAIADQAFACAIAAQAKAAAHgDQAIgDAFgFQAFgGAAgIQAAgNgJgHQgJgGgPAAIgKAAQAAAAgBAAQAAAAgBAAQgBgBAAAAQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBIAAgFQAAgBAAgBQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQABAAAAgBQABAAAAAAQABAAABAAIAIAAQAHAAAHgBQAIgDAFgFQAFgGAAgJQAAgIgEgEQgEgFgGgDQgGgBgHAAIgOABIgJAEIgHACIgBAAIgBgDIgBgKQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQAHgEAJgCQAIgBAJAAQAMAAAKADQALAFAGAIQAGAIAAANQAAAKgEAHQgEAHgHAEQgHAFgIACQAJABAHADQAHAEAFAIQAEAHAAAMQAAALgFAIQgFAHgIAFQgIAFgKACQgJACgLAAIgOgBg");
	this.shape.setTransform(25.3,11);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// gfx
	this.instance = new lib.HM_mcclipwhite();
	this.instance.parent = this;
	this.instance.setTransform(25.8,10.2,1,1,0,0,0,15.7,11.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.HM_mcnumberToggle, new cjs.Rectangle(1,-3.3,49.2,29), null);


(lib.HM_mcmysteryDigitCliphilitecopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"static":0});

	// timeline functions:
	this.frame_0 = function() {
		/* stop()*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// number
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgnBEQgRgTAAgtQAAgwATgXQAQgUAaAAQAUAAANAMQANALADAUIgVACQgDgNgFgFQgJgJgMAAQgJAAgIAFQgKAHgGAOQgGAOAAAaQAIgLALgGQALgGALAAQAVAAAPAQQAPAOAAAZQAAAQgHAOQgHAOgMAHQgNAIgPAAQgZAAgRgUgAgWACQgJAKAAARQAAALAEAKQAFAKAIAFQAIAFAJAAQANAAAKgKQAJgLAAgTQAAgSgJgKQgKgJgOAAQgOAAgKAJg");
	this.shape.setTransform(24.9,14.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// gfx
	this.instance = new lib.HM_mcmystnumdigitbackwhite();
	this.instance.parent = this;
	this.instance.setTransform(25.2,15.8,1,1,0,0,0,14,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.HM_mcmysteryDigitCliphilitecopy, new cjs.Rectangle(1.1,-2.3,47.8,36.3), null);


(lib.HM_mcmysteryDigitCliphilite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"static":0});

	// timeline functions:
	this.frame_0 = function() {
		/* stop()*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// 
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF0000").ss(4.5,1,1).p("ACjjJIAAGTIlFAAIAAmTg");
	this.shape.setTransform(25.3,15.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// number
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgnBEQgRgTAAgtQAAgwATgXQAQgUAaAAQAUAAANAMQANALADAUIgVACQgDgNgFgFQgJgJgMAAQgJAAgIAFQgKAHgGAOQgGAOAAAaQAIgLALgGQALgGALAAQAVAAAPAQQAPAOAAAZQAAAQgHAOQgHAOgMAHQgNAIgPAAQgZAAgRgUgAgWACQgJAKAAARQAAALAEAKQAFAKAIAFQAIAFAJAAQANAAAKgKQAJgLAAgTQAAgSgJgKQgKgJgOAAQgOAAgKAJg");
	this.shape_1.setTransform(24.9,14.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// gfx
	this.instance = new lib.HM_mcmystnumdigitbackwhite();
	this.instance.parent = this;
	this.instance.setTransform(25.2,15.8,1,1,0,0,0,14,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.HM_mcmysteryDigitCliphilite, new cjs.Rectangle(1.1,-6.9,47.8,44.9), null);


(lib.HM_mcmysteryDigitClip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"static":0});

	// timeline functions:
	this.frame_0 = function() {
		/* stop()*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// number
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgQBVQgEgFgBgHQABgHAEgEQAFgFAGAAQAHAAAEAFQAFAEAAAHQAAAHgFAFQgEAEgHAAQgGAAgFgEgAgJAmQgDAAgCgCQgCgCABgDIAAgVQgBgEACgDIAEgFIAMgMQAIgGAFgIQAFgHABgJQgBgLgGgFQgHgGgLAAIgRACIgLAEIgIACIgCgBIAAgDIgBgMIABgFQAAAAAAAAQAAgBAAAAQABAAAAgBQABAAAAAAIANgEIANgCIAOgBQAMAAAKAFQALAEAFAKQAGAJABANQAAAMgFAJQgFAKgHAHIgQAOIgEAFIgCAGIAAAPQAAADgBACQAAABgBAAQAAAAgBAAQAAABgBAAQgBAAAAAAg");
	this.shape.setTransform(25,15.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// gfx
	this.instance = new lib.HM_mcmystnumdigitbackwhite();
	this.instance.parent = this;
	this.instance.setTransform(25.2,15.8,1,1,0,0,0,14,18.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.HM_mcmysteryDigitClip, new cjs.Rectangle(1.1,-2.3,47.8,36.3), null);


(lib.HM_harredlozenge = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.HM_harSymbol12_1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-30.6,-23.4);
	this.instance.alpha = 0.34;

	this.instance_1 = new lib.HM_harSymbol11_1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-27.5,-13.9);
	this.instance_1.alpha = 0.121;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#AA0000").s().p("AhgDtQhDgJg3gaQg2gagjgnQgjgngKgyQgJgwAUgvQATguAqgoQArgnA8gbQA9gbBJgKQBJgKBDAKQBDAJA3AaQA2AaAjAnQAjAnAKAyQAIAwgTAvQgTAugqAoQgrAng8AbQg9AbhJAKQglAFgiAAQgjAAgigFg");
	this.shape.setTransform(0.6,-1.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E45466").s().p("AhxEcQhPgLhAgfQhAgegqgtQgpgugMg6QgKg6AXg3QAXg5AygwQAygwBHgiQBHghBXgNQBVgLBPANQBPANBAAgQBBAhApAvQApAwAMA6QAKA4gXA3QgXA3gyAtQgyAuhHAgQhHAghXAMQgsAGgpAAQgpAAgmgFgAgLjlQhbANhEAoQhEAngiA4QgiA4AKA9QAJAvAhAkQAgAlAyAYQAzAZA+AJQA9AJBDgJQBbgNBEgoQBEgnAig4QAig4gKg9QgJgvghgkQggglgzgYQgygZg+gJQgfgFggAAQggAAghAFg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF9900").s().p("AhcDtQhCgKg0gaQg2gaghgnQgjgogKgxQgIgwASgvQATguApgnQApgnA7gbQA6gbBHgKQBHgKBBAKQBCAKA1AaQA0AaAjAoQAiAnAJAxQAJAxgTAuQgSAvgpAnQgoAng8AbQg6AahHAKQgjAFghAAQgjAAghgFg");
	this.shape_2.setTransform(-0.4,-1.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.8,-28.9,83.8,57.9);


(lib.HM_harspeakerup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#9F4900").s().p("AgBAxQgIgSgGgcQgGgbABgUQAAgUAHgCQAHAAAIARQAIASAGAdQAGAbgBAUQgBAUgGACIgBAAQgGAAgIgSg");
	this.shape.setTransform(-1.8,1.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#BD4900").s().p("AABAwQgOgVgDgWQgDgVADgQIADgRIAAALIADAaQADAPAGAQQAGAQANALIgJADIgEABIgEgCg");
	this.shape_1.setTransform(-11.4,3.7);

	this.instance = new lib.HM_harSymbol74("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-20.1,-3.6);
	this.instance.alpha = 0.199;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#BD4900").s().p("AgRAmQgMgngCgiQgCgjACgVIADgXIALACIgDAWQgDAVACAhQACAhAMAlQALAnAdAjIgJAHQgcglgNgog");
	this.shape_2.setTransform(-1.3,0.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFF00").s().p("AgIAuQgIgUgEgeQgFg8ARgBQAIgBAIAOQAJANADAfQADAegDAVQgDAVgIACQgJAAgIgUg");
	this.shape_3.setTransform(-17.6,3.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFF00").s().p("AAuBoIgngNIgigOIgPgGIgfheIAMgLIAdgaIAggdIAWgVIgDAYQgCAPABAWQABAWAHAhQAGAbAGARQAGASAJAOQAIANANAPQgJAAgTgGg");
	this.shape_4.setTransform(-6,0.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFF00").s().p("Ag+hBIBBAGIA8BaIhrAjg");
	this.shape_5.setTransform(-12.2,3.3);

	this.instance_1 = new lib.HM_harSymbol73("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-4.1,-10.5);
	this.instance_1.alpha = 0.199;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FEB849").s().p("AAIBZQgIgNgJgZQgKgYgHgeQgUhcAWgFQAMgDANAVQAOAWALAuQAHAeACAZQACAagCAQQgDAQgHACIgBAAQgHAAgJgMg");
	this.shape_6.setTransform(-1,1.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BD4900").s().p("ABjB5IgDAAIgagGIgjgLIgigMIgVgHIgQAFIgZAHIgMAEIADgCIgEACIgFACQgFACgJgGQgLgKgHgWQgHgVgCgXQgGgxANgPQAGgHAIgBIAJABIgCgBIAMACIAYACIASACIAUgTIAbgZIAagWQALgKADgBQAFgCAKAFQAKAHAKASQAJASAIAXQAHAXAFAVIAEAXQAEATABAXQACAXgEASQgEATgNADIgEAAgAgQA/IAjANIAtAOQAWAHAMADQADgGABgWQAAgbgKgvQgKgsgLgXQgLgYgGgFIgTAQIgaAYIgXAWIgNALIgDAEIhAgGIgCgBIgCAEQgCAFAAAQIABAXQADAbAGAQQAGAPAEADIAAAAIA9gTg");
	this.shape_7.setTransform(-8.6,0.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#BD4900").s().p("ABhBuQgKgBgTgGIgngNIgigLIgPgGIg5ASIgDACQgJAAgJgUQgIgVgEgfQgFg7ARgBIAEABIA7AGIAOgNIAcgaIAegbIAOgMQAHgBAKAOQAJANAJAYQAJAYAHAfQAHAeACAaQACAagCAQQgDAQgHACIgEgBg");
	this.shape_8.setTransform(-8.6,0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.instance_1},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.instance},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.9,-11.5,24.5,24.3);


(lib.HM_harredlozengehighlight11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.HM_harSymbol12_1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-30.6,-23.4);
	this.instance.alpha = 0.34;

	this.instance_1 = new lib.HM_harSymbol11_1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-27.5,-13.9);
	this.instance_1.alpha = 0.121;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C51F34").s().p("AhgDtQhDgJg3gaQg2gagjgnQgjgngKgyQgJgwAUgvQATguAqgoQArgnA8gbQA9gbBJgKQBJgKBDAKQBDAJA3AaQA2AaAjAnQAjAnAKAyQAIAwgTAvQgTAugqAoQgrAng8AbQg9AbhJAKQglAFgiAAQgjAAgigFg");
	this.shape.setTransform(0.6,-1.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E45466").s().p("AhxEcQhPgLhAgfQhAgegqgtQgpgugMg6QgKg6AXg3QAXg5AygwQAygwBHgiQBHghBXgNQBVgLBPANQBPANBAAgQBBAhApAvQApAwAMA6QAKA4gXA3QgXA3gyAtQgyAuhHAgQhHAghXAMQgsAGgpAAQgpAAgmgFgAgLjlQhbANhEAoQhEAngiA4QgiA4AKA9QAJAvAhAkQAgAlAyAYQAzAZA+AJQA9AJBDgJQBbgNBEgoQBEgnAig4QAig4gKg9QgJgvghgkQggglgzgYQgygZg+gJQgfgFggAAQggAAghAFg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF9900").s().p("AhcDtQhCgKg0gaQg2gaghgnQgjgogKgxQgIgwASgvQATguApgnQApgnA7gbQA6gbBHgKQBHgKBBAKQBCAKA1AaQA0AaAjAoQAiAnAJAxQAJAxgTAuQgSAvgpAnQgoAng8AbQg6AahHAKQgjAFghAAQgjAAghgFg");
	this.shape_2.setTransform(-0.4,-1.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.8,-28.9,83.8,57.9);


(lib.HM_harorangelozenge = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.HM_harSymbol12("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-9.2,-7,0.3,0.3);
	this.instance.alpha = 0.34;

	this.instance_1 = new lib.HM_harSymbol11("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-8.2,-4.2,0.3,0.3);
	this.instance_1.alpha = 0.121;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF7200").s().p("AgcBHQgUgDgQgHQgRgIgKgMQgLgMgDgPQgCgOAFgNQAGgOANgMQANgMASgIQASgIAWgDQAVgDAUADQAUADARAHQAQAIALAMQAKAMADAPQACANgFAOQgGAOgNAMQgMAMgTAIQgSAIgWADIgUACQgLAAgKgCg");
	this.shape.setTransform(0.2,-0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF9500").s().p("AghBVQgYgDgTgKQgUgJgMgNQgMgOgEgRQgDgSAHgQQAHgQAPgPQAPgOAVgKQAWgLAZgDQAZgEAYAEQAYAEATAKQATAKANAOQAMAOAEARQADARgHAQQgHARgPANQgPAOgWAKQgVAJgaAEQgNACgLAAQgNAAgLgCgAgDhEQgbAEgUAMQgVAMgKAQQgKARADASQADAOAJALQAKALAPAHQAPAHATADQARADAVgDQAbgEAUgMQAVgMAKgQQAKgRgDgSQgDgOgKgLQgJgLgPgHQgPgHgTgDIgTgBIgTABg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF9900").s().p("AgbBHQgUgDgQgHQgPgJgLgLQgKgMgDgPQgCgOAFgOQAGgOAMgLQAMgMASgIQARgIAWgDQAUgDAUADQATADAQAIQAQAHALANQAKALADAPQACAOgFAOQgGAOgMAMQgMALgSAIQgSAIgVADIgUACQgKAAgKgCg");
	this.shape_2.setTransform(-0.1,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.5,-8.6,25.2,17.3);


(lib.HM_harhowtoplayhighlight = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVA7QgFAAABgDIAAgBIABgBIANghIgdhKIgBgBIAAgBQABgDAEAAIAQAAIAGABQABABABADIANAsIABAAIAMgsQABgDADgBIAEgBIAPAAQAFAAgBADIAAABIAAABIgoBrQgBADgCABQgBABgDAAg");
	this.shape.setTransform(15.4,5.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgaAjQgIgGgDgJQgEgJAAgLQAAgLAEgJQAEgJAIgGQAHgFAKAAQAIAAAFADQAFACAEAFIABAAIAAgDQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIADgBIARAAIAEABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABIAABDQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAIgEABIgQAAIgEgBIgBgEIAAgEIgBAAQgEAGgGACQgFADgGAAQgMAAgIgGgAgGgRQgEADgBAFQgCAEAAAFQAAAJAEAGQAEAFAHAAQAEAAADgCQAEgDACgEIAAgWQgCgEgDgCQgEgDgEABQgEAAgEACg");
	this.shape_1.setTransform(5.9,3.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgNA1QgGgGgBgIQgCgJAAgKIAAhIQAAgBABAAQAAgBAAgBQAAAAAAgBQABAAAAgBIAEgBIAQAAIADABQAAABABAAQAAABAAAAQAAABAAABQAAAAAAABIAABLQAAAHABAEQACAEAEAAIAEAAIAEgBIADABIAAAEIAAAJQABABAAAAQAAABAAAAQgBAAAAAAQAAABAAAAIgEADIgHABIgHABQgLgBgGgFg");
	this.shape_2.setTransform(-1,1.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgkA7QAAAAgBAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBIAAhpQAAgBAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBIAEgBIAQAAIAEABQAAABAAAAQABABAAAAQAAABAAAAQAAABAAABIAAAFQAEgGAHgDQAFgDAIgBQAMAAAHAHQAHAFAEAJQADAKAAAMQAAAKgEAIQgDAJgIAFQgHAGgLAAQgIABgFgDQgGgDgEgEIAAApQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAQgBAAgBAAgAgIgiQgDACgCAEQgBAFAAAFQAAAJAEAGQADAEAHABQAHgBAEgEQADgFAAgJQAAgKgEgFQgDgFgHgBQgEAAgEAEg");
	this.shape_3.setTransform(-8.9,5.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgVAkQgKgEgGgJQgGgKAAgNQAAgMAGgJQAGgKAKgEQAJgFAMAAQAMAAAKAFQAKAEAGAKQAFAJABAMQgBANgFAKQgGAJgKAEQgKAFgMAAQgMAAgJgFgAgIgRQgEADgBAFQgCAFAAAEQAAAFACAFQABAEAEADQADAEAFAAQAFAAAEgEQADgDACgEIACgKIgCgJQgCgFgDgDQgEgDgFAAQgFAAgDADg");
	this.shape_4.setTransform(25.9,-8.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgDAwQgGgEgDgHQgCgHAAgJIAAgdIgKAAIgDgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIAAgIQAAgBAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIADgBIAKAAIAAgTQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQAAgBABAAQABAAAAAAQABAAAAAAIAQAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQAAAAAAABQABAAAAABQAAAAAAABIAAATIALAAIAEABIABAFIAAAIIgBAEIgEABIgLAAIAAAbQAAAHACADQACADAEAAIAEAAIADgBIACABIABADIAAAKIgBADQAAABAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAIgHACIgHAAQgLAAgFgEg");
	this.shape_5.setTransform(17.9,-9.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AASAnQAAAAgBAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQgCgCgBgDIgLgsIgKAsQAAADgCACQgCABgDAAIgSAAQgDAAgCgBIgDgFIgShAIgBgCIAAgCIABgCIAEgBIAPAAIAFABQACABAAAEIAKAuIAAAAIAKguQABgEACgBIAFgBIAPAAIAFABQACABABAEIAJAuIABAAIAKguQAAgEACgBIAFgBIAPAAIAEABIABACIgBACIAAACIgSBAQgBADgCACQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAgBAAg");
	this.shape_6.setTransform(4.2,-8.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVAkQgKgEgGgJQgGgKAAgNQAAgMAGgJQAGgKAKgEQAJgFAMAAQAMAAAKAFQAKAEAGAKQAFAJABAMQgBANgFAKQgGAJgKAEQgKAFgMAAQgMAAgJgFgAgIgRQgEADgBAFQgCAFAAAEQAAAFACAFQABAEAEADQADAEAFAAQAFAAAEgEQADgDACgEIACgKIgCgJQgCgFgDgDQgEgDgFAAQgFAAgDADg");
	this.shape_7.setTransform(-7.2,-8.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAYA2QgBAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBIAAgnIgjAAIAAAnIgBAFQAAAAgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgQAAQgBAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBIAAhfQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAgBQABAAAAAAQABAAABAAIAQAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABIABAEIAAAjIAjAAIAAgjQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAgBQABAAAAAAQABAAABAAIAPAAQABAAABAAQAAAAABAAQAAABABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAABQAAAAAAABIAABfQAAABAAABQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAgBAAg");
	this.shape_8.setTransform(-17.7,-10.1);

	this.instance = new lib.HM_harredlozenge("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(1.8,-3.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 3
	this.instance_1 = new lib.HM_harHowtoplayhighlight("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(2.9,-6.6,1.104,1.124);

	this.instance_2 = new lib.HM_harredlozengehighlight11("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(1.8,-3.5,1.15,1.171);
	this.instance_2.filters = [new cjs.ColorFilter(0, 0, 0, 1, 255, 0, 0, 0)];
	this.instance_2.cache(-44,-31,88,62);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	// Layer 2
	this.instance_3 = new lib.HM_harovalshadow_1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(15.3,4.2);
	this.instance_3.alpha = 0.371;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.3,-37.4,97.5,69.9);


(lib.HM_harhowtoplay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgVA7QgFAAABgDIAAgBIABgBIANghIgdhKIgBgBIAAgBQABgDAEAAIAQAAIAGABQABABABADIANAsIABAAIAMgsQABgDADgBIAEgBIAPAAQAFAAgBADIAAABIAAABIgoBrQgBADgCABQgBABgDAAg");
	this.shape.setTransform(15.4,5.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgaAjQgIgGgDgJQgEgJAAgLQAAgLAEgJQAEgJAIgGQAHgFAKAAQAIAAAFADQAFACAEAFIABAAIAAgDQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIADgBIARAAIAEABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABIAABDQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAIgEABIgQAAIgEgBIgBgEIAAgEIgBAAQgEAGgGACQgFADgGAAQgMAAgIgGgAgGgRQgEADgBAFQgCAEAAAFQAAAJAEAGQAEAFAHAAQAEAAADgCQAEgDACgEIAAgWQgCgEgDgCQgEgDgEABQgEAAgEACg");
	this.shape_1.setTransform(5.9,3.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgNA1QgGgGgBgIQgCgJAAgKIAAhIQAAgBABAAQAAgBAAgBQAAAAAAgBQABAAAAgBIAEgBIAQAAIADABQAAABABAAQAAABAAAAQAAABAAABQAAAAAAABIAABLQAAAHABAEQACAEAEAAIAEAAIAEgBIADABIAAAEIAAAJQABABAAAAQAAABAAAAQgBAAAAAAQAAABAAAAIgEADIgHABIgHABQgLgBgGgFg");
	this.shape_2.setTransform(-1,1.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgkA7QAAAAgBAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBIAAhpQAAgBAAgBQAAAAAAgBQAAAAABgBQAAAAAAgBIAEgBIAQAAIAEABQAAABAAAAQABABAAAAQAAABAAAAQAAABAAABIAAAFQAEgGAHgDQAFgDAIgBQAMAAAHAHQAHAFAEAJQADAKAAAMQAAAKgEAIQgDAJgIAFQgHAGgLAAQgIABgFgDQgGgDgEgEIAAApQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAQgBAAgBAAgAgIgiQgDACgCAEQgBAFAAAFQAAAJAEAGQADAEAHABQAHgBAEgEQADgFAAgJQAAgKgEgFQgDgFgHgBQgEAAgEAEg");
	this.shape_3.setTransform(-8.9,5.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgVAkQgKgEgGgJQgGgKAAgNQAAgMAGgJQAGgKAKgEQAJgFAMAAQAMAAAKAFQAKAEAGAKQAFAJABAMQgBANgFAKQgGAJgKAEQgKAFgMAAQgMAAgJgFgAgIgRQgEADgBAFQgCAFAAAEQAAAFACAFQABAEAEADQADAEAFAAQAFAAAEgEQADgDACgEIACgKIgCgJQgCgFgDgDQgEgDgFAAQgFAAgDADg");
	this.shape_4.setTransform(25.9,-8.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgDAwQgGgEgDgHQgCgHAAgJIAAgdIgKAAIgDgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIAAgIQAAgBAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIADgBIAKAAIAAgTQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQAAgBABAAQABAAAAAAQABAAAAAAIAQAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABAAAAABQAAAAAAABQABAAAAABQAAAAAAABIAAATIALAAIAEABIABAFIAAAIIgBAEIgEABIgLAAIAAAbQAAAHACADQACADAEAAIAEAAIADgBIACABIABADIAAAKIgBADQAAABAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAIgHACIgHAAQgLAAgFgEg");
	this.shape_5.setTransform(17.9,-9.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AASAnQAAAAgBAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQgCgCgBgDIgLgsIgKAsQAAADgCACQgCABgDAAIgSAAQgDAAgCgBIgDgFIgShAIgBgCIAAgCIABgCIAEgBIAPAAIAFABQACABAAAEIAKAuIAAAAIAKguQABgEACgBIAFgBIAPAAIAFABQACABABAEIAJAuIABAAIAKguQAAgEACgBIAFgBIAPAAIAEABIABACIgBACIAAACIgSBAQgBADgCACQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAgBAAg");
	this.shape_6.setTransform(4.2,-8.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVAkQgKgEgGgJQgGgKAAgNQAAgMAGgJQAGgKAKgEQAJgFAMAAQAMAAAKAFQAKAEAGAKQAFAJABAMQgBANgFAKQgGAJgKAEQgKAFgMAAQgMAAgJgFgAgIgRQgEADgBAFQgCAFAAAEQAAAFACAFQABAEAEADQADAEAFAAQAFAAAEgEQADgDACgEIACgKIgCgJQgCgFgDgDQgEgDgFAAQgFAAgDADg");
	this.shape_7.setTransform(-7.2,-8.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAYA2QgBAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBIAAgnIgjAAIAAAnIgBAFQAAAAgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgQAAQgBAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBIAAhfQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAgBQABAAAAAAQABAAABAAIAQAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABIABAEIAAAjIAjAAIAAgjQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAAAQABgBAAAAQABAAAAgBQABAAAAAAQABAAABAAIAPAAQABAAABAAQAAAAABAAQAAABABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAABQAAAAAAABIAABfQAAABAAABQAAAAAAABQAAAAgBABQAAAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAgBAAg");
	this.shape_8.setTransform(-17.7,-10.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.instance = new lib.HM_harredlozenge("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(1.8,-3.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 2
	this.instance_1 = new lib.HM_harovalshadow_1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(15.3,4.2);
	this.instance_1.alpha = 0.371;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40,-32.6,91.2,65.2);


(lib.HM_harspeakerup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9F4900").s().p("AgBAxQgIgSgGgcQgGgbABgUQAAgUAHgCQAHAAAIARQAIASAGAdQAGAbgBAUQgBAUgGACIgBAAQgGAAgIgSg");
	this.shape_9.setTransform(-1.8,1.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BD4900").s().p("AABAwQgOgVgDgWQgDgVADgQIADgRIAAALIADAaQADAPAGAQQAGAQANALIgJADIgEABIgEgCg");
	this.shape_10.setTransform(-11.4,3.7);

	this.instance_2 = new lib.HM_harSymbol74_1("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-20.1,-3.6);
	this.instance_2.alpha = 0.199;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#BD4900").s().p("AgRAmQgMgngCgiQgCgjACgVIADgXIALACIgDAWQgDAVACAhQACAhAMAlQALAnAdAjIgJAHQgcglgNgog");
	this.shape_11.setTransform(-1.3,0.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFF00").s().p("AgIAuQgIgUgEgeQgFg8ARgBQAIgBAIAOQAJANADAfQADAegDAVQgDAVgIACQgJAAgIgUg");
	this.shape_12.setTransform(-17.6,3.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFF00").s().p("AAuBoIgngNIgigOIgPgGIgfheIAMgLIAdgaIAggdIAWgVIgDAYQgCAPABAWQABAWAHAhQAGAbAGARQAGASAJAOQAIANANAPQgJAAgTgGg");
	this.shape_13.setTransform(-6,0.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFF00").s().p("Ag+hBIBBAGIA8BaIhrAjg");
	this.shape_14.setTransform(-12.2,3.3);

	this.instance_3 = new lib.HM_harSymbol73_1("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-4.1,-10.5);
	this.instance_3.alpha = 0.199;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FEB849").s().p("AAIBZQgIgNgJgZQgKgYgHgeQgUhcAWgFQAMgDANAVQAOAWALAuQAHAeACAZQACAagCAQQgDAQgHACIgBAAQgHAAgJgMg");
	this.shape_15.setTransform(-1,1.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#BD4900").s().p("ABjB5IgDAAIgagGIgjgLIgigMIgVgHIgQAFIgZAHIgMAEIADgCIgEACIgFACQgFACgJgGQgLgKgHgWQgHgVgCgXQgGgxANgPQAGgHAIgBIAJABIgCgBIAMACIAYACIASACIAUgTIAbgZIAagWQALgKADgBQAFgCAKAFQAKAHAKASQAJASAIAXQAHAXAFAVIAEAXQAEATABAXQACAXgEASQgEATgNADIgEAAgAgQA/IAjANIAtAOQAWAHAMADQADgGABgWQAAgbgKgvQgKgsgLgXQgLgYgGgFIgTAQIgaAYIgXAWIgNALIgDAEIhAgGIgCgBIgCAEQgCAFAAAQIABAXQADAbAGAQQAGAPAEADIAAAAIA9gTg");
	this.shape_16.setTransform(-8.6,0.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#BD4900").s().p("ABhBuQgKgBgTgGIgngNIgigLIgPgGIg5ASIgDACQgJAAgJgUQgIgVgEgfQgFg7ARgBIAEABIA7AGIAOgNIAcgaIAegbIAOgMQAHgBAKAOQAJANAJAYQAJAYAHAfQAHAeACAaQACAagCAQQgDAQgHACIgEgBg");
	this.shape_17.setTransform(-8.6,0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.instance_3},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.instance_2},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.9,-11.5,24.5,24.3);


(lib.HM_harorangelozenge_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance_2 = new lib.HM_harSymbol12_2("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-9.2,-7,0.3,0.3);
	this.instance_2.alpha = 0.34;

	this.instance_3 = new lib.HM_harSymbol11_2("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-8.2,-4.2,0.3,0.3);
	this.instance_3.alpha = 0.121;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF7200").s().p("AgcBHQgUgDgQgHQgRgIgKgMQgLgMgDgPQgCgOAFgNQAGgOANgMQANgMASgIQASgIAWgDQAVgDAUADQAUADARAHQAQAIALAMQAKAMADAPQACANgFAOQgGAOgNAMQgMAMgTAIQgSAIgWADIgUACQgLAAgKgCg");
	this.shape_3.setTransform(0.2,-0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF9500").s().p("AghBVQgYgDgTgKQgUgJgMgNQgMgOgEgRQgDgSAHgQQAHgQAPgPQAPgOAVgKQAWgLAZgDQAZgEAYAEQAYAEATAKQATAKANAOQAMAOAEARQADARgHAQQgHARgPANQgPAOgWAKQgVAJgaAEQgNACgLAAQgNAAgLgCgAgDhEQgbAEgUAMQgVAMgKAQQgKARADASQADAOAJALQAKALAPAHQAPAHATADQARADAVgDQAbgEAUgMQAVgMAKgQQAKgRgDgSQgDgOgKgLQgJgLgPgHQgPgHgTgDIgTgBIgTABg");

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF9900").s().p("AgbBHQgUgDgQgHQgPgJgLgLQgKgMgDgPQgCgOAFgOQAGgOAMgLQAMgMASgIQARgIAWgDQAUgDAUADQATADAQAIQAQAHALANQAKALADAPQACAOgFAOQgGAOgMAMQgMALgSAIQgSAIgVADIgUACQgKAAgKgCg");
	this.shape_5.setTransform(-0.1,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.instance_3},{t:this.instance_2}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.5,-8.6,25.2,17.3);


(lib.HM_HAR_harthousandsbuttonnew = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// button
	this.instance = new lib.HM_HAR_harcolumnidle("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.4,32.5,24.9);


(lib.HM_mysteryNumberhilite = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape.setTransform(57.3,13.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 2
	this.mysteryDigitClip = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip.name = "mysteryDigitClip";
	this.mysteryDigitClip.parent = this;
	this.mysteryDigitClip.setTransform(13.6,13,0.75,0.75,0,0,0,25,15);

	this.mysteryDigitClip_1 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_1.name = "mysteryDigitClip_1";
	this.mysteryDigitClip_1.parent = this;
	this.mysteryDigitClip_1.setTransform(71.4,13.2,0.75,0.75,0,0,0,25,15);

	this.mysteryDigitClip_2 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_2.name = "mysteryDigitClip_2";
	this.mysteryDigitClip_2.parent = this;
	this.mysteryDigitClip_2.setTransform(99.9,13.2,0.75,0.75,0,0,0,25,15);

	this.mysteryDigitClip_3 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_3.name = "mysteryDigitClip_3";
	this.mysteryDigitClip_3.parent = this;
	this.mysteryDigitClip_3.setTransform(42.4,13,0.75,0.75,0,0,0,25,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.mysteryDigitClip_3},{t:this.mysteryDigitClip_2},{t:this.mysteryDigitClip_1},{t:this.mysteryDigitClip}]}).wait(1));

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF0000").ss(4.5,1,1).p("AIxieIAAE9IxhAAIAAk9g");
	this.shape_1.setTransform(57.2,13.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFB000").s().p("AowCfIAAk9IRhAAIAAE9g");
	this.shape_2.setTransform(57.2,13.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.HM_mysteryNumberhilite, new cjs.Rectangle(-4.3,-4.4,122.2,36.3), null);


(lib.HM_mctable_6cols = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{show4:0});

	// timeline functions:
	this.frame_0 = function() {
		/* stop()
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// cols
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AghAvQgMgNAAgZIAAg/IABgEIADgBIAIAAIADABIABAEIAAA9QAAASAIAKQAHAKAOAAQAPAAAHgKQAIgKAAgSIAAg9IABgEIADgBIAIAAIADABIABAEIAAA/QAAAZgMANQgMAMgWAAQgVAAgMgMg");
	this.shape.setTransform(134.2,44.3);

	this.instance = new lib.HM_HAR_harthousandsbuttonnew("single",0);
	this.instance.parent = this;
	this.instance.setTransform(134.2,44.8);

	this.mysteryDigitClip = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip.name = "mysteryDigitClip";
	this.mysteryDigitClip.parent = this;
	this.mysteryDigitClip.setTransform(134,10,1,1,0,0,0,25,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAgBJQgBAAAAAAQgBAAgBAAQAAAAAAgBQgBAAAAAAIgBgFIAAg6IgBAAQgFAFgHADQgHADgJAAQgNAAgKgGQgKgGgFgJQgFgKAAgNQAAgNAFgLQAFgLAKgGQAJgHAPAAQAIAAAHADQAHADAGAFIAAgDIABgEQAAgBABAAQAAAAAAAAQABgBABAAQAAAAABAAIAJAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABIABAEIAACDIgBAFQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAgAgMgzQgFAEgDAHQgDAHAAAIQAAAIACAGQADAHAGAEQAFADAHAAQAMAAAHgGQAHgIABgNQAAgJgDgHQgDgHgGgEQgFgEgJAAQgHAAgGAEg");
	this.shape_1.setTransform(133.9,299.5);

	this.instance_1 = new lib.HM_mcclipwhite();
	this.instance_1.parent = this;
	this.instance_1.setTransform(134.8,298.9,1,1,0,0,0,15.7,11.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgXBGQgMgEgGgJQgIgJAAgOQAAgJAEgHQAFgIAHgFQAGgFAJgDIAAAAQgOgFgHgJQgGgJAAgNQAAgMAHgHQAGgIALgEQAKgDAMAAQAKAAALADQAKAEAGAHQAHAIAAALQAAANgGAJQgHAIgMAGIAAAAQAHAEAHADQAHAFAEAIQAEAHAAAJQAAAOgHAKQgGAJgMAFQgLAEgNAAQgNAAgKgEgAgOALQgGAEgDAFQgDAFgBAIQABAIAEAFQADAGAHADQAHACAGAAQAHAAAGgCQAGgDADgFQAEgFABgHQgBgJgEgGQgDgFgHgEIgQgHIgLAHgAgMg2QgFACgEAEQgDAEAAAHQgBAGAFAFQAEAFAHAEIANAHIAJgHQAFgEACgEQADgFAAgHQAAgGgDgFQgEgEgFgCQgGgCgFAAQgGAAgGACg");
	this.shape_2.setTransform(134.6,274.4);

	this.instance_2 = new lib.HM_mcclipwhite();
	this.instance_2.parent = this;
	this.instance_2.setTransform(134.8,273.6,1,1,0,0,0,15.7,11.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgZBIIgDgBIgBgDIAAgBIAAgBIAzh2Ig9AAIgDgBQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBIAAgHQAAgBAAAAQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAIBPAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQABABAAABQAAAAAAABIAAAFIgBADIgBAFIgxB2QgBAEgCABIgFABg");
	this.shape_3.setTransform(134.4,249.1);

	this.instance_3 = new lib.HM_mcclipwhite();
	this.instance_3.parent = this;
	this.instance_3.setTransform(134.8,248.3,1,1,0,0,0,15.7,11.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgYBDQgLgIgGgRQgFgQgBgaQABgUAHgSQAGgQAOgKQANgJARgBQAIAAAGACIALADIADACIAAADIAAAKIgBADIgCABIgFgCIgHgDIgLgBQgLAAgHAFQgHAFgFAHQgFAHgCAJQgCAKAAAJQAGgHAIgDQAIgDAJAAQAMgBAKAGQAKAFAFAKQAGAKAAAOQAAAOgGAKQgFALgKAGQgLAGgOABQgPgBgLgHgAgKADQgGADgDAHQgEAHAAAIQAAAIADAGQADAHAGAFQAFADAIABQAIgBAGgDQAGgFACgHQADgGAAgJQAAgHgDgHQgCgGgGgEQgFgDgIgBQgHABgGADg");
	this.shape_4.setTransform(134.6,223.8);

	this.instance_4 = new lib.HM_mcclipwhite();
	this.instance_4.parent = this;
	this.instance_4.setTransform(134.8,223,1,1,0,0,0,15.7,11.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgaBIIgNgDIgDgDIAAgDIABgKIABgCIACgBIAFACIAIADQAFABAJAAQAKAAAGgDQAIgEAEgGQAFgHAAgJQAAgQgKgHQgJgGgPAAIgLABIgHABIgFAAQgBAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgCAAgDIABg9QAAgBAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQABAAABAAIBDAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAIABAFIAAAHIgBAEIgEABIg0AAIgBAmIAJgCIAJgBQAMAAAKAFQALAFAGAJQAGAKAAAPQAAAPgHALQgHALgMAGQgNAFgPAAIgPgBg");
	this.shape_5.setTransform(134.6,198.6);

	this.instance_5 = new lib.HM_mcclipwhite();
	this.instance_5.parent = this;
	this.instance_5.setTransform(134.8,197.7,1,1,0,0,0,15.7,11.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AATBIQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBIgBgEIAAgaIg9AAIgEgBQAAgBAAAAQAAgBgBAAQAAAAAAgBQAAgBAAAAIAAgIIABgEIABgDIA1hWIADgEIAEgBIAMAAIAEABIAAACIAAACIgBACIg3BWIAsAAIAAgeIABgEQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAIAKAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAAAABIACAEIAAAeIAOAAIAEABQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAABIAAAHQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIgOAAIAAAaIgCAEQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAg");
	this.shape_6.setTransform(134.4,173.2);

	this.instance_6 = new lib.HM_mcclipwhite();
	this.instance_6.parent = this;
	this.instance_6.setTransform(134.8,172.4,1,1,0,0,0,15.7,11.8);

	this.clip3 = new lib.HM_mcnumberToggle();
	this.clip3.name = "clip3";
	this.clip3.parent = this;
	this.clip3.setTransform(134,146.9,1,1,0,0,0,25,10);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgnBJQgBAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAgBIAAgHIACgFQABgDADgDIAUgSQAKgJAJgJQAJgKAFgJQAHgKAAgMQAAgJgEgFQgEgGgGgCQgGgDgHAAQgIAAgHACIgJACIgHACIgBgBIgBgCIAAgKIAAgEIADgCIAKgDIAMgCIAMgBQANAAAKAFQAKAFAHAJQAFAJAAAOQAAAMgFALQgGALgJAKIgUAWIgVATIA6AAQABAAABAAQAAAAABAAQAAAAABABQAAAAAAAAIACAEIAAAHIgCAFQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAg");
	this.shape_7.setTransform(134.1,122.4);

	this.instance_7 = new lib.HM_mcclipwhite();
	this.instance_7.parent = this;
	this.instance_7.setTransform(134.8,121.8,1,1,0,0,0,15.7,11.8);

	this.clip1 = new lib.HM_mcnumberToggle();
	this.clip1.name = "clip1";
	this.clip1.parent = this;
	this.clip1.setTransform(134,96.3,1,1,0,0,0,25,10);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgYBDQgJgGgFgLQgGgLgCgNQgCgNAAgNQAAgLACgOQACgMAGgMQAFgKAJgIQAKgGAOAAQAPAAAJAGQAKAIAFAKQAFAMACAMQADAOgBALQABANgDANQgCANgFALQgFALgKAGQgJAHgPAAQgOAAgKgHgAgPgwQgGAGgDANQgDANAAAQQAAASADAMQADANAGAGQAGAHAJAAQAJAAAHgHQAGgGADgNQADgMAAgSQAAgQgDgNQgDgNgGgGQgHgHgJAAQgJAAgGAHg");
	this.shape_8.setTransform(134.5,72);

	this.instance_8 = new lib.HM_mcclipwhite();
	this.instance_8.parent = this;
	this.instance_8.setTransform(134.8,71.2,1,1,0,0,0,15.7,11.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgEAxQgGgIAAgPIAAgpIgMAAIgEgBIgBgEIAAgDIABgEIAEgBIAMAAIAAgWIABgEIADgBIAGAAIADABIABAEIAAAWIATAAIADABIABAEIAAADIgBAEIgDABIgTAAIAAAnQAAAKADAFQAEAEAGAAIAFgBIAEAAIABAAIABADIAAAGIgBADIgCABIgEABIgEAAQgPAAgGgHg");
	this.shape_9.setTransform(172.1,44.7);

	this.instance_9 = new lib.HM_HAR_harthousandsbuttonnew("single",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(172.2,44.8);

	this.mysteryDigitClip_1 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_1.name = "mysteryDigitClip_1";
	this.mysteryDigitClip_1.parent = this;
	this.mysteryDigitClip_1.setTransform(172,10,1,1,0,0,0,25,15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAgBJQgBAAAAAAQgBAAgBAAQAAAAAAgBQgBAAAAAAIgBgFIAAg6IgBAAQgFAFgHADQgHADgJAAQgNAAgKgGQgKgGgFgJQgFgKAAgNQAAgNAFgLQAFgLAKgGQAJgHAPAAQAIAAAHADQAHADAGAFIAAgDIABgEQAAgBABAAQAAAAAAAAQABgBABAAQAAAAABAAIAJAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABIABAEIAACDIgBAFQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAgAgMgzQgFAEgDAHQgDAHAAAIQAAAIACAGQADAHAGAEQAFADAHAAQAMAAAHgGQAHgIABgNQAAgJgDgHQgDgHgGgEQgFgEgJAAQgHAAgGAEg");
	this.shape_10.setTransform(171.9,299.5);

	this.instance_10 = new lib.HM_mcclipwhite();
	this.instance_10.parent = this;
	this.instance_10.setTransform(172.8,298.9,1,1,0,0,0,15.7,11.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgYBGQgLgEgGgJQgIgJAAgOQAAgJAFgHQADgIAIgFQAGgFAJgDIAAAAQgOgFgHgJQgGgJAAgNQAAgMAHgHQAGgIALgEQALgDALAAQAKAAAKADQALAEAGAHQAHAIAAALQAAANgHAJQgGAIgMAGIAAAAQAHAEAHADQAHAFAEAIQAFAHgBAJQAAAOgHAKQgGAJgMAFQgLAEgNAAQgMAAgMgEgAgPALQgFAEgEAFQgCAFgBAIQABAIADAFQAEAGAHADQAGACAHAAQAHAAAGgCQAGgDADgFQAEgFABgHQAAgJgFgGQgDgFgIgEIgPgHIgMAHgAgMg2QgFACgEAEQgDAEAAAHQAAAGAEAFQAEAFAHAEIANAHIAJgHQAEgEADgEQADgFAAgHQAAgGgDgFQgEgEgFgCQgGgCgFAAQgGAAgGACg");
	this.shape_11.setTransform(172.6,274.4);

	this.instance_11 = new lib.HM_mcclipwhite();
	this.instance_11.parent = this;
	this.instance_11.setTransform(172.8,273.6,1,1,0,0,0,15.7,11.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgZBIIgDgBIgBgDIAAgBIAAgBIAzh2Ig9AAIgDgBQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBIAAgHQAAgBAAAAQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAIBPAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQABABAAABQAAAAAAABIAAAFIgBADIgBAFIgxB2QgBAEgCABIgFABg");
	this.shape_12.setTransform(172.4,249.1);

	this.instance_12 = new lib.HM_mcclipwhite();
	this.instance_12.parent = this;
	this.instance_12.setTransform(172.8,248.3,1,1,0,0,0,15.7,11.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgYBDQgLgIgGgRQgFgQgBgaQABgUAHgSQAGgQAOgKQANgJARgBQAIAAAGACIALADIADACIAAADIAAAKIgBADIgCABIgFgCIgHgDIgLgBQgLAAgHAFQgHAFgFAHQgFAHgCAJQgCAKAAAJQAGgHAIgDQAIgDAJAAQAMgBAKAGQAKAFAFAKQAGAKAAAOQAAAOgGAKQgFALgKAGQgLAGgOABQgPgBgLgHgAgKADQgGADgDAHQgEAHAAAIQAAAIADAGQADAHAGAFQAFADAIABQAIgBAGgDQAGgFACgHQADgGAAgJQAAgHgDgHQgCgGgGgEQgFgDgIgBQgHABgGADg");
	this.shape_13.setTransform(172.6,223.8);

	this.instance_13 = new lib.HM_mcclipwhite();
	this.instance_13.parent = this;
	this.instance_13.setTransform(172.8,223,1,1,0,0,0,15.7,11.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgaBIIgNgDIgDgDIAAgDIABgKIABgCIACgBIAFACIAIADQAFABAJAAQAKAAAGgDQAIgEAEgGQAFgHAAgJQAAgQgKgHQgJgGgPAAIgLABIgHABIgFAAQgBAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgCAAgDIABg9QAAgBAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAABAAIBDAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAIABAFIAAAHIgBAEIgEABIg0AAIgBAmIAJgCIAJgBQAMAAAKAFQALAFAGAJQAGAKAAAPQAAAPgHALQgHALgMAGQgNAFgPAAIgPgBg");
	this.shape_14.setTransform(172.6,198.6);

	this.instance_14 = new lib.HM_mcclipwhite();
	this.instance_14.parent = this;
	this.instance_14.setTransform(172.8,197.7,1,1,0,0,0,15.7,11.8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AATBIQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBIgBgEIAAgaIg9AAIgEgBQAAgBAAAAQAAgBgBAAQAAAAAAgBQAAgBAAAAIAAgIIABgEIABgDIA1hWIADgEIAEgBIANAAIADABIAAACIAAACIgBACIg3BWIAsAAIAAgeIABgEQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAIAJAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABIABAEIAAAeIAOAAIAEABQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAABIAAAHQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIgOAAIAAAaIgBAEQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_15.setTransform(172.4,173.2);

	this.instance_15 = new lib.HM_mcclipwhite();
	this.instance_15.parent = this;
	this.instance_15.setTransform(172.8,172.4,1,1,0,0,0,15.7,11.8);

	this.clip3_1 = new lib.HM_mcnumberToggle();
	this.clip3_1.name = "clip3_1";
	this.clip3_1.parent = this;
	this.clip3_1.setTransform(172,146.9,1,1,0,0,0,25,10);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgoBJQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAgBIAAgHIABgFQABgDADgDIAVgSQAJgJAJgJQAJgKAFgJQAHgKAAgMQAAgJgEgFQgEgGgGgCQgGgDgHAAQgIAAgHACIgJACIgGACIgCgBIgBgCIgBgKIABgEIADgCIAKgDIAMgCIAMgBQANAAAKAFQAKAFAHAJQAFAJABAOQgBAMgFALQgGALgJAKIgVAWIgTATIA5AAQABAAABAAQAAAAABAAQAAAAABABQAAAAABAAIABAEIAAAHIgBAFQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAg");
	this.shape_16.setTransform(172.1,122.4);

	this.instance_16 = new lib.HM_mcclipwhite();
	this.instance_16.parent = this;
	this.instance_16.setTransform(172.8,121.8,1,1,0,0,0,15.7,11.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgEBIQAAAAgBAAQgBAAAAAAQgBgBAAAAQAAAAgBAAIgBgFIAAiDIABgFQABAAAAAAQAAAAABgBQAAAAABAAQABAAAAAAIAJAAQAAAAABAAQAAAAABAAQABABAAAAQAAAAABAAIABAFIAACDIgBAFQgBAAAAAAQAAAAgBABQgBAAAAAAQgBAAAAAAg");
	this.shape_17.setTransform(172.5,97.3);

	this.instance_17 = new lib.HM_mcclipwhite();
	this.instance_17.parent = this;
	this.instance_17.setTransform(172.8,96.5,1,1,0,0,0,15.7,11.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgYBDQgJgGgFgLQgGgLgCgNQgCgNAAgNQAAgLACgOQACgMAGgMQAFgKAJgIQAKgGAOAAQAPAAAJAGQAKAIAFAKQAFAMACAMQADAOgBALQABANgDANQgCANgFALQgFALgKAGQgJAHgPAAQgOAAgKgHgAgPgwQgGAGgDANQgDANAAAQQAAASADAMQADANAGAGQAGAHAJAAQAJAAAHgHQAGgGADgNQADgMAAgSQAAgQgDgNQgDgNgGgGQgHgHgJAAQgJAAgGAHg");
	this.shape_18.setTransform(172.5,72);

	this.instance_18 = new lib.HM_mcclipwhite();
	this.instance_18.parent = this;
	this.instance_18.setTransform(172.8,71.2,1,1,0,0,0,15.7,11.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgCA6IgEAAIgBgEIAAhgIggAAIgEgBIgBgFIAAgFIABgEIAEgBIBQAAIACABIABAEIAAAFIgBAFIgCABIghAAIAABgIgBAEIgDAAg");
	this.shape_19.setTransform(95.2,44.2);

	this.instance_19 = new lib.HM_HAR_harthousandsbuttonnew("single",0);
	this.instance_19.parent = this;
	this.instance_19.setTransform(95.2,44.8);

	this.mysteryDigitClip_2 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_2.name = "mysteryDigitClip_2";
	this.mysteryDigitClip_2.parent = this;
	this.mysteryDigitClip_2.setTransform(95,10,1,1,0,0,0,25,15);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAgBJQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAIgBgFIAAg6IgBAAQgFAFgHADQgHADgJAAQgNAAgKgGQgKgGgFgJQgFgKAAgNQAAgNAFgLQAFgLAKgGQAJgHAPAAQAIAAAHADQAHADAGAFIAAgDIABgEQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAIAJAAQABAAAAAAQABAAABABQAAAAAAAAQABAAAAABIABAEIAACDIgBAFQAAAAgBAAQAAABAAAAQgBAAgBAAQAAAAgBAAgAgMgzQgFAEgDAHQgDAHAAAIQAAAIACAGQADAHAGAEQAFADAHAAQAMAAAHgGQAHgIABgNQAAgJgDgHQgDgHgGgEQgFgEgJAAQgHAAgGAEg");
	this.shape_20.setTransform(94.9,299.5);

	this.instance_20 = new lib.HM_mcclipwhite();
	this.instance_20.parent = this;
	this.instance_20.setTransform(95.8,298.9,1,1,0,0,0,15.7,11.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgYBGQgLgEgHgJQgGgJAAgOQAAgJADgHQAEgIAHgFQAHgFAJgDIAAAAQgOgFgGgJQgHgJAAgNQAAgMAHgHQAGgIALgEQAKgDALAAQALAAALADQAJAEAHAHQAGAIABALQAAANgHAJQgGAIgNAGIAAAAQAJAEAGADQAHAFAEAIQAFAHAAAJQgBAOgGAKQgIAJgKAFQgMAEgNAAQgNAAgLgEgAgPALQgFAEgEAFQgCAFgBAIQAAAIAFAFQAEAGAGADQAHACAGAAQAHAAAGgCQAGgDAEgFQADgFAAgHQAAgJgDgGQgEgFgHgEIgQgHIgMAHgAgLg2QgGACgDAEQgFAEAAAHQAAAGAFAFQAEAFAHAEIANAHIAJgHQAEgEADgEQADgFAAgHQAAgGgEgFQgDgEgGgCQgFgCgFAAQgGAAgFACg");
	this.shape_21.setTransform(95.6,274.4);

	this.instance_21 = new lib.HM_mcclipwhite();
	this.instance_21.parent = this;
	this.instance_21.setTransform(95.8,273.6,1,1,0,0,0,15.7,11.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgZBIIgDgBIgBgDIAAgBIAAgBIAzh2Ig9AAIgDgBQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBIAAgHQAAgBAAAAQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAIBPAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQABABAAABQAAAAAAABIAAAFIgBADIgBAFIgxB2QgBAEgCABIgFABg");
	this.shape_22.setTransform(95.4,249.1);

	this.instance_22 = new lib.HM_mcclipwhite();
	this.instance_22.parent = this;
	this.instance_22.setTransform(95.8,248.3,1,1,0,0,0,15.7,11.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgYBDQgLgIgGgRQgFgQgBgaQABgUAHgSQAGgQAOgKQANgJARgBQAIAAAGACIALADIADACIAAADIAAAKIgBADIgCABIgFgCIgHgDIgLgBQgLAAgHAFQgHAFgFAHQgFAHgCAJQgCAKAAAJQAGgHAIgDQAIgDAJAAQAMgBAKAGQAKAFAFAKQAGAKAAAOQAAAOgGAKQgFALgKAGQgLAGgOABQgPgBgLgHgAgKADQgGADgDAHQgEAHAAAIQAAAIADAGQADAHAGAFQAFADAIABQAIgBAGgDQAGgFACgHQADgGAAgJQAAgHgDgHQgCgGgGgEQgFgDgIgBQgHABgGADg");
	this.shape_23.setTransform(95.6,223.8);

	this.instance_23 = new lib.HM_mcclipwhite();
	this.instance_23.parent = this;
	this.instance_23.setTransform(95.8,223,1,1,0,0,0,15.7,11.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgaBIIgNgDIgDgDIAAgDIABgKIABgCIACgBIAFACIAIADQAFABAJAAQAKAAAGgDQAIgEAEgGQAFgHAAgJQAAgQgKgHQgJgGgPAAIgLABIgHABIgFAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgCAAgDIABg9QAAgBAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAAAAAQABAAABAAIBDAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAIABAFIAAAHIgBAEIgEABIg0AAIgBAmIAJgCIAJgBQAMAAAKAFQALAFAGAJQAGAKAAAPQAAAPgHALQgHALgMAGQgNAFgPAAIgPgBg");
	this.shape_24.setTransform(95.6,198.6);

	this.instance_24 = new lib.HM_mcclipwhite();
	this.instance_24.parent = this;
	this.instance_24.setTransform(95.8,197.7,1,1,0,0,0,15.7,11.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AATBIQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBIgBgEIAAgaIg9AAIgDgBQgBgBAAAAQAAgBgBAAQAAAAAAgBQAAgBAAAAIAAgIIABgEIABgDIA1hWIADgEIAFgBIAMAAIACABIABACIAAACIgBACIg3BWIAsAAIAAgeIABgEQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAIAKAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAAAABIABAEIAAAeIAPAAIADABQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABIAAAHQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIgPAAIAAAaIgBAEQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAg");
	this.shape_25.setTransform(95.4,173.2);

	this.instance_25 = new lib.HM_mcclipwhite();
	this.instance_25.parent = this;
	this.instance_25.setTransform(95.8,172.4,1,1,0,0,0,15.7,11.8);

	this.clip3_2 = new lib.HM_mcnumberToggle();
	this.clip3_2.name = "clip3_2";
	this.clip3_2.parent = this;
	this.clip3_2.setTransform(95,146.9,1,1,0,0,0,25,10);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgnBJQgBAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAgBIAAgHIACgFQABgDADgDIAVgSQAKgJAIgJQAIgKAHgJQAFgKABgMQAAgJgEgFQgEgGgGgCQgGgDgHAAQgJAAgFACIgKACIgHACIgBgBIgBgCIAAgKIAAgEIADgCIAKgDIAMgCIAMgBQANAAAKAFQALAFAFAJQAGAJAAAOQAAAMgFALQgGALgJAKIgVAWIgUATIA7AAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAIABAEIAAAHIgBAFQAAAAAAAAQgBABAAAAQgBAAAAAAQgBAAAAAAg");
	this.shape_26.setTransform(95.1,122.4);

	this.instance_26 = new lib.HM_mcclipwhite();
	this.instance_26.parent = this;
	this.instance_26.setTransform(95.8,121.8,1,1,0,0,0,15.7,11.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgEBIQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAIgBgFIAAiDIABgFQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAAAIAJAAQAAAAABAAQABAAAAAAQABABAAAAQAAAAABAAIABAFIAACDIgBAFQgBAAAAAAQAAAAgBABQAAAAgBAAQgBAAAAAAg");
	this.shape_27.setTransform(95.5,97.3);

	this.instance_27 = new lib.HM_mcclipwhite();
	this.instance_27.parent = this;
	this.instance_27.setTransform(95.8,96.5,1,1,0,0,0,15.7,11.8);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgYBDQgJgGgFgLQgGgLgCgNQgCgNAAgNQAAgLACgOQACgMAGgMQAFgKAJgIQAKgGAOAAQAPAAAJAGQAKAIAFAKQAFAMACAMQADAOgBALQABANgDANQgCANgFALQgFALgKAGQgJAHgPAAQgOAAgKgHgAgPgwQgGAGgDANQgDANAAAQQAAASADAMQADANAGAGQAGAHAJAAQAJAAAHgHQAGgGADgNQADgMAAgSQAAgQgDgNQgDgNgGgGQgHgHgJAAQgJAAgGAHg");
	this.shape_28.setTransform(95.5,72);

	this.instance_28 = new lib.HM_mcclipwhite();
	this.instance_28.parent = this;
	this.instance_28.setTransform(95.8,71.2,1,1,0,0,0,15.7,11.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AAaA/IgCgBQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgsQAAgKgEgGQgFgGgKAAQgHAAgGAEQgFAEgDAHQgDAHAAAJIAAAjIgCAEIgCABIgHAAIgDgBIgBgEIAAh0IABgDIADgBIAHAAIACABIACADIAAAzIAAAAQAFgHAHgDQAHgEAJAAQAJAAAGADQAGADAEAFQADAGABAFQACAGgBAGIAAAtIgBAEIgCABg");
	this.shape_29.setTransform(210.2,43.8);

	this.instance_29 = new lib.HM_HAR_harthousandsbuttonnew("single",0);
	this.instance_29.parent = this;
	this.instance_29.setTransform(210.2,44.8);

	this.mysteryDigitClip_3 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_3.name = "mysteryDigitClip_3";
	this.mysteryDigitClip_3.parent = this;
	this.mysteryDigitClip_3.setTransform(210,10,1,1,0,0,0,25,15);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAgBJQgBAAAAAAQgBAAgBAAQAAAAAAgBQgBAAAAAAIgBgFIAAg6IgBAAQgFAFgHADQgHADgJAAQgNAAgKgGQgKgGgFgJQgFgKAAgNQAAgNAFgLQAFgLAKgGQAJgHAPAAQAIAAAHADQAHADAGAFIAAgDIABgEQAAgBABAAQAAAAAAAAQABgBABAAQAAAAABAAIAJAAQABAAAAAAQABAAABABQAAAAAAAAQABAAAAABIABAEIAACDIgBAFQAAAAgBAAQAAABAAAAQgBAAgBAAQAAAAgBAAgAgMgzQgFAEgDAHQgDAHAAAIQAAAIACAGQADAHAGAEQAFADAHAAQAMAAAHgGQAHgIABgNQAAgJgDgHQgDgHgGgEQgFgEgJAAQgHAAgGAEg");
	this.shape_30.setTransform(209.9,299.5);

	this.instance_30 = new lib.HM_mcclipwhite();
	this.instance_30.parent = this;
	this.instance_30.setTransform(210.8,298.9,1,1,0,0,0,15.7,11.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgYBGQgLgEgHgJQgGgJgBgOQABgJAEgHQAEgIAGgFQAHgFAJgDIAAAAQgOgFgGgJQgHgJAAgNQAAgMAHgHQAHgIAKgEQALgDAKAAQALAAAKADQAKAEAHAHQAGAIABALQAAANgHAJQgGAIgNAGIAAAAQAJAEAGADQAHAFAEAIQAFAHgBAJQAAAOgGAKQgIAJgKAFQgMAEgNAAQgMAAgMgEgAgPALQgFAEgEAFQgDAFAAAIQAAAIAEAFQAFAGAGADQAGACAHAAQAHAAAGgCQAGgDAEgFQADgFABgHQgBgJgDgGQgEgFgIgEIgPgHIgMAHgAgLg2QgGACgDAEQgFAEAAAHQABAGAEAFQAEAFAHAEIANAHIAJgHQAEgEADgEQADgFAAgHQAAgGgEgFQgDgEgGgCQgFgCgFAAQgGAAgFACg");
	this.shape_31.setTransform(210.6,274.4);

	this.instance_31 = new lib.HM_mcclipwhite();
	this.instance_31.parent = this;
	this.instance_31.setTransform(210.8,273.6,1,1,0,0,0,15.7,11.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgZBIIgDgBQAAAAgBAAQAAgBAAAAQAAAAAAgBQAAAAAAgBIAAgBIAAgBIAzh2Ig9AAIgDgBQgBgBAAAAQAAgBAAAAQgBgBAAgBQAAAAAAgBIAAgHQAAgBAAAAQAAgBABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAIBPAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAAAABQABAAAAAAQAAABAAAAQABABAAABQAAAAAAABIAAAFIgBADIgBAFIgxB2QgBAEgCABIgFABg");
	this.shape_32.setTransform(210.4,249.1);

	this.instance_32 = new lib.HM_mcclipwhite();
	this.instance_32.parent = this;
	this.instance_32.setTransform(210.8,248.3,1,1,0,0,0,15.7,11.8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgYBDQgLgIgGgRQgFgQgBgaQABgUAHgSQAGgQAOgKQANgJARgBQAIAAAGACIALADIADACIAAADIAAAKIgBADIgCABIgFgCIgHgDIgLgBQgLAAgHAFQgHAFgFAHQgFAHgCAJQgCAKAAAJQAGgHAIgDQAIgDAJAAQAMgBAKAGQAKAFAFAKQAGAKAAAOQAAAOgGAKQgFALgKAGQgLAGgOABQgPgBgLgHgAgKADQgGADgDAHQgEAHAAAIQAAAIADAGQADAHAGAFQAFADAIABQAIgBAGgDQAGgFACgHQADgGAAgJQAAgHgDgHQgCgGgGgEQgFgDgIgBQgHABgGADg");
	this.shape_33.setTransform(210.6,223.8);

	this.instance_33 = new lib.HM_mcclipwhite();
	this.instance_33.parent = this;
	this.instance_33.setTransform(210.8,223,1,1,0,0,0,15.7,11.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgaBIIgNgDIgDgDIAAgDIABgKIABgCIACgBIAFACIAIADQAFABAJAAQAKAAAGgDQAIgEAEgGQAFgHAAgJQAAgQgKgHQgJgGgPAAIgLABIgHABIgFAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgCAAgDIABg9QAAgBAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQABAAABAAIBDAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAIABAFIAAAHIgBAEIgEABIg0AAIgBAmIAJgCIAJgBQAMAAAKAFQALAFAGAJQAGAKAAAPQAAAPgHALQgHALgMAGQgNAFgPAAIgPgBg");
	this.shape_34.setTransform(210.6,198.6);

	this.instance_34 = new lib.HM_mcclipwhite();
	this.instance_34.parent = this;
	this.instance_34.setTransform(210.8,197.7,1,1,0,0,0,15.7,11.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AATBIQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBIgBgEIAAgaIg9AAIgDgBQgBgBAAAAQAAgBgBAAQAAAAAAgBQAAgBAAAAIAAgIIABgEIABgDIA1hWIADgEIAEgBIANAAIACABIABACIAAACIgBACIg3BWIAsAAIAAgeIABgEQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAIAJAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABIABAEIAAAeIAOAAIAEABQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAABIAAAHQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIgOAAIAAAaIgBAEQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAgBAAg");
	this.shape_35.setTransform(210.4,173.2);

	this.instance_35 = new lib.HM_mcclipwhite();
	this.instance_35.parent = this;
	this.instance_35.setTransform(210.8,172.4,1,1,0,0,0,15.7,11.8);

	this.clip3_3 = new lib.HM_mcnumberToggle();
	this.clip3_3.name = "clip3_3";
	this.clip3_3.parent = this;
	this.clip3_3.setTransform(210,146.9,1,1,0,0,0,25,10);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgoBJQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQAAgBAAgBIAAgHIABgFQABgDADgDIAVgSQAKgJAIgJQAIgKAHgJQAGgKAAgMQAAgJgEgFQgDgGgHgCQgGgDgHAAQgJAAgFACIgKACIgGACIgCgBIgBgCIgBgKIABgEIADgCIAKgDIAMgCIAMgBQANAAAKAFQALAFAFAJQAGAJABAOQgBAMgFALQgGALgJAKIgVAWIgTATIA5AAQABAAABAAQAAAAABAAQAAAAABABQAAAAABAAIAAAEIAAAHIAAAFQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAg");
	this.shape_36.setTransform(210.1,122.4);

	this.instance_36 = new lib.HM_mcclipwhite();
	this.instance_36.parent = this;
	this.instance_36.setTransform(210.8,121.8,1,1,0,0,0,15.7,11.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgEBIQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAIgBgFIAAiDIABgFQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAAAIAJAAQAAAAABAAQABAAAAAAQABABAAAAQAAAAABAAIABAFIAACDIgBAFQgBAAAAAAQAAAAgBABQAAAAgBAAQgBAAAAAAg");
	this.shape_37.setTransform(210.5,97.3);

	this.instance_37 = new lib.HM_mcclipwhite();
	this.instance_37.parent = this;
	this.instance_37.setTransform(210.8,96.5,1,1,0,0,0,15.7,11.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgYBDQgJgGgFgLQgGgLgCgNQgCgNAAgNQAAgLACgOQACgMAGgMQAFgKAJgIQAKgGAOAAQAPAAAJAGQAKAIAFAKQAFAMACAMQADAOgBALQABANgDANQgCANgFALQgFALgKAGQgJAHgPAAQgOAAgKgHgAgPgwQgGAGgDANQgDANAAAQQAAASADAMQADANAGAGQAGAHAJAAQAJAAAHgHQAGgGADgNQADgMAAgSQAAgQgDgNQgDgNgGgGQgHgHgJAAQgJAAgGAHg");
	this.shape_38.setTransform(210.5,72);

	this.instance_38 = new lib.HM_mcclipwhite();
	this.instance_38.parent = this;
	this.instance_38.setTransform(210.8,71.2,1,1,0,0,0,15.7,11.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_38},{t:this.shape_38},{t:this.instance_37},{t:this.shape_37},{t:this.instance_36},{t:this.shape_36},{t:this.clip3_3},{t:this.instance_35},{t:this.shape_35},{t:this.instance_34},{t:this.shape_34},{t:this.instance_33},{t:this.shape_33},{t:this.instance_32},{t:this.shape_32},{t:this.instance_31},{t:this.shape_31},{t:this.instance_30},{t:this.shape_30},{t:this.mysteryDigitClip_3},{t:this.instance_29},{t:this.shape_29},{t:this.instance_28},{t:this.shape_28},{t:this.instance_27},{t:this.shape_27},{t:this.instance_26},{t:this.shape_26},{t:this.clip3_2},{t:this.instance_25},{t:this.shape_25},{t:this.instance_24},{t:this.shape_24},{t:this.instance_23},{t:this.shape_23},{t:this.instance_22},{t:this.shape_22},{t:this.instance_21},{t:this.shape_21},{t:this.instance_20},{t:this.shape_20},{t:this.mysteryDigitClip_2},{t:this.instance_19},{t:this.shape_19},{t:this.instance_18},{t:this.shape_18},{t:this.instance_17},{t:this.shape_17},{t:this.instance_16},{t:this.shape_16},{t:this.clip3_1},{t:this.instance_15},{t:this.shape_15},{t:this.instance_14},{t:this.shape_14},{t:this.instance_13},{t:this.shape_13},{t:this.instance_12},{t:this.shape_12},{t:this.instance_11},{t:this.shape_11},{t:this.instance_10},{t:this.shape_10},{t:this.mysteryDigitClip_1},{t:this.instance_9},{t:this.shape_9},{t:this.instance_8},{t:this.shape_8},{t:this.clip1},{t:this.instance_7},{t:this.shape_7},{t:this.clip3},{t:this.instance_6},{t:this.shape_6},{t:this.instance_5},{t:this.shape_5},{t:this.instance_4},{t:this.shape_4},{t:this.instance_3},{t:this.shape_3},{t:this.instance_2},{t:this.shape_2},{t:this.instance_1},{t:this.shape_1},{t:this.mysteryDigitClip},{t:this.instance},{t:this.shape}]}).wait(1));

	// decimal
	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgLAMIAAgXIAXAAIAAAXg");
	this.shape_39.setTransform(153.1,45.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgLAMIAAgXIAXAAIAAAXg");
	this.shape_40.setTransform(153.1,10.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_40},{t:this.shape_39}]}).wait(1));

	// background
	this.instance_39 = new lib.HM_HAR_harmystnumgamepanel("synched",0);
	this.instance_39.parent = this;
	this.instance_39.setTransform(152.5,152.4,1,1,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_39).wait(1));

}).prototype = getMCSymbolPrototype(lib.HM_mctable_6cols, new cjs.Rectangle(59.8,-26.9,185.4,358.8), null);


(lib.HM_harSpeakerbutton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 10
	this.instance = new lib.HM_harspeakerup("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(20.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(3));

	// Layer 11
	this.instance_1 = new lib.HM_harspeakershadow("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(14.2,15.2);
	this.instance_1.alpha = 0.41;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(3));

	// Layer 6
	this.instance_2 = new lib.HM_harorangelozenge("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(14.5,17.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},1).wait(3));

	// Layer 2
	this.instance_3 = new lib.HM_harovalshadow("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(19,19.7,0.286,0.286);
	this.instance_3.alpha = 0.371;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,1,29.7,26.9);


(lib.HM_harSpeakerbuttonstatements = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 10
	this.instance = new lib.HM_harspeakerup_1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(20.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(3));

	// Layer 11
	this.instance_1 = new lib.HM_harspeakershadow_1("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(14.2,15.2);
	this.instance_1.alpha = 0.41;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(3));

	// Layer 6
	this.instance_2 = new lib.HM_harorangelozenge_1("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(14.5,17.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},1).wait(3));

	// Layer 2
	this.instance_3 = new lib.HM_harovalshadow_2("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(19,19.7,0.286,0.286);
	this.instance_3.alpha = 0.371;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,1,29.7,26.9);


(lib.HM_mccluesclip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"static":0});

	// timeline functions:
	this.frame_0 = function() {
		/* stop()
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgGAHQgDgDAAgEQAAgDADgDQACgDAEAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgEAAgCgDg");
	this.shape.setTransform(616.6,-291.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgTA2IgKgCIgCgCQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgIIABgBIABgBIAFABIAGADIAKABQAHAAAFgDQAGgCADgFQADgFAAgHQAAgMgHgFQgHgFgLABIgIABIgFAAIgEAAQgBAAAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAIgBgDIABgvIABgDIACgBIAzAAIACABIABADIAAAFIgBAEIgCABIgnAAIgBAcIAHgCIAHAAQAIAAAIAEQAIAEAFAGQAEAIAAAKQAAAMgFAIQgFAIgKAFQgJAEgLAAIgLgBg");
	this.shape_1.setTransform(610.4,-296);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgSAyQgIgGgEgMQgFgNAAgTQAAgQAFgMQAGgMAKgIQAJgHANAAIALABIAIACIACACIAAADIAAAHIgBACIgBAAIgEgBIgFgCIgIgBQgJAAgEAEQgGADgEAGQgDAFgCAHQgCAHAAAHQAFgFAGgDQAGgCAGAAQAKAAAHAEQAHAEAFAGQAEAIAAALQAAAKgEAIQgFAIgHAFQgIAFgLAAQgLAAgIgGgAgIABQgEADgDAFQgCAFAAAHQAAAGACAFQACAFAFADQAEADAFAAQAGAAAFgDQAEgDACgGQACgFAAgGQAAgFgCgFQgCgFgEgDQgEgCgGAAQgFAAgFABg");
	this.shape_2.setTransform(601.8,-296.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAZAnIgEgBIgBgDIAAgnQAAgKgDgGQgFgGgJAAQgGAAgGAEQgFAEgDAHQgCAGAAAHIAAAhIgCADIgDABIgGAAIgDgBIgBgDIAAhDIABgDIADgBIAGAAIADABIABADIAAAHIABAAQAEgHAHgDQAGgDAIAAQAJAAAFADQAGADADAFQADAEACAGIABAMIAAAoIgBADIgDABg");
	this.shape_3.setTransform(588.5,-294.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgVAiQgHgFgEgKQgEgJAAgKQAAgHACgHQACgHAFgGQAEgFAGgEQAHgDAJAAQAHAAAGACQAGADAFAFIAAAAIAAgEIABgDIADgBIAHAAIACABIABADIAABDIgBADIgCABIgGAAIgDgBIgBgDIAAgHIgBAAQgEAHgHADQgHADgHAAQgLAAgIgGgAgLgXQgFAEgDAGQgCAHAAAGQAAAGACAHQACAGAFAFQAFAEAHAAQAHAAAFgDQAFgEADgGQADgHAAgIQAAgIgDgGQgDgGgFgEQgFgDgHAAQgHAAgEAEg");
	this.shape_4.setTransform(578.9,-294.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAYA6IgCgBIgBgEIAAgoQAAgJgFgGQgEgFgJAAQgHAAgFADQgFAEgDAGQgDAHAAAIIAAAgIgBAEIgCABIgHAAIgCgBIgBgEIAAhqIABgDIACgBIAHAAIACABIABADIAAAvIABAAQAFgHAGgDQAHgDAHgBQAIABAHADQAFADADAEQADAFABAFIABAMIAAAoIgBAEIgCABg");
	this.shape_5.setTransform(569.8,-296.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgDAtQgGgHAAgOIAAgmIgLAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBIgCgCIAAgEIACgDIADgBIALAAIAAgUIABgEIADgBIAFAAIADABIABAEIAAAUIARAAIADABIABADIAAAEIgBACQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAAAAAIgRAAIAAAkQAAAJADAFQADADAFAAIAGAAIADgBIABABIAAACIAAAGIAAACIgCACIgEAAIgEABQgOgBgEgGg");
	this.shape_6.setTransform(562.3,-295.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgMAnIgIgDIgCgBIgBgDIABgFIABgDIACgBIADACIAFACIAJABIAFgBIAFgDQACgCAAgEQAAgDgCgCIgEgEIgJgFQgIgEgGgEQgEgFAAgJQgBgHAEgFQAEgEAFgDQAHgCAGAAIAHABIAIACIAEACIAAADIgCAFIgBACIgCAAIgDAAIgFgCIgGgBQgFAAgDACQgDACgBAEQAAAFAFADQADADAIADIAKAFQAFAEACAEQABAEAAAFQAAAJgEAFQgEAFgHACQgGACgFAAIgKgBg");
	this.shape_7.setTransform(552.1,-294.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgLAnIgJgDIgCgBIgBgDIABgFIABgDIACgBIADACIAGACIAIABIAFgBIAFgDQACgCAAgEQAAgDgCgCIgEgEIgJgFQgJgEgFgEQgEgFgBgJQAAgHAEgFQADgEAHgDQAFgCAGAAIAIABIAIACIADACIAAADIgBAFIgBACIgBAAIgEAAIgFgCIgHgBQgEAAgDACQgDACAAAEQgBAFAEADQAFADAIADIAKAFQADAEADAEQACAEAAAFQgBAJgEAFQgEAFgHACQgGACgFAAIgJgBg");
	this.shape_8.setTransform(545.6,-294.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgQAjQgJgFgFgJQgEgJAAgMQAAgLAEgJQAFgJAIgFQAIgFALAAQAPAAAKAKQAIAKABASQAAABgBAAQAAAAAAAAQAAABAAAAQgBABAAAAIgEABIgxAAQAAAIADAFQAEAGAFADQAGADAGAAQAHAAAFgBIAGgDIAFgBIABAAIAAACIABAHIgBACIgCACIgLADIgLABQgMAAgJgFgAAVgGQAAgKgFgFQgGgGgJAAQgFAAgFADQgEADgDAEQgCAFgBAGIAoAAIAAAAg");
	this.shape_9.setTransform(538.1,-294.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAGA7QgIgBgEgEQgFgDgCgHQgBgHAAgIIAAhSIABgDIACgBIAHAAIADABIABADIAABUQAAAGABAFQACAEAGAAIACgBIACAAIACABIAAACIAAAGIAAACIgCABIgDACIgEAAg");
	this.shape_10.setTransform(532.2,-296.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgLAnIgJgDIgDgBIAAgDIABgFIABgDIACgBIADACIAGACIAIABIAFgBIAFgDQACgCAAgEQAAgDgBgCIgGgEIgIgFQgJgEgEgEQgGgFAAgJQAAgHAEgFQADgEAHgDQAGgCAFAAIAIABIAJACIACACIAAADIgBAFIgBACIgBAAIgEAAIgEgCIgIgBQgEAAgDACQgDACAAAEQAAAFADADQAEADAJADIAKAFQADAEACAEQADAEAAAFQAAAJgFAFQgEAFgHACQgGACgFAAIgJgBg");
	this.shape_11.setTransform(522,-294.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgCA5IgDgBIgBgEIAAhCIABgDIADgCIAFAAIADACIABADIAABCIgBAEIgDABgAgGgpQgCgCAAgEQAAgDACgDQADgDADAAQADAAADADQADADAAADQAAAEgDACQgDADgDAAQgDAAgDgDg");
	this.shape_12.setTransform(516.8,-296.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgSAnIgCgBIgBgDIAAhDIABgDIACgBIAGAAIADABIABADIAAAHIABAAQAEgHAEgDQAFgDAGAAIAEAAIADABIADABIAAADIAAAFIAAADIgCAAIgDAAIgFAAQgIAAgEAEQgEAFgCAHQgBAGAAAGIAAAgIgBADIgDABg");
	this.shape_13.setTransform(508.4,-294.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgQAjQgJgFgFgJQgEgJAAgMQAAgLAEgJQAFgJAIgFQAIgFALAAQAPAAAKAKQAIAKABASQAAABgBAAQAAAAAAAAQAAABAAAAQgBABAAAAIgEABIgxAAQAAAIADAFQAEAGAFADQAGADAGAAQAHAAAFgBIAGgDIAFgBIABAAIAAACIABAHIgBACIgCACIgLADIgLABQgMAAgJgFgAAVgGQAAgKgFgFQgGgGgJAAQgFAAgFADQgEADgDAEQgCAFgBAGIAoAAIAAAAg");
	this.shape_14.setTransform(500.7,-294.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgLA4QgHgDgEgGIgBAAIAAAFIgBAEIgDABIgGAAIgCgBIgBgEIAAhqIABgDIACgBIAHAAIADABIABADIAAAvIAAAAQAFgIAHgCQAGgEAHAAQALABAIAGQAHAFAEAJQAEAIAAAMQAAAKgEAJQgDAJgIAFQgIAFgLABQgIAAgGgDgAgLgFQgFAEgDAFQgDAGAAAIQAAAOAGAHQAHAIAJAAQAIAAAFgEQAEgEADgGQACgHAAgHQAAgHgCgGQgCgGgFgEQgFgFgIABQgGAAgFADg");
	this.shape_15.setTransform(492,-296.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAuAnIgDgBIgBgDIAAgnIgBgMQgBgFgDgCQgEgDgGAAQgGAAgEADQgEADgCAFIgDAKIgBAJIAAAfIgBADIgDABIgFAAIgDgBIgBgDIAAgnIgBgMQgBgFgDgCQgEgDgGAAQgIAAgEAEQgFAEgBAGQgCAGAAAHIAAAiIgBADIgDABIgHAAIgCgBIgBgDIAAhDIABgDIACgBIAGAAIADABIABADIAAAHIAFgGQADgDAFgCQAEgCAGAAQALAAAGAEQAEAFADAGIAAAAQACgEADgDIAIgGQAFgCAHAAQAJAAAFADQAFADADAFQADAEAAAGIABAMIAAAoIgBADIgCABg");
	this.shape_16.setTransform(480.3,-294.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgUAkQgFgDgDgFQgDgEgBgGIgBgMIAAgoIABgDIACgBIAHAAIACABIABADIAAAmQABAGABAGQACAFADADQAEADAGAAQAIAAAFgEQAFgEADgHQADgHAAgIIAAgfIABgDIACgBIAHAAIACABIABADIAABDIgBADIgCABIgGAAIgDgBIgBgDIAAgIIgBAAQgFAIgGADQgHADgHAAQgJAAgGgDg");
	this.shape_17.setTransform(468.8,-294.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAZAnIgEgBIgBgDIAAgnQAAgKgDgGQgEgGgKAAQgHAAgFAEQgFAEgDAHQgDAGABAHIAAAhIgBADIgEABIgGAAIgDgBIgBgDIAAhDIABgDIADgBIAGAAIADABIABADIAAAHIABAAQAFgHAGgDQAHgDAHAAQAJAAAFADQAGADADAFQADAEACAGIABAMIAAAoIgBADIgDABg");
	this.shape_18.setTransform(459.5,-294.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgQAjQgJgFgFgJQgEgJgBgMQABgLAEgJQAFgJAIgFQAIgFALAAQAQAAAIAKQAJAKAAASQAAABAAAAQAAAAAAAAQAAABAAAAQgBABAAAAIgEABIgyAAQABAIADAFQADAGAHADQAFADAHAAQAHAAADgBIAHgDIAEgBIACAAIABACIAAAHIgBACIgDACIgKADIgLABQgMAAgJgFgAAVgGQAAgKgGgFQgEgGgKAAQgFAAgFADQgFADgCAEQgCAFgCAGIApAAIAAAAg");
	this.shape_19.setTransform(446.3,-294.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAYA6IgCgBIgBgEIAAgoQAAgJgFgGQgDgFgKAAQgHAAgFADQgFAEgDAGQgCAHgBAIIAAAgIgBAEIgCABIgHAAIgCgBIgBgEIAAhqIABgDIACgBIAHAAIACABIABADIAAAvIABAAQAFgHAGgDQAGgDAIgBQAIABAHADQAFADADAEQADAFABAFIABAMIAAAoIgBAEIgCABg");
	this.shape_20.setTransform(437.4,-296.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgDA2IgCgBIgBgEIAAhYIgeAAIgDgBIgBgEIAAgFIABgDIADgBIBKAAQAAAAAAAAQABAAAAAAQAAAAABABQAAAAAAAAIABADIAAAFIgBAEIgCABIgeAAIAABYIgBAEIgDABg");
	this.shape_21.setTransform(428.3,-296.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgGAHQgDgDAAgEQAAgDADgDQACgDAEAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgEAAgCgDg");
	this.shape_22.setTransform(213.8,-291.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgRAyQgHgFgFgIQgEgIgBgKQgBgJAAgKIABgTQABgJAEgJQAFgIAHgFQAHgFAKAAQALAAAIAFQAHAFAEAIQADAJACAJIACATQAAAKgCAJQgCAKgDAIQgEAIgHAFQgIAFgLABQgKgBgHgFgAgLgkQgFAFgCAJQgCAKAAAMQAAANACAJQACAKAFAFQAFAFAGAAQAHAAAFgFQAFgFACgKQACgJAAgNQAAgMgCgKQgCgJgFgFQgFgFgHAAQgGAAgFAFg");
	this.shape_23.setTransform(207.1,-296.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgSAyQgIgGgEgMQgFgNAAgTQAAgQAFgMQAGgMAKgIQAJgHANAAIALABIAIACIACACIAAADIAAAHIgBACIgBAAIgEgBIgFgCIgIgBQgJAAgEAEQgGADgEAGQgDAFgCAHQgCAHAAAHQAFgFAGgDQAGgCAGAAQAKAAAHAEQAHAEAFAGQAEAIAAALQAAAKgEAIQgFAIgHAFQgIAFgLAAQgLAAgIgGgAgIABQgEADgDAFQgCAFAAAHQAAAGACAFQACAFAFADQAEADAFAAQAGAAAFgDQAEgDACgGQACgFAAgGQAAgFgCgFQgCgFgEgDQgEgCgGAAQgFAAgFABg");
	this.shape_24.setTransform(198.2,-296.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AAYAnIgCgBIgBgDIAAgnQAAgKgFgGQgDgGgKAAQgGAAgGAEQgFAEgDAHQgCAGgBAHIAAAhIgBADIgCABIgHAAIgCgBIgBgDIAAhDIABgDIACgBIAGAAIADABIABADIAAAHIABAAQAEgHAHgDQAGgDAIAAQAIAAAHADQAFADADAFQADAEABAGIABAMIAAAoIgBADIgCABg");
	this.shape_25.setTransform(184.9,-294.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgVAiQgHgFgEgKQgEgJAAgKQAAgHACgHQACgHAFgGQAEgFAGgEQAHgDAJAAQAHAAAGACQAGADAFAFIAAAAIAAgEIABgDIADgBIAHAAIACABIABADIAABDIgBADIgCABIgGAAIgDgBIgBgDIAAgHIgBAAQgEAHgHADQgHADgHAAQgLAAgIgGgAgLgXQgFAEgDAGQgCAHAAAGQAAAGACAHQACAGAFAFQAFAEAHAAQAHAAAFgDQAFgEADgGQADgHAAgIQAAgIgDgGQgDgGgFgEQgFgDgHAAQgHAAgEAEg");
	this.shape_26.setTransform(175.3,-294.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAZA6IgDgBIgCgEIAAgoQAAgJgEgGQgDgFgKAAQgHAAgFADQgFAEgDAGQgDAHABAIIAAAgIgBAEIgDABIgGAAIgEgBIgBgEIAAhqIABgDIAEgBIAGAAIADABIABADIAAAvIAAAAQAFgHAGgDQAHgDAHgBQAJABAFADQAGADADAEQADAFACAFIAAAMIAAAoIAAAEIgDABg");
	this.shape_27.setTransform(166.2,-296.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgEAtQgFgHAAgOIAAgmIgMAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBIgBgCIAAgEIABgDIADgBIAMAAIAAgUIABgEIADgBIAGAAIACABIABAEIAAAUIAQAAIADABIACADIAAAEIgCACQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgQAAIAAAkQAAAJADAFQACADAHAAIAEAAIADgBIACABIABACIAAAGIgBACIgCACIgEAAIgDABQgOgBgGgGg");
	this.shape_28.setTransform(158.7,-295.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgQAjQgJgFgFgJQgEgJAAgMQAAgLAEgJQAFgJAIgFQAIgFAKAAQAQAAAKAKQAIAKABASQAAABgBAAQAAAAAAAAQAAABAAAAQgBABAAAAIgEABIgxAAQAAAIADAFQAEAGAFADQAGADAGAAQAHAAAFgBIAGgDIAFgBIABAAIAAACIABAHIgBACIgCACIgLADIgLABQgMAAgJgFgAAVgGQAAgKgFgFQgGgGgJAAQgFAAgFADQgEADgDAEQgCAFgBAGIAoAAIAAAAg");
	this.shape_29.setTransform(147.5,-294.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgSAnIgCgBIgBgDIAAhDIABgDIACgBIAGAAIADABIABADIAAAHIABAAQAEgHAEgDQAFgDAGAAIAEAAIADABIADABIAAADIAAAFIAAADIgCAAIgDAAIgFAAQgIAAgEAEQgEAFgCAHQgBAGAAAGIAAAgIgBADIgDABg");
	this.shape_30.setTransform(141,-294.7);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgSAjQgJgEgGgJQgFgJgBgNQABgMAFgJQAGgJAJgEQAJgFAJAAQALAAAJAFQAJAEAFAJQAGAJAAAMQAAANgGAJQgFAJgJAEQgJAFgLAAQgJAAgJgFgAgMgXQgGAEgDAGQgDAGAAAHQAAAIADAGQADAGAGAEQAFAEAHAAQAIAAAGgEQAFgEADgGQADgGAAgIQAAgHgDgGQgDgGgFgEQgGgEgIAAQgHAAgFAEg");
	this.shape_31.setTransform(132.8,-294.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAuAnIgDgBIgBgDIAAgnIgBgMQgBgFgDgCQgEgDgGAAQgGAAgEADQgEADgCAFIgDAKIgBAJIAAAfIgBADIgDABIgFAAIgDgBIgBgDIAAgnIgBgMQgBgFgDgCQgEgDgGAAQgIAAgEAEQgFAEgBAGQgCAGAAAHIAAAiIgBADIgDABIgHAAIgCgBIgBgDIAAhDIABgDIACgBIAGAAIADABIABADIAAAHIAFgGQADgDAFgCQAEgCAGAAQALAAAGAEQAEAFADAGIAAAAQACgEADgDIAIgGQAFgCAHAAQAJAAAFADQAFADADAFQADAEAAAGIABAMIAAAoIgBADIgCABg");
	this.shape_32.setTransform(121.3,-294.7);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgMAnIgIgDIgDgBIAAgDIABgFIABgDIACgBIADACIAGACIAHABIAGgBIAFgDQACgCAAgEQAAgDgBgCIgGgEIgIgFQgJgEgEgEQgGgFAAgJQABgHADgFQADgEAHgDQAFgCAGAAIAJABIAIACIACACIAAADIgBAFIAAACIgCAAIgEAAIgEgCIgIgBQgEAAgDACQgDACAAAEQAAAFADADQAEADAJADIAKAFQADAEACAEQACAEABAFQAAAJgFAFQgEAFgGACQgHACgGAAIgJgBg");
	this.shape_33.setTransform(107,-294.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgCA5IgDgBIgBgEIAAhCIABgDIADgCIAGAAIACACIABADIAABCIgBAEIgCABgAgFgpQgDgCAAgEQAAgDADgDQACgDADAAQADAAADADQADADAAADQAAAEgDACQgDADgDAAQgDAAgCgDg");
	this.shape_34.setTransform(101.8,-296.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgSAnIgCgBIgBgDIAAhDIABgDIACgBIAGAAIADABIABADIAAAHIABAAQAEgHAEgDQAFgDAGAAIAEAAIADABIADABIAAADIAAAFIAAADIgCAAIgDAAIgFAAQgIAAgEAEQgEAFgCAHQgBAGAAAGIAAAgIgBADIgDABg");
	this.shape_35.setTransform(93.4,-294.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgQAjQgJgFgFgJQgEgJAAgMQAAgLAEgJQAFgJAIgFQAIgFALAAQAPAAAKAKQAIAKABASQAAABgBAAQAAAAAAAAQAAABAAAAQgBABAAAAIgEABIgyAAQABAIADAFQAEAGAGADQAFADAGAAQAHAAAFgBIAGgDIAFgBIABAAIABACIAAAHIgBACIgCACIgLADIgLABQgMAAgJgFgAAVgGQAAgKgGgFQgEgGgKAAQgFAAgFADQgEADgDAEQgCAFgCAGIApAAIAAAAg");
	this.shape_36.setTransform(85.7,-294.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgLA4QgHgDgEgGIgBAAIAAAFIgBAEIgDABIgGAAIgCgBIgBgEIAAhqIABgDIACgBIAHAAIADABIABADIAAAvIAAAAQAFgIAHgCQAGgEAHAAQALABAIAGQAHAFAEAJQAEAIAAAMQAAAKgEAJQgDAJgIAFQgIAFgLABQgIAAgGgDgAgLgFQgFAEgDAFQgDAGAAAIQAAAOAGAHQAHAIAJAAQAIAAAFgEQAEgEADgGQACgHAAgHQAAgHgCgGQgCgGgFgEQgFgFgIABQgGAAgFADg");
	this.shape_37.setTransform(77,-296.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AAuAnIgDgBIgBgDIAAgnIgBgMQgBgFgDgCQgEgDgGAAQgGAAgEADQgEADgCAFIgDAKIgBAJIAAAfIgBADIgDABIgFAAIgDgBIgBgDIAAgnIgBgMQgBgFgDgCQgEgDgGAAQgIAAgEAEQgFAEgBAGQgCAGAAAHIAAAiIgBADIgDABIgHAAIgCgBIgBgDIAAhDIABgDIACgBIAGAAIADABIABADIAAAHIAFgGQADgDAFgCQAEgCAGAAQALAAAGAEQAEAFADAGIAAAAQACgEADgDIAIgGQAFgCAHAAQAJAAAFADQAFADADAFQADAEAAAGIABAMIAAAoIgBADIgCABg");
	this.shape_38.setTransform(65.3,-294.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgTAkQgGgDgDgFQgDgEgBgGIgCgMIAAgoIACgDIACgBIAHAAIADABIABADIAAAmQAAAGABAGQACAFADADQAEADAHAAQAGAAAGgEQAFgEADgHQADgHAAgIIAAgfIABgDIADgBIAGAAIACABIABADIAABDIgBADIgCABIgGAAIgDgBIgBgDIAAgIIgBAAQgFAIgGADQgHADgHAAQgJAAgFgDg");
	this.shape_39.setTransform(53.8,-294.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AAZAnIgEgBIgBgDIAAgnQAAgKgDgGQgFgGgJAAQgGAAgGAEQgFAEgDAHQgCAGAAAHIAAAhIgBADIgEABIgGAAIgDgBIgBgDIAAhDIABgDIADgBIAGAAIADABIABADIAAAHIABAAQAFgHAGgDQAGgDAIAAQAJAAAFADQAGADADAFQADAEACAGIABAMIAAAoIgBADIgDABg");
	this.shape_40.setTransform(44.5,-294.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgQAjQgJgFgEgJQgFgJgBgMQABgLAFgJQAEgJAIgFQAIgFAKAAQARAAAIAKQAKAKgBASQAAABAAAAQAAAAAAAAQAAABAAAAQgBABAAAAIgEABIgyAAQABAIADAFQADAGAGADQAGADAHAAQAGAAAEgBIAIgDIADgBIACAAIABACIAAAHIgBACIgDACIgKADIgLABQgMAAgJgFgAAVgGQAAgKgGgFQgEgGgKAAQgFAAgFADQgFADgCAEQgCAFgCAGIApAAIAAAAg");
	this.shape_41.setTransform(31.3,-294.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AAYA6IgCgBIgBgEIAAgoQAAgJgFgGQgDgFgKAAQgGAAgGADQgFAEgDAGQgCAHgBAIIAAAgIAAAEIgDABIgGAAIgDgBIgBgEIAAhqIABgDIADgBIAGAAIADABIAAADIAAAvIABAAQAEgHAHgDQAGgDAIgBQAIABAHADQAFADADAEQADAFABAFIABAMIAAAoIgBAEIgCABg");
	this.shape_42.setTransform(22.4,-296.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgDA2IgCgBIgBgEIAAhYIgeAAIgDgBIgBgEIAAgFIABgDIADgBIBKAAQAAAAAAAAQABAAAAAAQAAAAABABQAAAAAAAAIABADIAAAFIgBAEIgCABIgeAAIAABYIgCAEIgCABg");
	this.shape_43.setTransform(13.3,-296.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 6
	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgFBeQgEAAgCgDQgBgBAAgEIAAirQAAgEABgCQACgBAEAAIALAAQABAAABAAQABAAAAAAQABAAAAABQABAAAAAAQACACAAAEIAACrQAAAEgCABQAAABgBAAQAAABgBAAQAAAAgBAAQgBABgBAAg");
	this.shape_44.setTransform(402,-277.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgFBeQgDAAgCgDQgCgBAAgEIAAirQAAgEACgCQACgBADAAIAMAAQAAAAABAAQABAAAAAAQABAAAAABQABAAAAAAQACACAAAEIAACrQAAAEgCABQAAABgBAAQAAABgBAAQAAAAgBAAQgBABAAAAg");
	this.shape_45.setTransform(-11.2,-277.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_45},{t:this.shape_44}]}).wait(1));

	// clue nos
	this.instance = new lib.HM_harSpeakerbuttonstatements("single",0);
	this.instance.parent = this;
	this.instance.setTransform(390.8,-321.8,0.904,0.904);

	this.instance_1 = new lib.HM_harSpeakerbuttonstatements("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-23.2,-322.8,0.904,0.904);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// gfx
	this.instance_2 = new lib.HM_HAR_harmystnumgreenclue("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(517.2,-285.5,1,1,0,0,0,0.5,-0.1);

	this.instance_3 = new lib.HM_HAR_harmystnumblueclue("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(103.7,-285.5,1,1,0,0,0,0.5,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.HM_mccluesclip, new cjs.Rectangle(-38.3,-323.5,697.6,76), null);


(lib.HM_mchelpMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{screen1:1,screen2:148,screen3:326,screen4:563,screen5:742});

	// timeline functions:
	this.frame_0 = function() {
		/* var strSwf:String = "";
		if(_parent._parent.strOptionalflashVars != undefined)
		{
		strSwf = _parent._parent.strOptionalflashVars;
		}
		strSwf += "helpmoviebar.swf";
		loadMovie(strSwf, stripLoader);
		//loadMovie("helpmoviebar.swf", stripLoader);
		
		_parent.ffBtnMC.gotoAndStop(2);
		_parent.backBtnMC.gotoAndStop(2);
		_parent.playBtnMC.gotoAndStop(1);
		
		feedbackClip.feedbackText="The computer is thinking of a mystery number. Use the clues to help you work out each digit in the number. Click to eliminate a digit on the grid.";
		HM_clues.gotoAndStop("showClue1");
		clueTextBlue1="The number is more than 60.";
		clueTextGreen1="The number is less than 65.";
		HM_table.gotoAndStop("show4");
		HM_table.col1.newHeaderTextClip.headingDisplay="T";
		HM_table.col2.newHeaderTextClip.headingDisplay="U";
		HM_table.col3.newHeaderTextClip.headingDisplay="t";
		HM_table.col4.newHeaderTextClip.headingDisplay="h";
		HM_table.col1.mysteryDigitClip.mysteryDigit="?";
		HM_table.col1.clip0.gotoAndStop("active");
		HM_table.col1.clip1.gotoAndStop("active");
		HM_table.col1.clip2.gotoAndStop("active");
		HM_table.col1.clip3.gotoAndStop("active");
		HM_table.col1.clip4.gotoAndStop("active");
		HM_table.col1.clip5.gotoAndStop("active");
		HM_table.col1.clip7.gotoAndStop("active");
		HM_table.col1.clip8.gotoAndStop("active");
		HM_table.col1.clip9.gotoAndStop("active");
		stop();
		*/
	}
	this.frame_1 = function() {
		/* _parent.currentScreen = 1;
		_parent.backBtnMC.gotoAndStop(1);
		_parent.ffBtnMC.gotoAndStop(1);
		
		feedbackClip.feedbackText="The computer is thinking of a mystery number. Use the clues to help you work out each digit in the number. Click to eliminate a digit on the grid.";
		HM_clues.gotoAndStop("showClue1");
		clueTextBlue1="The number is more than 60.";
		clueTextGreen1="The number is less than 65.";
		HM_table.gotoAndStop("show4");
		HM_table.col1.newHeaderTextClip.headingDisplay="T";
		HM_table.col2.newHeaderTextClip.headingDisplay="U";
		HM_table.col3.newHeaderTextClip.headingDisplay="t";
		HM_table.col4.newHeaderTextClip.headingDisplay="h";
		HM_table.col1.mysteryDigitClip.mysteryDigit="?";
		HM_table.col1.clip0.gotoAndStop("active");
		HM_table.col1.clip1.gotoAndStop("active");
		HM_table.col1.clip2.gotoAndStop("active");
		HM_table.col1.clip3.gotoAndStop("active");
		HM_table.col1.clip4.gotoAndStop("active");
		HM_table.col1.clip5.gotoAndStop("active");
		HM_table.col1.clip7.gotoAndStop("active");
		HM_table.col1.clip8.gotoAndStop("active");
		HM_table.col1.clip9.gotoAndStop("active");
		*/
	}
	this.frame_148 = function() {
		/* _parent.currentScreen = 2;
		_parent.backBtnMC.gotoAndStop(1);
		_parent.ffBtnMC.gotoAndStop(1);
		
		feedbackClip.feedbackText="You are aiming to eliminate all but one digit in each column. The last digit becomes your guess for that digit in the computer's mystery number.";
		HM_clues.gotoAndStop("showClue1");
		clueTextBlue1="The number is more than 60.";
		clueTextGreen1="The number is less than 65.";
		HM_table.gotoAndStop("show4");
		HM_table.col1.newHeaderTextClip.headingDisplay="T";
		HM_table.col2.newHeaderTextClip.headingDisplay="U";
		HM_table.col3.newHeaderTextClip.headingDisplay="t";
		HM_table.col4.newHeaderTextClip.headingDisplay="h";
		HM_table.col1.mysteryDigitClip.mysteryDigit="?";
		HM_table.col1.clip0.gotoAndStop("inactive");
		HM_table.col1.clip1.gotoAndStop("inactive");
		HM_table.col1.clip2.gotoAndStop("inactive");
		HM_table.col1.clip3.gotoAndStop("inactive");
		HM_table.col1.clip4.gotoAndStop("inactive");
		HM_table.col1.clip5.gotoAndStop("inactive");
		HM_table.col1.clip6.gotoAndStop("active");
		HM_table.col1.clip7.gotoAndStop("active");
		HM_table.col1.clip8.gotoAndStop("active");
		HM_table.col1.clip9.gotoAndStop("active");
		*/
	}
	this.frame_326 = function() {
		/* _parent.currentScreen = 3;
		_parent.backBtnMC.gotoAndStop(1);
		_parent.ffBtnMC.gotoAndStop(1);
		
		feedbackClip.feedbackText="You are aiming to eliminate all but one digit in each column. The last digit becomes your guess for that digit in the computer's mystery number.";
		HM_clues.gotoAndStop("showClue1");
		clueTextBlue1="The number is more than 60.";
		clueTextGreen1="The number is less than 65.";
		HM_table.gotoAndStop("show4");
		HM_table.col1.newHeaderTextClip.headingDisplay="T";
		HM_table.col2.newHeaderTextClip.headingDisplay="U";
		HM_table.col3.newHeaderTextClip.headingDisplay="t";
		HM_table.col4.newHeaderTextClip.headingDisplay="h";
		HM_table.col1.mysteryDigitClip.mysteryDigit="?";
		HM_table.col1.clip0.gotoAndStop("inactive");
		HM_table.col1.clip1.gotoAndStop("inactive");
		HM_table.col1.clip2.gotoAndStop("inactive");
		HM_table.col1.clip3.gotoAndStop("inactive");
		HM_table.col1.clip4.gotoAndStop("inactive");
		HM_table.col1.clip5.gotoAndStop("inactive");
		HM_table.col1.clip6.gotoAndStop("active");
		HM_table.col1.clip7.gotoAndStop("active");
		HM_table.col1.clip8.gotoAndStop("active");
		HM_table.col1.clip9.gotoAndStop("active");
		*/
	}
	this.frame_563 = function() {
		/* _parent.currentScreen = 4;
		_parent.backBtnMC.gotoAndStop(1);
		_parent.ffBtnMC.gotoAndStop(1);
		
		feedbackClip.feedbackText="You are aiming to eliminate all but one digit in each column. The last digit becomes your guess for that digit in the computer's mystery number.";
		HM_clues.gotoAndStop("showClue1");
		clueTextBlue1="The number is more than 60.";
		clueTextGreen1="The number is less than 65.";
		HM_table.gotoAndStop("show4");
		HM_table.col1.newHeaderTextClip.headingDisplay="T";
		HM_table.col2.newHeaderTextClip.headingDisplay="U";
		HM_table.col3.newHeaderTextClip.headingDisplay="t";
		HM_table.col4.newHeaderTextClip.headingDisplay="h";
		HM_table.col1.mysteryDigitClip.mysteryDigit="6";
		HM_table.col1.clip0.gotoAndStop("inactive");
		HM_table.col1.clip1.gotoAndStop("inactive");
		HM_table.col1.clip2.gotoAndStop("inactive");
		HM_table.col1.clip3.gotoAndStop("inactive");
		HM_table.col1.clip4.gotoAndStop("inactive");
		HM_table.col1.clip5.gotoAndStop("inactive");
		HM_table.col1.clip7.gotoAndStop("inactive");
		HM_table.col1.clip8.gotoAndStop("inactive");
		HM_table.col1.clip9.gotoAndStop("inactive");
		*/
	}
	this.frame_742 = function() {
		/* _parent.currentScreen = 5;
		_parent.backBtnMC.gotoAndStop(1);
		_parent.ffBtnMC.gotoAndStop(1);
		
		feedbackClip.feedbackText="The computer is thinking of a mystery number. Use the clues to help you work out each digit in the number. Click to eliminate a digit on the grid.";
		HM_clues.gotoAndStop("showClue1");
		clueTextBlue1="The number is more than 60.";
		clueTextGreen1="The number is less than 65.";
		HM_table.gotoAndStop("show4");
		HM_table.col1.newHeaderTextClip.headingDisplay="T";
		HM_table.col2.newHeaderTextClip.headingDisplay="U";
		HM_table.col3.newHeaderTextClip.headingDisplay="t";
		HM_table.col4.newHeaderTextClip.headingDisplay="h";
		HM_table.col1.mysteryDigitClip.mysteryDigit="?";
		HM_table.col1.clip0.gotoAndStop("active");
		HM_table.col1.clip1.gotoAndStop("active");
		HM_table.col1.clip2.gotoAndStop("active");
		HM_table.col1.clip3.gotoAndStop("active");
		HM_table.col1.clip4.gotoAndStop("active");
		HM_table.col1.clip5.gotoAndStop("active");
		HM_table.col1.clip7.gotoAndStop("active");
		HM_table.col1.clip8.gotoAndStop("active");
		HM_table.col1.clip9.gotoAndStop("active");
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(147).call(this.frame_148).wait(178).call(this.frame_326).wait(237).call(this.frame_563).wait(179).call(this.frame_742).wait(111));

	// header
	this.instance = new lib.HM_harSoundbutton("single",0);
	this.instance.parent = this;
	this.instance.setTransform(99.2,-224.3,0.75,0.75);

	this.instance_1 = new lib.HM_harVoicebutton("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(166,-224.4,0.749,0.754);

	this.instance_2 = new lib.HM_harSpeakerbutton("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-291.7,-199.6,0.75,0.75);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgFAFQgCgCAAgDQAAgCACgDQADgCACAAQADAAACACQADADAAACQAAADgDACQgCADgDAAQgCAAgDgDg");
	this.shape.setTransform(-100.6,-151.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgQArQgGgFgDgHQgEgIAAgJQAAgFACgGQACgFADgEQAEgFAFgCQAFgDAHAAQAFAAAGADQAFACADAFIABAAIAAglIABgCIACgBIAFAAIACABIABACIAABVIgBADIgCABIgFAAIgCgBIgBgDIAAgFIgBAAQgDAGgGACQgFACgFAAQgJAAgGgEgAgJgDQgEADgCAEQgCAFAAAGQAAAFACAFQACAGAEADQAEAEAFAAQAGAAAEgDQAEgDACgFQADgFAAgHQAAgHgDgFQgCgEgEgDQgFgDgFAAQgFABgEADg");
	this.shape_1.setTransform(-106.3,-155.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgEACgCQACgCACAAQADAAACACQACACAAAEQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_2.setTransform(-111.3,-155.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgOAfIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFQAEgGADgCQADgCAGAAIADAAIACAAIACABIABACIAAAFIAAACIgCAAIgDAAIgDAAQgHAAgDADQgDAEgCAGQgBAFAAAFIAAAZIAAACIgDABg");
	this.shape_3.setTransform(-114.6,-154.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgIAvIgHgCIgGgBIgCgCIAAgCIAAgFQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAIACgBIAEACIAGACIAKABQAJAAAFgFQAFgFAAgLIAAgMIgBAAQgDAGgGACQgFACgFAAQgJAAgGgFQgGgDgDgHQgEgHAAgJQAAgFACgGQACgFADgFQAEgEAFgDQAFgDAHABQAGgBAFADQAFADAEAFIAAAAIAAgGIABgDIACAAIAFAAIACAAIABADIAAA8QAAAPgIAHQgIAIgPgBIgHAAgAgJgiQgEAEgCAEQgCAFAAAGQAAAGACAEQACAFAEACQAEAEAFAAQAJgBAFgFQAFgFAAgKQAAgHgDgFQgCgEgEgEQgFgCgFAAQgFAAgEADg");
	this.shape_4.setTransform(-121.3,-152.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgMAcQgHgEgFgHQgDgIgBgJQABgJADgHQAEgHAHgEQAGgEAIAAQANAAAHAIQAIAHgBAQIgBABIgDABIgoAAQABAGADAFQADAEAEADQAEACAGAAIAJgBIAFgCIADgBIABABIABABIAAAFIAAADIgCAAIgJADIgJABQgKAAgGgEgAARgFQAAgHgEgFQgFgFgHAAQgEAAgEADQgDACgCADQgDAFAAAEIAgAAIAAAAg");
	this.shape_5.setTransform(-131.7,-154);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AATAuIgCgBIgBgCIAAggQAAgIgCgDQgDgFgIgBQgGAAgEAEQgEACgCAFQgDAGAAAGIAAAaIAAACIgCABIgFAAIgDgBIgBgCIAAhVIABgDIADAAIAFAAIACAAIAAADIAAAlIABAAQAEgFAFgCQAFgDAGAAQAHAAAEADQAFACADADQACAEABAEIAAAJIAAAhIAAACIgCABg");
	this.shape_6.setTransform(-138.8,-155.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgCAkQgFgGAAgLIAAgeIgJAAIgCgBIgBgDIAAgCIABgDIACAAIAJAAIAAgRIABgCIACgBIAEAAIACABIABACIAAARIAOAAIACAAIAAADIAAACIAAADIgCABIgOAAIAAAdQAAAHADADQACAEAEAAIAFgBIACAAIABAAIAAACIAAAFIAAACIgCAAIgCABIgEAAQgKAAgEgFg");
	this.shape_7.setTransform(-144.8,-155);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AAUAfIgCgBIgBgCIAAgfQgBgIgDgFQgCgFgJAAQgEAAgFADQgEAEgCAFQgDAFABAGIAAAaIgBACIgCABIgGAAIgBgBIgBgCIAAg1IABgDIABgBIAFAAIADABIABADIAAAFIAAAAQAEgFAFgDQAFgCAGAAQAHAAAFACQAEACACAEQADAEABAFIABAJIAAAgIgBACIgCABg");
	this.shape_8.setTransform(-154.1,-154.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgPAcQgHgEgEgGQgEgIgBgKQABgJAEgHQAEgIAHgDQAIgEAHAAQAJAAAHAEQAHADAEAIQAFAHAAAJQAAAKgFAIQgEAGgHAEQgHAEgJAAQgHAAgIgEgAgKgSQgEACgDAGQgCAFAAAFQAAAGACAFQADAFAEADQAFADAFAAQAGAAAFgDQAFgDACgFQACgFAAgGQAAgFgCgFQgCgGgFgCQgFgEgGAAQgFAAgFAEg");
	this.shape_9.setTransform(-161.6,-154);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgDAkQgEgGAAgLIAAgeIgJAAIgDgBIgBgDIAAgCIABgDIADAAIAJAAIAAgRIABgCIACgBIAEAAIADABIAAACIAAARIANAAIADAAIABADIAAACIgBADIgDABIgNAAIAAAdQAAAHACADQADAEAFAAIADgBIADAAIABAAIABACIAAAFIgBACIgCAAIgCABIgDAAQgMAAgEgFg");
	this.shape_10.setTransform(-171.1,-155);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgEACgCQACgCACAAQADAAACACQACACAAAEQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_11.setTransform(-174.8,-155.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgIAvIgHgCIgGgBIgCgCIAAgCIAAgFQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAIACgBIAEACIAGACIAKABQAJAAAFgFQAFgFAAgLIAAgMIgBAAQgDAGgGACQgFACgFAAQgJAAgGgFQgGgDgDgHQgEgHAAgJQAAgFACgGQACgFADgFQAEgEAFgDQAFgDAHABQAGgBAFADQAFADAEAFIAAAAIAAgGIABgDIACAAIAFAAIACAAIABADIAAA8QAAAPgIAHQgIAIgPgBIgHAAgAgJgiQgEAEgCAEQgCAFAAAGQAAAGACAEQACAFAEACQAEAEAFAAQAJgBAFgFQAFgFAAgKQAAgHgDgFQgCgEgEgEQgFgCgFAAQgFAAgEADg");
	this.shape_12.setTransform(-180.2,-152.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgEACgCQACgCACAAQADAAACACQACACAAAEQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_13.setTransform(-185.3,-155.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgQArQgGgFgDgHQgEgIAAgJQAAgFACgGQACgFADgEQAEgFAFgCQAFgDAHAAQAFAAAGADQAFACADAFIABAAIAAglIABgCIACgBIAFAAIACABIABACIAABVIgBADIgCABIgFAAIgCgBIgBgDIAAgFIgBAAQgDAGgGACQgFACgFAAQgJAAgGgEgAgJgDQgEADgCAEQgCAFAAAGQAAAFACAFQACAGAEADQAEAEAFAAQAGAAAEgDQAEgDACgFQADgFAAgHQAAgHgDgFQgCgEgEgDQgFgDgFAAQgFABgEADg");
	this.shape_14.setTransform(-190.7,-155.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgQAcQgGgFgDgHQgEgIAAgIQAAgFACgHQACgFADgFQAEgEAFgCQAFgDAHAAQAGAAAFACQAFACADADIABAAIAAgCIABgDIACgBIAFAAIACABIABADIAAA1IgBACIgCABIgFAAIgCgBIgBgCIAAgGIAAAAQgEAGgFACQgFADgGAAQgJAAgGgEgAgJgSQgEADgCAFQgCAFAAAFQAAAFACAFQACAGAEADQAEAEAFgBQAGAAAEgDQAEgDACgFQADgEAAgHQAAgGgDgFQgCgFgEgDQgFgDgFAAQgFAAgEAEg");
	this.shape_15.setTransform(-201.7,-154);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgNAcQgGgEgFgHQgDgIAAgJQAAgJADgHQAEgHAGgEQAHgEAIAAQANAAAHAIQAHAHAAAQIgBABIgDABIgoAAQABAGACAFQADAEAFADQAEACAFAAIAJgBIAGgCIADgBIABABIABABIAAAFIAAADIgDAAIgIADIgJABQgJAAgIgEgAARgFQAAgHgFgFQgEgFgHAAQgEAAgEADQgDACgDADQgCAFAAAEIAgAAIAAAAg");
	this.shape_16.setTransform(-212,-154);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgCAkQgFgGAAgLIAAgeIgJAAIgCgBIgBgDIAAgCIABgDIACAAIAJAAIAAgRIABgCIACgBIAEAAIACABIABACIAAARIAOAAIACAAIAAADIAAACIAAADIgCABIgOAAIAAAdQAAAHADADQACAEAEAAIAFgBIACAAIABAAIAAACIAAAFIAAACIgCAAIgCABIgEAAQgKAAgEgFg");
	this.shape_17.setTransform(-217.7,-155);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgQAcQgGgFgDgHQgEgIAAgIQAAgFACgHQACgFADgFQAEgEAFgCQAFgDAHAAQAGAAAFACQAFACADADIABAAIAAgCIABgDIACgBIAFAAIACABIABADIAAA1IgBACIgCABIgFAAIgCgBQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAgBAAAAIAAgGIAAAAQgEAGgFACQgFADgGAAQgJAAgGgEgAgJgSQgEADgCAFQgCAFAAAFQAAAFACAFQACAGAEADQAEAEAFgBQAGAAAEgDQAEgDACgFQADgEAAgHQAAgGgDgFQgCgFgEgDQgFgDgFAAQgFAAgEAEg");
	this.shape_18.setTransform(-223.8,-154);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AATAfIgCgBIgBgCIAAgfQAAgIgCgFQgDgFgIAAQgGAAgEADQgEAEgCAFQgDAFAAAGIAAAaIAAACIgDABIgEAAIgDgBIgBgCIAAg1IABgDIADgBIAEAAIACABIABADIAAAFIABAAQAEgFAFgDQAFgCAGAAQAHAAAEACQAFACADAEQACAEABAFIAAAJIAAAgIAAACIgCABg");
	this.shape_19.setTransform(-231,-154.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgEACgCQACgCACAAQADAAACACQACACAAAEQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_20.setTransform(-236.3,-155.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAlAfIgCgBIgBgCIAAgfIgBgJQgBgEgDgDQgCgCgFAAQgFAAgEADIgEAGIgDAIIgBAHIAAAZIAAACIgCABIgFAAIgCgBIgBgCIAAgfIgBgJQAAgEgDgDQgDgCgEAAQgHAAgDADQgDADgCAFQgCAGAAAFIAAAbIAAACIgDABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIABADIAAAFIAEgFIAGgEQAEgBAEAAQAJAAAEADQAEADACAGIAFgGQACgDAEgCQADgBAGAAQAHAAAFACQADACACAEQADAEABAFIAAAJIAAAgIAAACIgDABg");
	this.shape_21.setTransform(-243.2,-154.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgEACgCQACgCACAAQADAAACACQACACAAAEQAAACgCACQgCADgDAAQgCAAgCgDg");
	this.shape_22.setTransform(-250.2,-155.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgFArQgEgDgBgEQgBgGAAgHIAAhBIABgDIACgBIAFAAIACABIABADIAABCQAAAGABADQACAEAEAAIACAAIABAAIACAAIAAACIAAAEIAAADIgBAAIgDABIgDAAQgGAAgEgEg");
	this.shape_23.setTransform(-253,-155.6);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgMAcQgHgEgFgHQgDgIgBgJQABgJADgHQAEgHAHgEQAGgEAIAAQANAAAHAIQAIAHgBAQIgBABIgDABIgoAAQABAGADAFQADAEAEADQAEACAGAAIAJgBIAFgCIADgBIABABIABABIAAAFIAAADIgCAAIgJADIgJABQgKAAgGgEgAARgFQAAgHgEgFQgFgFgHAAQgEAAgEADQgDACgCADQgDAFAAAEIAgAAIAAAAg");
	this.shape_24.setTransform(-258.6,-154);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgOAcQgIgDgEgIQgEgHgBgKQABgKAEgGQAEgHAIgFQAGgDAIAAQAJAAAHADQAHAFAEAHQAFAGAAAKQAAAKgFAHQgEAIgHADQgHAEgJAAQgIAAgGgEgAgKgTQgEAEgDAEQgCAGAAAFQAAAGACAFQADAFAEAEQAEACAGAAQAGAAAFgCQAEgEACgFQADgFAAgGQAAgFgDgGQgCgEgEgEQgFgDgGAAQgGAAgEADg");
	this.shape_25.setTransform(45.8,-170.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgCAkQgFgGAAgLIAAgeIgJAAIgDgBIAAgDIAAgCIAAgDIADAAIAJAAIAAgRIABgCIACgBIAEAAIACABIABACIAAARIANAAIADAAIAAADIAAACIAAADIgDABIgNAAIAAAdQAAAHADADQACAEAFAAIADgBIADAAIABAAIAAACIAAAFIAAACIgCAAIgCABIgDAAQgMAAgDgFg");
	this.shape_26.setTransform(39.8,-171.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AARAvIgEgBIgCgCIgagdIAAAcIgBADIgBABIgGAAIgCgBQAAgBAAAAQgBAAAAAAQAAgBAAAAQAAgBAAAAIAAhVIABgCIACgBIAGAAIABABIABACIAAA1IAYgXIABgBIAEgBIAHAAIACABIABABIgBABIgBABIgYAWIAcAfIABABIAAABIAAABIgCABg");
	this.shape_27.setTransform(31.5,-172.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgIAcQgHgFgEgHQgDgHAAgJQAAgIADgHQAFgHAGgFQAIgEAIAAIAHAAIAHACIABACIAAADIAAADIgBABIgBABIgEgCIgIgBQgGABgEADQgFADgCAFQgCAFgBAFQABAGACAFQADAFAEAEQAEACAIAAIAEAAIAEgBIADgBIABABIAAABIAAAEIAAADIgCABIgHABIgGABQgIAAgIgEg");
	this.shape_28.setTransform(25.1,-170.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgCAuIgCgBIgBgDIAAg2IABgCIACgBIAFAAIACABIAAACIAAA2IAAADIgCABgAgEghQgCgBAAgDQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_29.setTransform(20.7,-172);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgFArQgEgCgBgGQgBgFAAgGIAAhDIABgCIACgBIAFAAIACABIABACIAABDQAAAGABADQACADAEAAIACAAIABAAIACABIAAACIAAAEIAAACIgBABIgDAAIgDABQgGAAgEgEg");
	this.shape_30.setTransform(17.9,-172.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgTAhQgHgHgDgIQgDgIAAgKQAAgJADgIQAEgIAGgGQAGgHAIgDQAIgDAJAAIAGABIAHABIAFACIACABIAAACIAAAHIgBABIgBABIgBgBIgEgBIgFgCIgHAAQgIAAgFACQgGACgEAFQgFAFgCAGQgCAGAAAGQAAAIACAGQACAGAFAEQAFAFAFACQAFADAHAAIAGgBIAFAAIAEgCIADgBIACABIAAACIAAAEIAAADIgCACIgGABIgGABIgGABQgTAAgMgMg");
	this.shape_31.setTransform(12.1,-171.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgFAGQgCgCAAgEQAAgDACgCQACgCADAAQADAAACACQADACAAADQAAAEgDACQgCACgDAAQgDAAgCgCg");
	this.shape_32.setTransform(3.1,-168.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgOAfIgCgBQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAIAAg1IABgDIACgBIAFAAIACABIABADIAAAFQAEgGACgCQAFgCAEAAIAEAAIADAAIABABIABACIAAAFIAAACIgCAAIgDAAIgEAAQgFAAgEADQgDAEgCAGQgBAFAAAFIAAAZIgBACIgCABg");
	this.shape_33.setTransform(-0.5,-170.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgNAcQgGgEgEgIQgEgGgBgKQABgJAEgHQADgHAGgEQAHgEAIAAQANAAAHAIQAIAIAAAOIgBADIgEABIgnAAQAAAFACAFQADAFAFACQAFACAEAAIAJAAIAGgCIADgCIABABIAAABIABAFIgBADIgCABIgIACIgJABQgJAAgIgEgAARgFQgBgIgEgEQgDgEgIgBQgEABgEACQgEACgCAEQgCADAAAFIAgAAIAAAAg");
	this.shape_34.setTransform(-6.6,-170.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgJAtQgFgDgEgFIAAAFIgBADIgCABIgFAAIgCgBIgBgDIAAhVIABgCIACgBIAFAAIADABIAAACIAAAlIABAAQAEgFAFgCQAFgDAGAAQAJAAAGAFQAGAEADAHQADAHAAAJQAAAIgDAHQgDAHgGAFQgGAEgJAAQgGAAgGgCgAgJgDQgEACgCAEQgDAFAAAHQABALAFAGQAFAGAHAAQAGAAAEgDQAEgDACgFQACgGAAgGIgCgKQgCgFgDgDQgEgDgHAAQgEAAgFADg");
	this.shape_35.setTransform(-13.6,-172.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AAlAfIgDgBIAAgCIAAgfIgBgJQgBgEgCgDQgDgCgFAAQgFAAgEADIgFAGIgCAIIgBAHIAAAZIAAACIgCABIgFAAIgCgBIAAgCIAAgfIgBgJQgBgEgDgDQgCgCgFAAQgHAAgDADQgDADgCAFQgCAGAAAFIAAAbIAAACIgDABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFIAEgFIAGgEQAEgBAFAAQAIAAAEADQAEADACAGIAEgGQADgDAEgCQADgBAGAAQAHAAAEACQAFACABAEQADAEAAAFIABAJIAAAgIgBACIgCABg");
	this.shape_36.setTransform(-22.9,-170.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgPAdQgFgCgCgEQgDgEgBgFIgBgJIAAggIABgDIADAAIAEAAIADAAIAAADIAAAeQAAAFACAEQABAFADACQADADAFAAQAGAAAEgEQAFgDACgGQABgFAAgGIAAgZIABgDIACAAIAGAAIACAAIAAADIAAA1IAAADIgCABIgFAAIgCgBIgBgDIAAgGIgBAAQgEAGgFADQgFACgFAAQgIAAgEgCg");
	this.shape_37.setTransform(-32.1,-170.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AATAfIgCgBIAAgCIAAgfQAAgIgDgFQgEgFgIAAQgEAAgFADQgEAEgCAFQgCAFgBAGIAAAaIAAACIgCABIgGAAIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIABADIAAAFIABAAQADgFAGgDQAFgCAGAAQAHAAAFACQAEACADAEQACAEABAFIAAAJIAAAgIAAACIgCABg");
	this.shape_38.setTransform(-39.5,-170.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgNAcQgHgEgEgIQgDgGAAgKQAAgJADgHQAEgHAGgEQAHgEAIAAQANAAAHAIQAHAIAAAOIAAADIgEABIgoAAQABAFACAFQAEAFAEACQAFACAEAAIAJAAIAGgCIADgCIABABIAAABIABAFIgBADIgCABIgIACIgJABQgJAAgIgEgAARgFQAAgIgFgEQgDgEgIgBQgEABgEACQgEACgCAEQgCADAAAFIAgAAIAAAAg");
	this.shape_39.setTransform(-50.1,-170.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AATAvIgBgBIgBgDIAAggQAAgIgEgDQgCgGgJAAQgEAAgFADQgEADgCAFQgCAGgBAGIAAAaIAAADIgCABIgGAAIgCgBIAAgDIAAhVIAAgCIACgBIAGAAIACABIAAACIAAAlIABAAQADgFAGgDQAFgCAGAAQAHAAAFACQAEADADAEQACADABAEIAAAJIAAAhIAAADIgCABg");
	this.shape_40.setTransform(-57.2,-172.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgDAkQgEgGAAgLIAAgeIgJAAIgCgBIgCgDIAAgCIACgDIACAAIAJAAIAAgRIABgCIACgBIAFAAIABABIABACIAAARIAOAAIACAAIABADIAAACIgBADIgCABIgOAAIAAAdQAAAHACADQADAEAEAAIAFgBIACAAIABAAIAAACIAAAFIAAACIgBAAIgDABIgEAAQgKAAgFgFg");
	this.shape_41.setTransform(-63.2,-171.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AAUAfIgDgBIgBgCIAAgfQAAgIgCgFQgEgFgHAAQgGAAgEADQgEAEgCAFQgCAFAAAGIAAAaIgBACIgDABIgEAAIgDgBIgBgCIAAg1IABgDIADgBIAEAAIACABIACADIAAAFIAAAAQADgFAGgDQAFgCAGAAQAHAAAEACQAFACACAEQADAEABAFIAAAJIAAAgIAAACIgCABg");
	this.shape_42.setTransform(-72.5,-170.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgCAuIgCgBQAAgBAAAAQAAAAgBAAQAAgBAAAAQAAgBAAAAIAAg2IABgCIACgBIAFAAIACABIAAACIAAA2IAAADIgCABgAgEghQgCgBAAgDQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_43.setTransform(-77.8,-172);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgDAkQgEgGAAgLIAAgeIgJAAIgDgBIgBgDIAAgCIABgDIADAAIAJAAIAAgRIABgCIACgBIAFAAIACABIAAACIAAARIANAAIADAAIABADIAAACIgBADIgDABIgNAAIAAAdQAAAHACADQADAEAFAAIADgBIADAAIABAAIABACIAAAFIgBACIgBAAIgDABIgDAAQgMAAgEgFg");
	this.shape_44.setTransform(-85,-171.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgCAuIgCgBIgBgDIAAg2IABgCIACgBIAFAAIACABIAAACIAAA2IAAADIgCABgAgEghQgCgBAAgDQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_45.setTransform(-88.7,-172);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AgIAvIgHgBIgGgCIgCgCIAAgCIAAgEQAAgBAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAIACgBIAEACIAGACIAKABQAJAAAFgFQAFgFAAgKIAAgNIgBAAQgDAFgGADQgFACgFAAQgJAAgGgEQgGgEgDgHQgEgGAAgJQAAgGACgGQACgGADgEQAEgFAFgCQAFgDAHAAQAGAAAFADQAFACAEAGIAAAAIAAgGIABgCIACgBIAFAAIACABIABACIAAA8QAAAPgIAHQgIAHgPAAIgHAAgAgJgiQgEAEgCAFQgCAEAAAGQAAAFACAFQACAFAEACQAEAEAFgBQAJAAAFgFQAFgFAAgKQAAgGgDgFQgCgGgEgCQgFgDgFgBQgFABgEADg");
	this.shape_46.setTransform(-94.2,-169);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgCAuIgCgBIgBgDIAAg2IABgCIACgBIAFAAIACABIAAACIAAA2IAAADIgCABgAgEghQgCgBAAgDQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_47.setTransform(-99.2,-172);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AgQArQgGgFgDgHQgEgIAAgJQAAgFACgGQACgFADgEQAEgFAFgCQAFgDAHAAQAFAAAGADQAFACADAFIABAAIAAglIABgCIACgBIAFAAIACABIABACIAABVIgBADIgCABIgFAAIgCgBIgBgDIAAgFIgBAAQgDAGgGACQgFACgFAAQgJAAgGgEgAgJgDQgEADgCAEQgCAFAAAGQAAAFACAFQACAGAEADQAEAEAFAAQAGAAAEgDQAEgDACgFQADgFAAgHQAAgHgDgFQgCgEgEgDQgFgDgFAAQgFABgEADg");
	this.shape_48.setTransform(-104.7,-172.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AATAvIgCgBIgBgDIAAggQAAgIgCgDQgDgGgIAAQgGAAgEADQgEADgCAFQgDAGAAAGIAAAaIAAADIgCABIgFAAIgDgBIgBgDIAAhVIABgCIADgBIAFAAIACABIAAACIAAAlIABAAQAEgFAFgDQAFgCAGAAQAHAAAEACQAFADADAEQACADABAEIAAAJIAAAhIAAADIgCABg");
	this.shape_49.setTransform(-115.4,-172.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgHAcQgIgFgDgHQgEgHgBgJQABgIAEgHQADgHAIgFQAGgEAKAAIAGAAIAGACIACACIAAADIgBADIAAABIgCABIgDgCIgHgBQgHABgEADQgFADgCAFQgDAFAAAFQAAAGADAFQACAFAGAEQADACAIAAIAEAAIAEgBIACgBIABABIABABIAAAEIgBADIgCABIgGABIgFABQgKAAgGgEg");
	this.shape_50.setTransform(-121.7,-170.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgQAcQgGgGgDgHQgEgHAAgIQAAgGACgGQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFACADAEIABAAIAAgDIABgDIACgBIAFAAIACABIABADIAAA1IgBADIgCABIgFAAIgCgBIgBgDIAAgFIAAAAQgEAFgFADQgFACgGAAQgJAAgGgEgAgJgTQgEAEgCAFQgCAFAAAFQAAAFACAFQACAGAEADQAEADAFAAQAGAAAEgCQAEgEACgEQADgGAAgGQAAgGgDgFQgCgFgEgDQgFgDgFAAQgFAAgEADg");
	this.shape_51.setTransform(-128.6,-170.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgNAcQgGgEgFgIQgDgGAAgKQAAgJADgHQAEgHAGgEQAHgEAIAAQANAAAHAIQAHAIAAAOIgBADIgDABIgoAAQABAFACAFQADAFAFACQAEACAFAAIAJAAIAGgCIADgCIABABIABABIAAAFIAAADIgDABIgIACIgJABQgJAAgIgEgAARgFQAAgIgFgEQgEgEgHgBQgEABgEACQgDACgDAEQgCADAAAFIAgAAIAAAAg");
	this.shape_52.setTransform(-135.5,-170.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgDAkQgEgGAAgLIAAgeIgJAAIgCgBIgCgDIAAgCIACgDIACAAIAJAAIAAgRIABgCIACgBIAFAAIABABIABACIAAARIAOAAIACAAIABADIAAACIgBADIgCABIgOAAIAAAdQAAAHACADQADAEAEAAIAFgBIACAAIABAAIAAACIAAAFIAAACIgBAAIgDABIgEAAQgKAAgFgFg");
	this.shape_53.setTransform(-144.7,-171.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgPAdQgEgCgDgEQgDgEAAgFIgBgJIAAggIABgDIABAAIAGAAIACAAIABADIAAAeQgBAFACAEQABAFADACQADADAFAAQAGAAAEgEQAEgDACgGQACgFABgGIAAgZIABgDIACAAIAFAAIACAAIABADIAAA1IgBADIgCABIgFAAIgCgBIgBgDIAAgGIgBAAQgDAGgFADQgGACgGAAQgGAAgFgCg");
	this.shape_54.setTransform(-150.5,-170.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgPAcQgHgDgEgIQgEgHgBgKQABgKAEgGQAEgHAHgFQAIgDAHAAQAJAAAHADQAHAFAEAHQAFAGAAAKQAAAKgFAHQgEAIgHADQgHAEgJAAQgHAAgIgEgAgKgTQgEAEgDAEQgCAGAAAFQAAAGACAFQADAFAEAEQAFACAFAAQAGAAAFgCQAFgEACgFQACgFAAgGQAAgFgCgGQgCgEgFgEQgFgDgGAAQgFAAgFADg");
	this.shape_55.setTransform(-158,-170.5);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AARAvIgEgBIgCgCIgagdIAAAcIgBADIgBABIgGAAIgCgBQAAgBAAAAQgBAAAAAAQAAgBAAAAQAAgBAAAAIAAhVIABgCIACgBIAGAAIABABIABACIAAA1IAYgXIABgBIAEgBIAHAAIACABIABABIgBABIgBABIgYAWIAcAfIABABIAAABIAAABIgCABg");
	this.shape_56.setTransform(-167.9,-172.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgOAfIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFQADgGADgCQAFgCAEAAIAEAAIACAAIACABIABACIAAAFIgBACIgBAAIgCAAIgFAAQgFAAgEADQgDAEgBAGQgCAFAAAFIAAAZIAAACIgDABg");
	this.shape_57.setTransform(-173.3,-170.6);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgPAcQgHgDgEgIQgFgHAAgKQAAgKAFgGQAEgHAHgFQAIgDAHAAQAIAAAIADQAHAFAEAHQAFAGAAAKQAAAKgFAHQgEAIgHADQgIAEgIAAQgHAAgIgEgAgKgTQgEAEgDAEQgCAGAAAFQAAAGACAFQADAFAEAEQAFACAFAAQAHAAAEgCQAEgEACgFQADgFAAgGQAAgFgDgGQgCgEgEgEQgEgDgHAAQgFAAgFADg");
	this.shape_58.setTransform(-179.8,-170.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AATAfIgCgBIgCgCIgPgvIgNAvIgCACIgCABIgHAAIgDgBIgBgCIgRg1IgBgCIAAgBIABgBIABgBIAHAAIACABIACACIANAuIAAAAIAOguIACgCIACgBIAGAAIACABIACACIAOAuIAAAAIANguIACgCIACgBIAGAAIABABIABABIAAABIgBACIgRA1IgBACIgDABg");
	this.shape_59.setTransform(-188.5,-170.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgPAdQgEgCgDgEQgDgEAAgFIgBgJIAAggIABgDIACAAIAEAAIADAAIABADIAAAeQgBAFACAEQABAFADACQADADAFAAQAGAAAEgEQAEgDACgGQACgFAAgGIAAgZIACgDIACAAIAFAAIACAAIABADIAAA1IgBADIgCABIgFAAIgCgBIgBgDIAAgGIgBAAQgDAGgGADQgFACgGAAQgGAAgFgCg");
	this.shape_60.setTransform(-200.6,-170.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AgPAcQgHgDgEgIQgEgHgBgKQABgKAEgGQAEgHAHgFQAIgDAHAAQAJAAAHADQAHAFAFAHQAEAGAAAKQAAAKgEAHQgFAIgHADQgHAEgJAAQgHAAgIgEgAgKgTQgEAEgCAEQgDAGAAAFQAAAGADAFQACAFAEAEQAEACAGAAQAGAAAFgCQAFgEACgFQACgFAAgGQAAgFgCgGQgCgEgFgEQgFgDgGAAQgGAAgEADg");
	this.shape_61.setTransform(-208,-170.5);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgNAvQgBAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAIAAgBIAAgBIALgaIgXg7IAAgBIAAgBQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAABAAIAHAAIACABIABACIAPAuIABAAIAQguIABgCIACgBIAHAAQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIAAABIgBABIggBWIgBACIgCABg");
	this.shape_62.setTransform(-214.9,-168.9);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgaAvIgCgBIgBgDIAAhUIABgDIACAAIAFAAIACAAIABADIAAAFQAEgFAGgCQAFgDAGAAQAJAAAGAFQAGAEADAHQADAIAAAJQAAAGgCAFIgFAJQgDAFgFACQgFADgHAAQgGAAgFgCQgGgDgDgFIgBAAIAAAkIAAADIgDABgAgJghQgEACgCAFQgDAFAAAHQABALAFAFQAFAGAHAAQAGAAAEgEQAEgDACgEIACgLIgCgKQgCgFgDgEQgEgDgHAAQgEAAgFADg");
	this.shape_63.setTransform(-225,-169.1);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgFArQgEgCgBgGQgBgFAAgGIAAhDIABgCIACgBIAFAAIACABIABACIAABDQAAAGABADQACADAEAAIACAAIABAAIACABIAAACIAAAEIAAACIgBABIgDAAIgDABQgGAAgEgEg");
	this.shape_64.setTransform(-230.2,-172.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgMAcQgHgEgFgIQgDgGAAgKQAAgJADgHQAEgHAGgEQAHgEAIAAQANAAAHAIQAHAIAAAOIgBADIgDABIgoAAQABAFADAFQADAFAEACQAEACAGAAIAJAAIAFgCIADgCIABABIABABIAAAFIAAADIgDABIgIACIgJABQgKAAgGgEgAARgFQAAgIgFgEQgEgEgHgBQgEABgEACQgEACgBAEQgDADAAAFIAgAAIAAAAg");
	this.shape_65.setTransform(-235.7,-170.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AAUAvIgCgBQgBgBAAAAQAAAAAAAAQAAgBAAAAQgBgBAAAAIAAggQAAgIgDgDQgDgGgHAAQgFAAgFADQgEADgCAFQgDAGABAGIAAAaIgBADIgCABIgFAAIgCgBIgBgDIAAhVIABgCIACgBIAFAAIACABIABACIAAAlIAAAAQAEgFAFgDQAFgCAGAAQAHAAAEACQAFADACAEQADADABAEIABAJIAAAhIgBADIgCABg");
	this.shape_66.setTransform(-242.9,-172.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgOAcQgIgDgEgIQgFgHAAgKQAAgKAFgGQAEgHAIgFQAGgDAIAAQAJAAAHADQAHAFAFAHQAEAGAAAKQAAAKgEAHQgFAIgHADQgHAEgJAAQgIAAgGgEgAgKgTQgEAEgCAEQgDAGAAAFQAAAGADAFQACAFAEAEQAFACAFAAQAGAAAFgCQAFgEABgFQADgFAAgGQAAgFgDgGQgBgEgFgEQgFgDgGAAQgFAAgFADg");
	this.shape_67.setTransform(-253.8,-170.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgCAkQgFgGAAgLIAAgeIgJAAIgDgBIgBgDIAAgCIABgDIADAAIAJAAIAAgRIABgCIACgBIAEAAIADABIAAACIAAARIANAAIADAAIAAADIAAACIAAADIgDABIgNAAIAAAdQAAAHADADQACAEAFAAIADgBIADAAIABAAIABACIAAAFIgBACIgCAAIgCABIgDAAQgMAAgDgFg");
	this.shape_68.setTransform(-259.8,-171.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgCIABgFIAAgBIACgBIADABIAEABIAHABIADgBQABAAABAAQAAAAABAAQAAgBABAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgGgEQgHgDgFgDQgDgEAAgHQAAgGACgEQADgEAFgCQAFgBAEAAIAHAAIAGACIADACIAAADIgBADIgBACIgCAAIgDgBIgDgBIgGgBQgDAAgDACQgCACAAADQAAAEADACIAJAFQAFADAEACQACACACADQACADgBAFQABAGgEAEQgEAEgEACQgFACgEAAIgIgBg");
	this.shape_69.setTransform(80.6,-187);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgMAcQgIgEgDgHQgEgIgBgJQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAHAAAQIgCACIgDAAIgnAAQAAAGADAFQADAEAEADQAFADAFgBIAJgBIAFgBIADgCIABABIAAABIABAFIgBADIgBABIgJACIgJABQgJAAgHgEgAARgFQAAgHgEgFQgFgEgHgBQgEABgEACQgDACgCADQgDAEAAAFIAgAAIAAAAg");
	this.shape_70.setTransform(74.6,-187);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgPAdQgFgCgCgEQgCgEgCgFIAAgJIAAggIAAgDIACAAIAGAAIACAAIAAADIAAAeQABAFABAEQABAFADACQADADAGAAQAFAAAEgEQAEgDADgGQACgFAAgGIAAgZIABgDIABAAIAGAAIACAAIAAADIAAA1IAAADIgCABIgFAAIgCgBIgBgDIAAgGIgBAAQgEAGgEADQgGACgGAAQgGAAgFgCg");
	this.shape_71.setTransform(67.5,-186.9);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgFArQgEgCgBgGQgBgFAAgHIAAhBIABgDIACgBIAFAAIACABIABADIAABCQAAAGABADQACADAEABIACAAIABAAIACAAIAAACIAAAEIAAADIgBAAIgDABIgDAAQgGAAgEgEg");
	this.shape_72.setTransform(62.5,-188.5);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgIAcQgHgFgDgHQgEgHgBgJQABgIAEgHQAEgHAGgEQAIgFAJAAIAHAAIAFACIACACIAAADIAAADIgBABIgCABIgDgCIgIgBQgGABgEADQgEADgDAFQgDAFABAFQgBAGADAFQADAGAFADQADACAHAAIAGAAIADgCIACAAIACAAIAAACIABAFIgBACIgDABIgFABIgGABQgJAAgIgEg");
	this.shape_73.setTransform(57.7,-187);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgNAcQgGgEgEgHQgEgIAAgJQAAgJAEgHQADgHAGgEQAHgEAIAAQANAAAHAIQAHAHABAQIgBACIgEAAIgnAAQAAAGACAFQADAEAFADQAFADAEgBIAJgBIAGgBIADgCIABABIAAABIABAFIgBADIgCABIgIACIgJABQgJAAgIgEgAARgFQgBgHgEgFQgDgEgIgBQgEABgEACQgEACgCADQgCAEAAAFIAgAAIAAAAg");
	this.shape_74.setTransform(47.9,-187);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AATAuIgCgBIgBgCIAAggQAAgIgCgDQgDgGgIAAQgGAAgEAEQgEACgCAFQgDAFAAAHIAAAaIAAACIgCABIgFAAIgDgBIgBgCIAAhVIABgCIADgBIAFAAIACABIAAACIAAAlIABAAQAEgFAFgDQAFgCAGAAQAHAAAEACQAFADADADQACAEABAEIAAAJIAAAhIAAACIgCABg");
	this.shape_75.setTransform(40.8,-188.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgDAkQgEgGAAgLIAAgeIgJAAIgDgBIgBgDIAAgCIABgDIADAAIAJAAIAAgRIABgCIACgBIAFAAIACABIAAACIAAARIANAAIADAAIABADIAAACIgBADIgDABIgNAAIAAAdQAAAHACADQADAEAFAAIADgBIADAAIABAAIABACIAAAFIgBACIgBAAIgDABIgDAAQgLAAgFgFg");
	this.shape_76.setTransform(34.8,-187.9);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgNAcQgGgEgEgHQgEgIgBgJQABgJAEgHQADgHAGgEQAHgEAIAAQANAAAHAIQAIAHAAAQIgBACIgEAAIgnAAQAAAGACAFQADAEAFADQAFADAEgBIAJgBIAGgBIADgCIABABIAAABIABAFIgBADIgCABIgIACIgJABQgJAAgIgEgAARgFQgBgHgDgFQgEgEgIgBQgEABgEACQgEACgCADQgCAEAAAFIAgAAIAAAAg");
	this.shape_77.setTransform(25.8,-187);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgCIABgFIAAgBIACgBIACABIAFABIAHABIADgBQABAAABAAQAAAAABAAQAAgBABAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgHgEQgGgDgFgDQgDgEAAgHQAAgGACgEQADgEAFgCQAFgBAEAAIAHAAIAGACIADACIAAADIgBADIgBACIgCAAIgDgBIgDgBIgGgBQgEAAgCACQgCACAAADQAAAEADACQADACAGADQAFADADACQAEACABADQACADgBAFQAAAGgDAEQgEAEgEACQgGACgDAAIgIgBg");
	this.shape_78.setTransform(19.8,-187);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgYAiQgJgJAAgSIAAguIABgDIACgBIAGAAIACABIAAADIAAAsQABAOAFAHQAGAHAKAAQAKAAAGgHQAGgHAAgOIAAgsIAAgDIADgBIAFAAIADABIABADIAAAuQAAASgJAJQgJAKgQAAQgQAAgIgKg");
	this.shape_79.setTransform(12.7,-188.2);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgFAFQgCgCAAgDQAAgDACgCQACgCADAAQADAAADACQACACAAADQAAADgCACQgDADgDAAQgDAAgCgDg");
	this.shape_80.setTransform(3.1,-184.6);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgOAfIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFQADgGAEgCQADgCAGAAIADAAIACAAIACABIABACIAAAFIgBACIgBAAIgDAAIgDAAQgGAAgEADQgDAEgBAGQgCAFAAAFIAAAZIAAACIgDABg");
	this.shape_81.setTransform(-0.4,-187.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgMAcQgHgEgFgHQgDgIgBgJQABgJADgHQAEgHAHgEQAGgEAIAAQANAAAHAIQAIAHgBAQIgBACIgDAAIgoAAQABAGADAFQADAEAEADQAEADAGgBIAJgBIAFgBIADgCIABABIABABIAAAFIAAADIgCABIgJACIgJABQgKAAgGgEgAARgFQAAgHgEgFQgFgEgHgBQgEABgEACQgDACgCADQgDAEAAAFIAgAAIAAAAg");
	this.shape_82.setTransform(-6.6,-187);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgJAtQgFgDgEgFIAAAFIgBADIgCABIgFAAIgCgBIgBgDIAAhVIABgCIACgBIAFAAIADABIAAACIAAAlIABAAQAEgFAFgCQAFgDAGAAQAJAAAGAFQAGAEADAHQADAHAAAJQAAAIgDAHQgDAHgGAFQgGAEgJAAQgGAAgGgCgAgJgDQgEACgCAEQgDAFAAAHQABALAFAGQAFAGAHAAQAGAAAEgDQAEgDACgFQACgGAAgGIgCgKQgCgFgDgDQgEgDgHAAQgEAAgFADg");
	this.shape_83.setTransform(-13.5,-188.5);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AAlAfIgCgBIgBgCIAAgfIgBgJQgBgEgDgDQgCgCgFAAQgFAAgDADIgGAGIgBAIIgBAHIAAAZIgBACIgCABIgEAAIgCgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQgBgBAAAAIAAgfIgBgJQAAgEgDgDQgDgCgFAAQgFAAgEADQgEADgBAFQgCAGAAAFIAAAbIgBACIgCABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIABADIAAAFIAEgFIAGgEQADgBAFAAQAJAAAFADQADADACAGIAEgGQADgDAEgCQADgBAGAAQAHAAAEACQAFACACAEQACAEAAAFIABAJIAAAgIgBACIgCABg");
	this.shape_84.setTransform(-22.9,-187.1);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgPAdQgFgCgCgEQgCgEgBgFIgBgJIAAggIABgDIABAAIAGAAIACAAIAAADIAAAeQABAFABAEQABAFADACQADADAGAAQAFAAAEgEQAFgDABgGQADgFAAgGIAAgZIABgDIABAAIAGAAIACAAIABADIAAA1IgBADIgCABIgFAAIgCgBIgBgDIAAgGIgBAAQgDAGgFADQgGACgGAAQgGAAgFgCg");
	this.shape_85.setTransform(-32.1,-186.9);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AAUAfIgCgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQgBgBAAAAIAAgfQAAgIgDgFQgDgFgHAAQgFAAgFADQgEAEgCAFQgDAFABAGIAAAaIgBACIgDABIgEAAIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFIAAAAQAEgFAFgDQAFgCAGAAQAHAAAEACQAFACACAEQADAEABAFIABAJIAAAgIgBACIgCABg");
	this.shape_86.setTransform(-39.5,-187.1);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgNAvQgBAAAAAAQgBgBAAAAQAAAAAAAAQAAgBAAAAIAAgBIAAgBIALgaIgXg7IAAgBIAAgBQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAABAAIAHAAIACABIABACIAPAuIABAAIAQguIABgCIACgBIAHAAQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIAAABIgBABIggBWIgBACIgCABg");
	this.shape_87.setTransform(-49.7,-185.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgOAfIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFQADgGADgCQAFgCAEAAIAEAAIACAAIACABIABACIAAAFIgBACIgBAAIgCAAIgFAAQgFAAgEADQgDAEgBAGQgCAFAAAFIAAAZIgBACIgCABg");
	this.shape_88.setTransform(-54.6,-187.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgNAcQgGgEgFgHQgDgIAAgJQAAgJADgHQAEgHAGgEQAHgEAIAAQANAAAHAIQAHAHAAAQIgBACIgDAAIgoAAQABAGACAFQADAEAFADQAEADAFgBIAJgBIAGgBIADgCIABABIABABIAAAFIAAADIgDABIgIACIgJABQgJAAgIgEgAARgFQAAgHgFgFQgEgEgHgBQgEABgEACQgDACgDADQgCAEAAAFIAgAAIAAAAg");
	this.shape_89.setTransform(-60.8,-187);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgDAkQgEgGAAgLIAAgeIgJAAIgDgBIgBgDIAAgCIABgDIADAAIAJAAIAAgRIABgCIACgBIAFAAIACABIAAACIAAARIANAAIADAAIABADIAAACIgBADIgDABIgNAAIAAAdQAAAHACADQADAEAEAAIAEgBIADAAIABAAIABACIAAAFIgBACIgBAAIgDABIgEAAQgKAAgFgFg");
	this.shape_90.setTransform(-66.5,-187.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgCIABgFIAAgBIACgBIACABIAFABIAHABIADgBQABAAABAAQAAAAABAAQAAgBABAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgHgEQgHgDgEgDQgDgEAAgHQAAgGACgEQADgEAFgCQAFgBAEAAIAHAAIAGACIADACIAAADIgBADIgCACIgBAAIgDgBIgDgBIgGgBQgEAAgCACQgCACAAADQAAAEADACQADACAGADQAFADADACQAEACABADQABADAAAFQAAAGgDAEQgDAEgFACQgGACgDAAIgIgBg");
	this.shape_91.setTransform(-71.2,-187);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgNAvQgBAAAAAAQgBgBAAAAQAAAAAAAAQAAgBAAAAIAAgBIABgBIAKgaIgXg7IgBgBIAAgBQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAABAAIAGAAIADABIABACIAPAuIABAAIAQguIABgCIADgBIAFAAQABAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIAAABIgBABIggBWIgBACIgCABg");
	this.shape_92.setTransform(-76.9,-185.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#000000").s().p("AAlAfIgDgBIAAgCIAAgfIgBgJQgBgEgCgDQgDgCgFAAQgFAAgEADIgFAGIgCAIIgBAHIAAAZIAAACIgCABIgFAAIgCgBIAAgCIAAgfIgBgJQgBgEgDgDQgCgCgFAAQgHAAgDADQgDADgCAFQgCAGAAAFIAAAbIAAACIgDABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFIAEgFIAGgEQAEgBAFAAQAIAAAEADQAEADACAGIAEgGQADgDAEgCQADgBAGAAQAHAAAEACQAFACABAEQADAEAAAFIABAJIAAAgIgBACIgCABg");
	this.shape_93.setTransform(-85.5,-187.1);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#000000").s().p("AgQAcQgGgGgDgHQgEgHAAgIQAAgFACgHQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFACADADIABAAIAAgCIABgDIACgBIAFAAIACABIABADIAAA1IgBACIgCABIgFAAIgCgBIgBgCIAAgGIAAAAQgEAGgFACQgFADgGAAQgJAAgGgEgAgJgSQgEADgCAFQgCAFAAAFQAAAFACAFQACAGAEADQAEAEAFgBQAGAAAEgCQAEgEACgFQADgEAAgHQAAgGgDgFQgCgFgEgDQgFgDgFAAQgFAAgEAEg");
	this.shape_94.setTransform(-98.3,-187);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#000000").s().p("AgDAvIgDgBIAAgCIAAgwIgLAAIgDAAIAAgDIAAgCIAAgDIADgBIALAAIAAgLQAAgLAFgGQAEgFAKAAIAEAAIACABIACAAIAAACIAAAFIgBACIgBAAIgCAAIgEgBQgEAAgCAEQgDADAAAIIAAAJIAOAAIACABIAAADIAAACIAAADIgCAAIgOAAIAAAwIgBACIgCABg");
	this.shape_95.setTransform(-107.6,-188.7);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#000000").s().p("AgPAcQgHgEgEgGQgEgIgBgKQABgKAEgGQAEgIAHgDQAIgEAHAAQAJAAAHAEQAHADAFAIQAEAGAAAKQAAAKgEAIQgFAGgHAEQgHAEgJAAQgHAAgIgEgAgKgSQgEADgCAEQgDAGAAAFQAAAGADAFQACAFAEAEQAEACAGAAQAGAAAFgCQAFgEACgFQACgFAAgGQAAgFgCgGQgCgEgFgDQgFgEgGAAQgGAAgEAEg");
	this.shape_96.setTransform(-113.5,-187);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#000000").s().p("AgIAvIgHgCIgGgBIgCgCIAAgCIAAgEQAAgBAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAIACgBIAEACIAGACIAKABQAJAAAFgFQAFgFAAgKIAAgNIgBAAQgDAFgGADQgFACgFAAQgJAAgGgFQgGgEgDgGQgEgHAAgJQAAgFACgGQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFADAEAFIAAAAIAAgGIABgCIACgBIAFAAIACABIABACIAAA8QAAAPgIAHQgIAHgPAAIgHAAgAgJgiQgEAEgCAEQgCAFAAAGQAAAFACAFQACAFAEACQAEAEAFAAQAJgBAFgFQAFgFAAgKQAAgHgDgEQgCgFgEgEQgFgCgFAAQgFAAgEADg");
	this.shape_97.setTransform(-124.7,-185.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#000000").s().p("AATAfIgBgBIgBgCIAAgfQAAgIgEgFQgCgFgJAAQgEAAgFADQgEAEgCAFQgCAFgBAGIAAAaIAAACIgCABIgGAAIgCgBIAAgCIAAg1IAAgDIACgBIAFAAIACABIABADIAAAFIABAAQADgFAGgDQAFgCAGAAQAHAAAFACQAEACADAEQACAEABAFIAAAJIAAAgIAAACIgCABg");
	this.shape_98.setTransform(-131.9,-187.1);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAACgCACQgCACgDABQgCgBgCgCg");
	this.shape_99.setTransform(-137.1,-188.5);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#000000").s().p("AARAuIgEAAIgCgCIgagdIAAAcIgBACIgBABIgGAAIgCgBQAAAAAAAAQgBAAAAAAQAAgBAAAAQAAgBAAAAIAAhVIABgCIACgBIAGAAIABABIABACIAAA1IAYgWIABgCIAEgBIAHAAIACABIABABIgBABIgBABIgYAWIAcAfIABABIAAABIAAABIgCAAg");
	this.shape_100.setTransform(-141.3,-188.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#000000").s().p("AATAfIgCgBIgBgCIAAgfQAAgIgCgFQgDgFgIAAQgGAAgEADQgEAEgCAFQgDAFAAAGIAAAaIAAACIgDABIgEAAIgDgBIgBgCIAAg1IABgDIADgBIAEAAIACABIABADIAAAFIABAAQAEgFAFgDQAFgCAGAAQAHAAAEACQAFACADAEQACAEABAFIAAAJIAAAgIAAACIgCABg");
	this.shape_101.setTransform(-148.7,-187.1);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAACgCACQgCACgDABQgCgBgCgCg");
	this.shape_102.setTransform(-153.9,-188.5);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#000000").s().p("AAUAuIgCgBQgBAAAAAAQAAAAAAAAQAAgBAAAAQgBgBAAAAIAAggQAAgIgDgDQgDgGgHAAQgFAAgFAEQgEACgCAFQgDAFABAHIAAAaIgBACIgCABIgFAAIgCgBIgBgCIAAhVIABgCIACgBIAFAAIACABIABACIAAAlIAAAAQAEgFAFgDQAFgCAGAAQAHAAAEACQAFADACADQADAEABAEIABAJIAAAhIgBACIgCABg");
	this.shape_103.setTransform(-159.2,-188.6);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#000000").s().p("AgCAkQgFgGAAgLIAAgeIgJAAIgCgBIgBgDIAAgCIABgDIACAAIAJAAIAAgRIABgCIACgBIAEAAIACABIABACIAAARIAOAAIACAAIAAADIAAACIAAADIgCABIgOAAIAAAdQAAAHADADQACAEAEAAIAFgBIACAAIABAAIAAACIAAAFIAAACIgCAAIgCABIgEAAQgKAAgEgFg");
	this.shape_104.setTransform(-165.2,-187.9);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgCIABgFIAAgBIACgBIACABIAFABIAHABIADgBQABAAABAAQAAAAABAAQAAgBABAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgHgEQgHgDgEgDQgDgEAAgHQAAgGACgEQADgEAFgCQAFgBAEAAIAHAAIAGACIADACIAAADIgBADIgCACIgBAAIgDgBIgDgBIgGgBQgEAAgCACQgCACAAADQAAAEADACQADACAGADQAFADADACQAEACABADQABADAAAFQAAAGgDAEQgDAEgFACQgGACgDAAIgIgBg");
	this.shape_105.setTransform(-173.4,-187);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAACgCACQgCACgDABQgCgBgCgCg");
	this.shape_106.setTransform(-177.5,-188.5);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#000000").s().p("AgOAfIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIABADIAAAFQADgGAEgCQADgCAGAAIADAAIACAAIACABIABACIAAAFIAAACIgCAAIgDAAIgDAAQgHAAgDADQgDAEgCAGQgBAFAAAFIAAAZIAAACIgDABg");
	this.shape_107.setTransform(-184.3,-187.1);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#000000").s().p("AgNAcQgGgEgFgHQgDgIAAgJQAAgJADgHQAEgHAGgEQAHgEAIAAQANAAAHAIQAHAHAAAQIgBACIgDAAIgoAAQABAGACAFQADAEAFADQAEADAFgBIAJgBIAGgBIADgCIABABIABABIAAAFIAAADIgDABIgIACIgJABQgJAAgIgEgAARgFQAAgHgFgFQgEgEgHgBQgEABgEACQgDACgDADQgCAEAAAFIAgAAIAAAAg");
	this.shape_108.setTransform(-190.4,-187);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#000000").s().p("AgCAkQgFgGAAgLIAAgeIgJAAIgCgBIgBgDIAAgCIABgDIACAAIAJAAIAAgRIABgCIACgBIAEAAIACABIABACIAAARIAOAAIACAAIAAADIAAACIAAADIgCABIgOAAIAAAdQAAAHADADQACAEAEAAIAFgBIACAAIABAAIAAACIAAAFIAAACIgCAAIgCABIgEAAQgKAAgEgFg");
	this.shape_109.setTransform(-196.1,-187.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#000000").s().p("AgPAdQgFgCgCgEQgCgEgCgFIgBgJIAAggIABgDIACAAIAGAAIACAAIAAADIAAAeQABAFABAEQABAFADACQADADAGAAQAFAAAEgEQAFgDACgGQACgFAAgGIAAgZIAAgDIACAAIAGAAIACAAIAAADIAAA1IAAADIgCABIgFAAIgCgBQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAgBIAAgGIgBAAQgEAGgEADQgGACgFAAQgIAAgEgCg");
	this.shape_110.setTransform(-202,-186.9);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#000000").s().p("AgaAvIgCgBIgBgDIAAhUIABgDIACAAIAFAAIACAAIABADIAAAFQAEgFAGgCQAFgDAGAAQAJAAAGAFQAGAEADAHQADAIAAAJQAAAGgCAFIgFAJQgDAFgFACQgFADgHAAQgGAAgFgCQgGgDgDgFIgBAAIAAAkIAAADIgDABgAgJghQgEACgCAFQgDAFAAAHQABALAFAFQAFAGAHAAQAGAAAEgEQAEgDACgEIACgLIgCgKQgCgFgDgEQgEgDgHAAQgEAAgFADg");
	this.shape_111.setTransform(-209.2,-185.5);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#000000").s().p("AAlAfIgCgBIgBgCIAAgfIgBgJQgBgEgDgDQgCgCgFAAQgFAAgDADIgGAGIgBAIIgBAHIAAAZIgBACIgCABIgEAAIgCgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQgBgBAAAAIAAgfIgBgJQAAgEgDgDQgDgCgFAAQgFAAgEADQgEADgBAFQgCAGAAAFIAAAbIgBACIgCABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIABADIAAAFIAEgFIAGgEQADgBAFAAQAJAAAFADQADADACAGIAEgGQADgDAEgCQADgBAGAAQAHAAAEACQAFACACAEQACAEAAAFIABAJIAAAgIgBACIgCABg");
	this.shape_112.setTransform(-218.6,-187.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#000000").s().p("AgPAcQgHgEgEgGQgEgIgBgKQABgKAEgGQAEgIAHgDQAIgEAHAAQAJAAAHAEQAHADAFAIQAEAGAAAKQAAAKgEAIQgFAGgHAEQgHAEgJAAQgHAAgIgEgAgKgSQgEADgCAEQgDAGAAAFQAAAGADAFQACAFAEAEQAEACAGAAQAGAAAFgCQAFgEACgFQACgFAAgGQAAgFgCgGQgCgEgFgDQgFgEgGAAQgGAAgEAEg");
	this.shape_113.setTransform(-227.8,-187);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#000000").s().p("AgHAcQgIgFgDgHQgEgHgBgJQABgIAEgHQADgHAIgEQAGgFAKAAIAGAAIAGACIACACIAAADIgBADIAAABIgCABIgDgCIgHgBQgHABgEADQgFADgCAFQgDAFAAAFQAAAGADAFQACAGAGADQADACAIAAIAEAAIAEgCIACAAIABAAIABACIAAAFIgBACIgCABIgGABIgFABQgKAAgGgEg");
	this.shape_114.setTransform(-234.2,-187);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#000000").s().p("AgMAcQgIgEgDgHQgEgIgBgJQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAHAAAQIgCACIgDAAIgnAAQAAAGADAFQADAEAEADQAFADAFgBIAJgBIAFgBIADgCIABABIAAABIABAFIgBADIgBABIgJACIgJABQgJAAgHgEgAARgFQAAgHgEgFQgFgEgHgBQgEABgEACQgDACgCADQgDAEAAAFIAgAAIAAAAg");
	this.shape_115.setTransform(-244,-187);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#000000").s().p("AATAuIgBgBIgBgCIAAggQAAgIgEgDQgCgGgJAAQgEAAgFAEQgEACgCAFQgCAFgBAHIAAAaIAAACIgCABIgGAAIgCgBIAAgCIAAhVIAAgCIACgBIAGAAIACABIAAACIAAAlIABAAQADgFAGgDQAFgCAGAAQAHAAAFACQAEADADADQACAEABAEIAAAJIAAAhIAAACIgCABg");
	this.shape_116.setTransform(-251.1,-188.6);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#000000").s().p("AgCArIgCgBIgBgCIAAhHIgYAAIgCgBIgBgCIAAgFIABgCIACgBIA7AAIACABIABACIAAAFIgBACIgCABIgYAAIAABHIgBACIgCABg");
	this.shape_117.setTransform(-258.4,-188.3);

	this.instance_3 = new lib.mcfeedbackgfxpanelYG4();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-88,-170.2,0.75,0.75);

	this.text = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text.lineHeight = 22;
	this.text.parent = this;
	this.text.setTransform(-222.4,-161.2,0.75,0.75);

	this.text_1 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_1.lineHeight = 22;
	this.text_1.parent = this;
	this.text_1.setTransform(-237.5,-161.2,0.75,0.75);

	this.text_2 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_2.lineHeight = 22;
	this.text_2.parent = this;
	this.text_2.setTransform(25.4,-176.9,0.75,0.75);

	this.text_3 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_3.lineHeight = 22;
	this.text_3.parent = this;
	this.text_3.setTransform(-3.6,-176.9,0.75,0.75);

	this.text_4 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_4.lineHeight = 22;
	this.text_4.parent = this;
	this.text_4.setTransform(-93.2,-176.9,0.75,0.75);

	this.text_5 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_5.lineHeight = 22;
	this.text_5.parent = this;
	this.text_5.setTransform(-173.9,-176.9,0.75,0.75);

	this.text_6 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_6.lineHeight = 22;
	this.text_6.parent = this;
	this.text_6.setTransform(-202.9,-176.9,0.75,0.75);

	this.text_7 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_7.lineHeight = 22;
	this.text_7.parent = this;
	this.text_7.setTransform(45.6,-192.6,0.75,0.75);

	this.text_8 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_8.lineHeight = 22;
	this.text_8.parent = this;
	this.text_8.setTransform(30.5,-192.6,0.75,0.75);

	this.text_9 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_9.lineHeight = 22;
	this.text_9.parent = this;
	this.text_9.setTransform(-35.1,-192.6,0.75,0.75);

	this.text_10 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_10.lineHeight = 22;
	this.text_10.parent = this;
	this.text_10.setTransform(-64.1,-192.6,0.75,0.75);

	this.text_11 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_11.lineHeight = 22;
	this.text_11.parent = this;
	this.text_11.setTransform(-153.7,-192.6,0.75,0.75);

	this.text_12 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_12.lineHeight = 22;
	this.text_12.parent = this;
	this.text_12.setTransform(-168.7,-192.6,0.75,0.75);

	this.text_13 = new cjs.Text(" ", "16px 'Courier'", "#2A2828");
	this.text_13.lineHeight = 22;
	this.text_13.parent = this;
	this.text_13.setTransform(-234.4,-192.6,0.75,0.75);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#F8F491").s().p("AgCgCIABAAIAEAGg");
	this.shape_118.setTransform(-265.9,-193.3,0.75,0.75);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#D3D0AB").s().p("AgtDbIAAkxQAqgXAVgjQAYgiAAgrQABgMgDgOQAGATgBATQAAAqgXAkQgXAjgoAWIAAExQAAAJABAIQgFgOAAgPg");
	this.shape_119.setTransform(-265.9,-169.2,0.75,0.75);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#D3D0AB").s().p("EAlGgAIQgYgRgggBMhI+AAAQgaABgVAMIgJgJQAXgPAegBMBI+AAAQAjABAaAWQAaAUAHAiQgKgcgZgTg");
	this.shape_120.setTransform(-85.4,-191.8,0.75,0.75);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FDFBD9").s().p("EgkeAFmQgjAAgcgRQgdgSgRgcQgQgbgBgkIAAlDIAQgJQAigTATgcQATgdAAggQAAgsgkglIgbgbIAggUQAhgWAkABMBI8AAAQAkABAcAPQAcASASAdQAQAbABAkIAAHPQAAAjgRAcQgRAcgdASQgbAQglABgEgkGgDQQABAtgYAoQgXAogqAbIAAEgQABAbASASQASATAbAAMBI8AAAQAbAAATgTQASgSAAgbIAAnPQAAgbgSgSQgTgSgbgBMhI9AAAQAZAoAAAvg");
	this.shape_121.setTransform(-87.1,-170.2,0.75,0.75);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FDFBD9").s().p("EgktAFHQgbgBgUgMQgWgMgNgWQgMgUgBgcIAAkxQApgXAXgiQAYgjAAgrQAAgdgMgaQgLgagWgWQAXgOAdgBMBJbAAAQAbABAUAMQAWANANAVQAMAUABAcIAAHPQgBAcgMAUQgNAWgWAMQgUAMgbABg");
	this.shape_122.setTransform(-85.9,-170.2,0.75,0.75);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#F8F491").s().p("AgCgCIABgBIAEAGg");
	this.shape_123.setTransform(-265.6,-193.7,0.75,0.75);

	this.instance_4 = new lib.Group();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-85.8,-144.5,0.75,0.75,0,0,0,251,11.5);
	this.instance_4.alpha = 0.699;

	this.instance_5 = new lib.harYr4instructionboxbkg("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-97.3,-170.6,0.78,0.78);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#000000").s().p("AgFAFQgCgCAAgDQAAgCACgDQACgCADAAQAEAAACACQACADAAACQAAADgCACQgCADgEAAQgDAAgCgDg");
	this.shape_124.setTransform(-79.1,-151.6);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#000000").s().p("AgMAcQgIgEgDgHQgEgIgBgJQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAHgBAQIgBABIgDABIgoAAQABAGADAFQADAEAEADQAEACAGAAIAJgBIAFgCIADgBIABABIABABIAAAFIAAADIgCAAIgJADIgJABQgKAAgGgEgAARgFQAAgHgEgFQgFgFgHAAQgEAAgEADQgDACgCADQgDAFAAAEIAgAAIAAAAg");
	this.shape_125.setTransform(-88.8,-154);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#000000").s().p("AAlAfIgDgBIAAgCIAAgfIgBgJQgBgEgDgDQgCgCgFAAQgFAAgDADIgGAGIgBAIIgBAHIAAAZIgBACIgCABIgEAAIgCgBIgBgCIAAgfIgCgJQAAgEgDgDQgDgCgFAAQgFAAgEADQgEADgBAFQgCAGAAAFIAAAbIgBACIgCABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFIAEgFIAGgEQADgBAFAAQAJAAAFADQADADACAGIAEgGQADgDAEgCQAEgBAFAAQAHAAAEACQAEACADAEQACAEAAAFIABAJIAAAgIgBACIgCABg");
	this.shape_126.setTransform(-105.1,-154.1);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#000000").s().p("AgNAvQgBAAAAAAQgBgBAAAAQAAAAAAAAQgBgBAAAAIABgBIAAgBIALgaIgXg7IAAgBIAAgBQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAABAAIAHAAIACABIABACIAPAuIABAAIAQguIABgCIACgBIAHAAQAAAAAAAAQABAAAAABQAAAAAAAAQAAAAAAABIAAABIAAABIggBWIgBACIgCABg");
	this.shape_127.setTransform(-132,-152.4);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#000000").s().p("AgNAcQgGgEgEgHQgEgIgBgJQABgJAEgHQADgHAGgEQAHgEAIAAQANAAAHAIQAIAHAAAQIgBABIgEABIgnAAQAAAGACAFQADAEAFADQAFACAEAAIAJgBIAGgCIADgBIABABIAAABIABAFIgBADIgCAAIgIADIgJABQgJAAgIgEgAARgFQgBgHgEgFQgDgFgIAAQgEAAgEADQgEACgCADQgCAFAAAEIAgAAIAAAAg");
	this.shape_128.setTransform(-143,-154);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgCIABgFIAAgCIACAAIACAAIAFACIAHABIADgBQABAAABAAQAAAAABAAQAAgBABAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgHgEQgGgDgFgDQgDgEAAgHQAAgGACgEQADgDAFgDQAFgBAEAAIAHAAIAGADIADABIAAACIgBAEIgBACIgCAAIgDAAIgDgCIgGgBQgEAAgCADQgCABAAADQAAAEADACQADACAGADQAFACADADQAEACABADQACAEgBAEQAAAGgDAFQgEAEgEABQgGACgDAAIgIgBg");
	this.shape_129.setTransform(-153.5,-154);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#000000").s().p("AgNAvQgBAAAAAAQgBgBAAAAQAAAAAAAAQAAgBAAAAIAAgBIABgBIAKgaIgXg7IgBgBIAAgBQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAABAAIAGAAIADABIABACIAPAuIABAAIAQguIABgCIADgBIAGAAQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABIAAABIgBABIggBWIgBACIgCABg");
	this.shape_130.setTransform(-159.2,-152.4);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#000000").s().p("AAlAfIgDgBIAAgCIAAgfIgBgJQgBgEgCgDQgDgCgFAAQgFAAgEADIgEAGIgDAIIgBAHIAAAZIAAACIgCABIgFAAIgCgBIgBgCIAAgfIAAgJQgBgEgDgDQgCgCgFAAQgHAAgDADQgDADgCAFQgCAGAAAFIAAAbIAAACIgDABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFIAEgFIAGgEQAEgBAFAAQAIAAAEADQAEADACAGIAFgGQACgDAEgCQADgBAGAAQAHAAAFACQADACACAEQADAEABAFIAAAJIAAAgIAAACIgDABg");
	this.shape_131.setTransform(-167.7,-154.1);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgCIABgFIAAgCIACAAIACAAIAFACIAHABIADgBQABAAABAAQAAAAABAAQAAgBABAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgHgEQgHgDgEgDQgDgEAAgHQAAgGACgEQADgDAFgDQAFgBAEAAIAHAAIAGADIADABIAAACIgBAEIgCACIgBAAIgDAAIgDgCIgGgBQgEAAgCADQgCABAAADQAAAEADACQADACAGADQAFACADADQAEACABADQABAEAAAEQAAAGgDAFQgDAEgFABQgGACgDAAIgIgBg");
	this.shape_132.setTransform(-179.2,-154);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#000000").s().p("AgBAOIgDgBIAAgCIgBgNIAAgFIAAgDIABgCIACgBIAFAAIADABIAAACIAAADIAAAFIAAANIgBACIgCABg");
	this.shape_133.setTransform(-183.5,-158.2);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#000000").s().p("AgPAcQgHgEgEgGQgEgIgBgKQABgJAEgHQAEgIAHgDQAIgEAHAAQAJAAAHAEQAHADAFAIQAEAHAAAJQAAAKgEAIQgFAGgHAEQgHAEgJAAQgHAAgIgEgAgKgSQgEACgCAGQgDAFAAAFQAAAGADAFQACAFAEADQAEADAGAAQAGAAAFgDQAFgDACgFQACgFAAgGQAAgFgCgFQgCgGgFgCQgFgEgGAAQgGAAgEAEg");
	this.shape_134.setTransform(-230.5,-154);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#000000").s().p("AgHAcQgIgEgDgIQgEgHgBgJQABgIAEgHQADgIAIgDQAGgFAKAAIAGAAIAGADIACABIAAACIgBAEIAAACIgCAAIgDgCIgHgBQgHAAgEAEQgFADgCAFQgDAFAAAFQAAAGADAFQACAGAGACQADADAIAAIAEAAIAEgCIACAAIABAAIABACIAAAFIgBABIgCACIgGABIgFABQgKAAgGgEg");
	this.shape_135.setTransform(-236.9,-154);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#000000").s().p("AgMAcQgIgEgDgHQgEgIgBgJQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAHAAAQIgCABIgDABIgnAAQAAAGADAFQADAEAEADQAFACAFAAIAJgBIAFgCIADgBIABABIAAABIABAFIgBADIgBAAIgJADIgJABQgJAAgHgEgAARgFQAAgHgEgFQgFgFgHAAQgEAAgEADQgDACgCADQgDAFAAAEIAgAAIAAAAg");
	this.shape_136.setTransform(-246.7,-154);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#000000").s().p("AATAuIgBgBIgBgCIAAggQAAgIgEgDQgCgFgJgBQgEAAgFAEQgEACgCAFQgCAGgBAGIAAAaIAAACIgCABIgGAAIgCgBIAAgCIAAhVIAAgDIACAAIAGAAIACAAIAAADIAAAlIABAAQADgFAGgCQAFgDAGAAQAHAAAFADQAEACADADQACAEABAEIAAAJIAAAhIAAACIgCABg");
	this.shape_137.setTransform(-253.8,-155.6);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#000000").s().p("AAUAfIgDgBIgBgCIAAgfQAAgIgDgFQgDgFgHAAQgGAAgEADQgEAEgCAFQgCAFAAAGIAAAaIgBACIgDABIgEAAIgCgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQgBgBAAAAIAAg1IACgDIACgBIAEAAIADABIABADIAAAFIAAAAQADgFAGgDQAFgCAGAAQAHAAAEACQAFACACAEQADAEABAFIABAJIAAAgIgBACIgCABg");
	this.shape_138.setTransform(66.2,-170.6);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#000000").s().p("AgQArQgGgFgDgHQgEgIAAgJQAAgFACgGQACgFADgEQAEgFAFgCQAFgDAHAAQAFAAAGADQAFACADAFIABAAIAAglIABgCIACgBIAFAAIACABIABACIAABVIgBADIgCABIgFAAIgCgBQAAAAAAgBQAAAAgBAAQAAAAAAgBQAAAAAAgBIAAgFIgBAAQgDAGgGACQgFACgFAAQgJAAgGgEgAgJgDQgEADgCAEQgCAFAAAGQAAAFACAFQACAGAEADQAEAEAFAAQAGAAAEgDQAEgDACgFQADgFAAgHQAAgHgDgFQgCgEgEgDQgFgDgFAAQgFABgEADg");
	this.shape_139.setTransform(34,-172.1);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#000000").s().p("AATAvIgCgBIAAgDIAAggQAAgIgDgDQgEgGgIAAQgFAAgEADQgEADgCAFQgDAGAAAGIAAAaIAAADIgCABIgGAAIgCgBIgBgDIAAhVIABgCIACgBIAGAAIACABIAAACIAAAlIABAAQADgFAGgDQAFgCAGAAQAHAAAFACQAEADADAEQACADABAEIAAAJIAAAhIAAADIgCABg");
	this.shape_140.setTransform(11.4,-172.1);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#000000").s().p("AgDAkQgEgGAAgLIAAgeIgJAAIgDgBIgBgDIAAgCIABgDIADAAIAJAAIAAgRIABgCIACgBIAFAAIACABIAAACIAAARIANAAIADAAIABADIAAACIgBADIgDABIgNAAIAAAdQAAAHACADQADAEAFAAIADgBIADAAIABAAIABACIAAAFIgBACIgBAAIgDABIgDAAQgMAAgEgFg");
	this.shape_141.setTransform(5.4,-171.5);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#000000").s().p("AgPAcQgHgDgEgIQgFgHAAgKQAAgKAFgGQAEgHAHgFQAIgDAHAAQAIAAAIADQAHAFAEAHQAFAGAAAKQAAAKgFAHQgEAIgHADQgIAEgIAAQgHAAgIgEgAgKgTQgEAEgDAEQgCAGAAAFQAAAGACAFQADAFAEAEQAFACAFAAQAGAAAFgCQAEgEACgFQADgFAAgGQAAgFgDgGQgCgEgEgEQgFgDgGAAQgFAAgFADg");
	this.shape_142.setTransform(-8.5,-170.5);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#000000").s().p("AgDAvIgCgBIgBgCIAAgwIgMAAIgCAAIgBgDIAAgCIABgDIACgBIAMAAIAAgLQAAgLAFgGQAEgFALAAIACAAIAEABIABAAIABACIgBAFIgBACIgBAAIgDAAIgCgBQgFAAgDAEQgCADAAAIIAAAJIANAAIADABIABADIAAACIgBADIgDAAIgNAAIAAAwIAAACIgDABg");
	this.shape_143.setTransform(-14.5,-172.2);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgDIABgDIAAgCIACgBIACABIAFACIAGAAIAEAAQABgBABAAQAAAAABAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgHgEQgGgDgFgDQgDgEAAgHQAAgGADgDQACgFAFgCQAFgBAFAAIAGAAIAGACIADACIAAADIgCADIgBACIgBAAIgCgBIgEgBIgGgBQgEAAgCACQgCACAAADQgBADAEADQADADAGACQAFACADADQADABACAEQABADABAFQgBAGgDAEQgDAFgFABQgGACgEAAIgHgBg");
	this.shape_144.setTransform(-22.7,-170.5);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgDIAAgDIABgCIACgBIADABIAEACIAGAAIAFAAQAAgBABAAQAAAAABAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgGgEQgIgDgDgDQgFgEAAgHQAAgGAEgDQACgFAFgCQAEgBAGAAIAFAAIAHACIACACIAAADIgBADIgBACIgBAAIgCgBIgEgBIgGgBQgDAAgCACQgDACAAADQAAADADADIAJAFQAFACAEADQADABABAEQACADAAAFQAAAGgEAEQgEAFgFABQgFACgEAAIgHgBg");
	this.shape_145.setTransform(-28,-170.5);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#000000").s().p("AgMAcQgIgEgDgIQgEgGgBgKQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAIgBAOIgBADIgDABIgoAAQABAFADAFQADAFAEACQAEACAGAAIAJAAIAFgCIADgCIABABIABABIAAAFIAAADIgCABIgJACIgJABQgKAAgGgEgAARgFQAAgIgEgEQgFgEgHgBQgEABgEACQgDACgCAEQgDADAAAFIAgAAIAAAAg");
	this.shape_146.setTransform(-33.9,-170.5);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#000000").s().p("AgIAvIgHgBIgGgCIgCgCIAAgCIAAgEQAAgBAAAAQAAAAAAgBQABAAAAAAQAAAAAAAAIACgBIAEACIAGACIAKABQAJAAAFgFQAFgFAAgKIAAgNIgBAAQgDAFgGADQgFACgFAAQgJAAgGgEQgGgEgDgHQgEgGAAgJQAAgGACgGQACgGADgEQAEgFAFgCQAFgDAHAAQAGAAAFADQAFACAEAGIAAAAIAAgGIABgCIACgBIAFAAIACABIABACIAAA8QAAAPgIAHQgIAHgPAAIgHAAgAgJgiQgEAEgCAFQgCAEAAAGQAAAFACAFQACAFAEACQAEAEAFgBQAJAAAFgFQAFgFAAgKQAAgGgDgFQgCgGgEgCQgFgDgFgBQgFABgEADg");
	this.shape_147.setTransform(-48.7,-169);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#000000").s().p("AgOAfIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFQAEgGADgCQADgCAGAAIADAAIACAAIACABIABACIAAAFIAAACIgCAAIgDAAIgDAAQgHAAgDADQgDAEgCAGQgBAFAAAFIAAAZIAAACIgDABg");
	this.shape_148.setTransform(-57.5,-170.6);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#000000").s().p("AgPAdQgFgCgCgEQgCgEgCgFIAAgJIAAggIAAgDIACAAIAGAAIACAAIAAADIAAAeQABAFABAEQABAFADACQADADAGAAQAFAAAEgEQAEgDADgGQACgFAAgGIAAgZIABgDIABAAIAGAAIACAAIAAADIAAA1IAAADIgCABIgFAAIgCgBIgBgDIAAgGIgBAAQgEAGgEADQgGACgGAAQgGAAgFgCg");
	this.shape_149.setTransform(-63.9,-170.5);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#000000").s().p("AgNAvQgBAAAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAIABgBIAAgBIALgaIgXg7IAAgBIAAgBQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAAAAAIAIAAIABABIACACIAPAuIABAAIAQguIABgCIACgBIAGAAQABAAAAAAQABAAAAABQAAAAAAAAQAAAAAAABIAAABIAAABIgfBWIgCACIgCABg");
	this.shape_150.setTransform(-78.2,-168.9);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgDIAAgDIABgCIACgBIADABIAEACIAGAAIAFAAQAAgBABAAQAAAAABAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgGgEQgIgDgDgDQgFgEAAgHQAAgGAEgDQACgFAFgCQAEgBAGAAIAFAAIAHACIACACIAAADIgBADIgBACIgBAAIgCgBIgEgBIgGgBQgDAAgCACQgDACAAADQAAADADADIAJAFQAFACAEADQADABABAEQACADAAAFQAAAGgEAEQgEAFgFABQgFACgEAAIgHgBg");
	this.shape_151.setTransform(-87.4,-170.5);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#000000").s().p("AgNAcQgGgEgFgIQgDgGAAgKQAAgJADgHQAEgHAGgEQAHgEAIAAQANAAAHAIQAHAIABAOIgBADIgEABIgnAAQAAAFACAFQADAFAFACQAFACAEAAIAJAAIAGgCIADgCIABABIAAABIABAFIgBADIgCABIgIACIgJABQgJAAgIgEgAARgFQgBgIgEgEQgDgEgIgBQgEABgEACQgEACgCAEQgCADAAAFIAgAAIAAAAg");
	this.shape_152.setTransform(-93.4,-170.5);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#000000").s().p("AAlAfIgDgBIAAgCIAAgfIgBgJQgBgEgCgDQgDgCgFAAQgFAAgDADIgGAGIgCAIIgBAHIAAAZIAAACIgCABIgFAAIgBgBIgBgCIAAgfIgBgJQgBgEgDgDQgCgCgGAAQgGAAgDADQgEADgBAFQgCAGAAAFIAAAbIAAACIgDABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFIAEgFIAGgEQADgBAGAAQAIAAAEADQAEADACAGIAEgGQADgDAEgCQADgBAGAAQAHAAAEACQAFACABAEQADAEAAAFIABAJIAAAgIgBACIgCABg");
	this.shape_153.setTransform(-102.2,-170.6);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#000000").s().p("AgPAcQgHgDgEgIQgFgHAAgKQAAgKAFgGQAEgHAHgFQAIgDAHAAQAIAAAIADQAHAFAEAHQAFAGAAAKQAAAKgFAHQgEAIgHADQgIAEgIAAQgHAAgIgEgAgKgTQgEAEgDAEQgCAGAAAFQAAAGACAFQADAFAEAEQAFACAFAAQAHAAAEgCQAEgEACgFQADgFAAgGQAAgFgDgGQgCgEgEgEQgEgDgHAAQgFAAgFADg");
	this.shape_154.setTransform(-111.4,-170.5);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#000000").s().p("AgHAcQgIgFgEgHQgDgHAAgJQAAgIADgHQAFgHAHgFQAHgEAIAAIAHAAIAHACIABACIAAADIgBADIAAABIgBABIgEgCIgHgBQgHABgEADQgFADgCAFQgCAFgBAFQABAGACAFQACAFAFAEQAEACAIAAIAEAAIAEgBIADgBIAAABIABABIAAAEIgBADIgBABIgHABIgGABQgIAAgHgEg");
	this.shape_155.setTransform(-117.9,-170.5);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#000000").s().p("AgNAcQgHgEgDgIQgEgGgBgKQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAIAAAOIgBADIgEABIgnAAQAAAFACAFQADAFAFACQAFACAEAAIAJAAIAGgCIADgCIABABIAAABIABAFIgBADIgBABIgJACIgJABQgJAAgIgEgAARgFQgBgIgDgEQgEgEgIgBQgEABgEACQgDACgDAEQgCADAAAFIAgAAIAAAAg");
	this.shape_156.setTransform(-124.2,-170.5);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#000000").s().p("AgCAuIgCgBIgBgDIAAg2IABgCIACgBIAFAAIACABIAAACIAAA2IAAADIgCABgAgEghQgCgBAAgDQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_157.setTransform(-144.5,-172);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#000000").s().p("AgIAvIgHgBIgGgCIgCgCIAAgCIAAgEQAAgBAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAIACgBIAEACIAGACIAKABQAJAAAFgFQAFgFAAgKIAAgNIgBAAQgDAFgGADQgFACgFAAQgJAAgGgEQgGgEgDgHQgEgGAAgJQAAgGACgGQACgGADgEQAEgFAFgCQAFgDAHAAQAGAAAFADQAFACAEAGIAAAAIAAgGIABgCIACgBIAFAAIACABIABACIAAA8QAAAPgIAHQgIAHgPAAIgHAAgAgJgiQgEAEgCAFQgCAEAAAGQAAAFACAFQACAFAEACQAEAEAFgBQAJAAAFgFQAFgFAAgKQAAgGgDgFQgCgGgEgCQgFgDgFgBQgFABgEADg");
	this.shape_158.setTransform(-149.9,-169);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#000000").s().p("AgCAuIgCgBIgBgDIAAg2IABgCIACgBIAFAAIACABIAAACIAAA2IAAADIgCABgAgEghQgCgBAAgDQAAgEACgCQACgBACAAQADAAACABQACACAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_159.setTransform(-155,-172);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#000000").s().p("AgJAfIgHgCIgCgBIAAgDIABgDIAAgCIACgBIACABIAFACIAGAAIAFAAQAAgBABAAQAAAAABAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAgBAAgBIgBgEIgEgDIgHgEQgGgDgEgDQgEgEgBgHQABgGADgDQACgFAFgCQAEgBAGAAIAFAAIAHACIACACIAAADIgBADIgBACIgBAAIgCgBIgEgBIgGgBQgDAAgDACQgCACAAADQgBADAEADQADADAGACQAFACADADQADABACAEQABADABAFQgBAGgDAEQgDAFgGABQgEACgFAAIgHgBg");
	this.shape_160.setTransform(-174.5,-170.5);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#000000").s().p("AgQAcQgGgGgDgHQgEgHAAgIQAAgGACgGQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFACADAEIABAAIAAgDIABgDIACgBIAFAAIACABIABADIAAA1IgBADIgCABIgFAAIgCgBIgBgDIAAgFIAAAAQgEAFgFADQgFACgGAAQgJAAgGgEgAgJgTQgEAEgCAFQgCAFAAAFQAAAFACAFQACAGAEADQAEADAFAAQAGAAAEgCQAEgEACgEQADgGAAgGQAAgGgDgFQgCgFgEgDQgFgDgFAAQgFAAgEADg");
	this.shape_161.setTransform(-181,-170.5);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#000000").s().p("AgNAcQgHgEgDgIQgEgGgBgKQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAIAAAOIgBADIgEABIgnAAQAAAFACAFQADAFAFACQAFACAEAAIAJAAIAGgCIADgCIABABIAAABIABAFIgBADIgBABIgJACIgJABQgJAAgIgEgAARgFQgBgIgDgEQgEgEgIgBQgEABgEACQgDACgDAEQgCADAAAFIAgAAIAAAAg");
	this.shape_162.setTransform(-194.8,-170.5);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#000000").s().p("AgFAGQgCgCAAgEQAAgDACgCQADgCACAAQAEAAABACQADACAAADQAAAEgDACQgBACgEAAQgCAAgDgCg");
	this.shape_163.setTransform(-217.9,-168.1);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#000000").s().p("AgPAdQgEgCgDgEQgCgEgCgFIgBgJIAAggIABgDIADAAIAEAAIADAAIABADIAAAeQAAAFABAEQABAFADACQADADAFAAQAGAAAEgEQAEgDACgGQACgFAAgGIAAgZIABgDIADAAIAFAAIACAAIAAADIAAA1IAAADIgCABIgFAAIgCgBIgBgDIAAgGIgBAAQgEAGgFADQgFACgFAAQgIAAgEgCg");
	this.shape_164.setTransform(-241.7,-170.5);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#000000").s().p("AgOAcQgIgDgEgIQgFgHAAgKQAAgKAFgGQAEgHAIgFQAGgDAIAAQAIAAAIADQAHAFAEAHQAFAGAAAKQAAAKgFAHQgEAIgHADQgIAEgIAAQgIAAgGgEgAgKgTQgEAEgDAEQgCAGAAAFQAAAGACAFQADAFAEAEQAEACAGAAQAGAAAFgCQAEgEACgFQADgFAAgGQAAgFgDgGQgCgEgEgEQgFgDgGAAQgGAAgEADg");
	this.shape_165.setTransform(-252.6,-170.5);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("AgHAcQgIgFgEgHQgDgHgBgJQABgIADgHQAFgHAHgFQAGgEAKAAIAGAAIAGACIACACIAAADIgBADIAAABIgBABIgEgCIgHgBQgHABgEADQgEADgDAFQgDAFAAAFQAAAGADAFQACAFAFAEQAEACAIAAIAEAAIAEgBIACgBIABABIABABIAAAEIgBADIgBABIgHABIgFABQgKAAgGgEg");
	this.shape_166.setTransform(-259.1,-170.5);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#000000").s().p("AATAuIgCgBIgBgCIAAggQABgIgDgDQgEgGgIAAQgFAAgEAEQgEACgCAFQgDAFAAAHIAAAaIAAACIgCABIgGAAIgCgBIgBgCIAAhVIABgCIACgBIAGAAIACABIAAACIAAAlIABAAQADgFAGgDQAFgCAGAAQAHAAAEACQAFADADADQACAEABAEIAAAJIAAAhIAAACIgCABg");
	this.shape_167.setTransform(33.9,-188.6);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#000000").s().p("AgMAcQgIgEgDgHQgEgIgBgJQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAHgBAQIgBACIgDAAIgoAAQABAGADAFQADAEAEADQAEADAGgBIAJgBIAFgBIADgCIABABIABABIAAAFIAAADIgCABIgJACIgJABQgKAAgGgEgAARgFQAAgHgEgFQgFgEgHgBQgEABgEACQgDACgCADQgDAEAAAFIAgAAIAAAAg");
	this.shape_168.setTransform(13.8,-187);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#000000").s().p("AgCAtIgCgBQAAAAAAAAQAAAAgBAAQAAgBAAAAQAAgBAAAAIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAACgCACQgCACgDABQgCgBgCgCg");
	this.shape_169.setTransform(-13,-188.5);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#000000").s().p("AgIAvIgHgCIgGgBIgCgCIAAgCIAAgEQAAgBAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAIACgBIAEACIAGACIAKABQAJAAAFgFQAFgFAAgKIAAgNIgBAAQgDAFgGADQgFACgFAAQgJAAgGgFQgGgEgDgGQgEgHAAgJQAAgFACgGQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFADAEAFIAAAAIAAgGIABgCIACgBIAFAAIACABIABACIAAA8QAAAPgIAHQgIAHgPAAIgHAAgAgJgiQgEAEgCAEQgCAFAAAGQAAAFACAFQACAFAEACQAEAEAFAAQAJgBAFgFQAFgFAAgKQAAgHgDgEQgCgFgEgEQgFgCgFAAQgFAAgEADg");
	this.shape_170.setTransform(-18.4,-185.4);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#000000").s().p("AgNAcQgHgEgEgHQgDgIAAgJQAAgJADgHQAEgHAGgEQAHgEAIAAQANAAAHAIQAHAHAAAQIAAACIgEAAIgoAAQABAGACAFQAEAEAEADQAFADAEgBIAJgBIAGgBIADgCIABABIAAABIABAFIgBADIgCABIgIACIgJABQgJAAgIgEgAARgFQAAgHgFgFQgDgEgIgBQgEABgEACQgEACgCADQgCAEAAAFIAgAAIAAAAg");
	this.shape_171.setTransform(-39.3,-187);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#000000").s().p("AgPAcQgHgEgEgGQgFgIAAgKQAAgKAFgGQAEgIAHgDQAIgEAHAAQAIAAAIAEQAHADAEAIQAFAGAAAKQAAAKgFAIQgEAGgHAEQgIAEgIAAQgHAAgIgEgAgKgSQgEADgDAEQgCAGAAAFQAAAGACAFQADAFAEAEQAFACAFAAQAHAAAEgCQAEgEACgFQADgFAAgGQAAgFgDgGQgCgEgEgDQgEgEgHAAQgFAAgFAEg");
	this.shape_172.setTransform(-53.8,-187);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#000000").s().p("AgPAdQgFgCgCgEQgCgEgCgFIgBgJIAAggIABgDIACAAIAGAAIACAAIAAADIAAAeQABAFABAEQABAFADACQADADAGAAQAFAAAEgEQAFgDACgGQACgFAAgGIAAgZIAAgDIACAAIAGAAIACAAIAAADIAAA1IAAADIgCABIgFAAIgCgBQAAAAAAgBQgBAAAAAAQAAAAAAgBQAAAAAAgBIAAgGIgBAAQgEAGgEADQgGACgFAAQgIAAgEgCg");
	this.shape_173.setTransform(-69.2,-186.9);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#000000").s().p("AgJAtQgFgDgEgFIAAAFIgBADIgCABIgFAAIgCgBIgBgDIAAhVIABgCIACgBIAFAAIADABIAAACIAAAlIABAAQAEgFAFgCQAFgDAGAAQAJAAAGAFQAGAEADAHQADAHAAAJQAAAIgDAHQgDAHgGAFQgGAEgJAAQgGAAgGgCgAgJgDQgEACgCAEQgDAFAAAHQABALAFAGQAFAGAHAAQAGAAAEgDQAEgDACgFQACgGAAgGIgCgKQgCgFgDgDQgEgDgHAAQgEAAgFADg");
	this.shape_174.setTransform(-76.5,-188.5);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#000000").s().p("AgFArQgEgCgBgGQgBgFAAgHIAAhBIABgDIACgBIAFAAIACABIABADIAABCQAAAGABADQACADAEABIACAAIABAAIACAAIAAACIAAAEIAAADIgBAAIgDABIgDAAQgGAAgEgEg");
	this.shape_175.setTransform(-88.6,-188.5);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#000000").s().p("AgQAcQgGgGgDgHQgEgHAAgIQAAgFACgHQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFACADADIABAAIAAgCIABgDIACgBIAFAAIACABIABADIAAA1IgBACIgCABIgFAAIgCgBIgBgCIAAgGIAAAAQgEAGgFACQgFADgGAAQgJAAgGgEgAgJgSQgEADgCAFQgCAFAAAFQAAAFACAFQACAGAEADQAEAEAFgBQAGAAAEgCQAEgEACgFQADgEAAgHQAAgGgDgFQgCgFgEgDQgFgDgFAAQgFAAgEAEg");
	this.shape_176.setTransform(-94.7,-187);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#000000").s().p("AgMAcQgIgEgDgHQgEgIgBgJQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAHgBAQIgBACIgDAAIgoAAQABAGADAFQADAEAEADQAEADAGgBIAJgBIAFgBIADgCIABABIABABIAAAFIAAADIgCABIgJACIgJABQgKAAgGgEgAARgFQAAgHgEgFQgFgEgHgBQgEABgEACQgDACgCADQgDAEAAAFIAgAAIAAAAg");
	this.shape_177.setTransform(-105,-187);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#000000").s().p("AgDAkQgEgGAAgLIAAgeIgJAAIgDgBIgBgDIAAgCIABgDIADAAIAJAAIAAgRIABgCIACgBIAEAAIADABIAAACIAAARIANAAIADAAIABADIAAACIgBADIgDABIgNAAIAAAdQAAAHACADQADAEAFAAIADgBIADAAIABAAIABACIAAAFIgBACIgCAAIgCABIgDAAQgMAAgEgFg");
	this.shape_178.setTransform(-110.8,-187.9);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#000000").s().p("AgQAcQgGgGgDgHQgEgHAAgIQAAgFACgHQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFACADADIABAAIAAgCIABgDIACgBIAFAAIACABIABADIAAA1IgBACIgCABIgFAAIgCgBIgBgCIAAgGIAAAAQgEAGgFACQgFADgGAAQgJAAgGgEgAgJgSQgEADgCAFQgCAFAAAFQAAAFACAFQACAGAEADQAEAEAFgBQAGAAAEgCQAEgEACgFQADgEAAgHQAAgGgDgFQgCgFgEgDQgFgDgFAAQgFAAgEAEg");
	this.shape_179.setTransform(-116.9,-187);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#000000").s().p("AAlAfIgCgBIgBgCIAAgfIgBgJQgBgEgDgDQgCgCgFAAQgFAAgDADIgGAGIgBAIIgBAHIAAAZIgBACIgCABIgEAAIgCgBQgBAAAAAAQAAAAAAgBQAAAAAAAAQgBgBAAAAIAAgfIgBgJQAAgEgDgDQgDgCgFAAQgFAAgEADQgEADgBAFQgCAGAAAFIAAAbIgBACIgCABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIABADIAAAFIAEgFIAGgEQADgBAFAAQAJAAAFADQADADACAGIAEgGQADgDAEgCQADgBAGAAQAHAAAEACQAFACACAEQACAEAAAFIABAJIAAAgIgBACIgCABg");
	this.shape_180.setTransform(-136.3,-187.1);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAACgCACQgCACgDABQgCgBgCgCg");
	this.shape_181.setTransform(-143.3,-188.5);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#000000").s().p("AgFArQgEgCgBgGQgBgFAAgHIAAhBIABgDIACgBIAFAAIACABIABADIAABCQAAAGABADQACADAEABIACAAIABAAIACAAIAAACIAAAEIAAADIgBAAIgDABIgDAAQgGAAgEgEg");
	this.shape_182.setTransform(-146.1,-188.5);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#000000").s().p("AgNAcQgHgEgDgHQgEgIgBgJQABgJAEgHQADgHAHgEQAGgEAIAAQANAAAHAIQAIAHAAAQIgBACIgEAAIgnAAQAAAGACAFQADAEAFADQAFADAEgBIAJgBIAGgBIADgCIABABIAAABIABAFIgBADIgBABIgJACIgJABQgJAAgIgEgAARgFQgBgHgDgFQgEgEgIgBQgEABgEACQgDACgDADQgCAEAAAFIAgAAIAAAAg");
	this.shape_183.setTransform(-151.6,-187);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#000000").s().p("AgPAcQgHgEgEgGQgEgIgBgKQABgKAEgGQAEgIAHgDQAIgEAHAAQAIAAAIAEQAHADAFAIQAEAGAAAKQAAAKgEAIQgFAGgHAEQgIAEgIAAQgHAAgIgEgAgKgSQgEADgCAEQgDAGAAAFQAAAGADAFQACAFAEAEQAEACAGAAQAHAAAEgCQAFgEACgFQACgFAAgGQAAgFgCgGQgCgEgFgDQgEgEgHAAQgGAAgEAEg");
	this.shape_184.setTransform(-162.2,-187);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#000000").s().p("AgDAkQgEgGAAgLIAAgeIgJAAIgDgBIgBgDIAAgCIABgDIADAAIAJAAIAAgRIABgCIACgBIAFAAIACABIAAACIAAARIANAAIADAAIABADIAAACIgBADIgDABIgNAAIAAAdQAAAHACADQADAEAFAAIADgBIADAAIABAAIABACIAAAFIgBACIgBAAIgDABIgDAAQgMAAgEgFg");
	this.shape_185.setTransform(-168.3,-187.9);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#000000").s().p("AgIAvIgHgCIgGgBIgCgCIAAgCIAAgEQAAgBAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAIACgBIAEACIAGACIAKABQAJAAAFgFQAFgFAAgKIAAgNIgBAAQgDAFgGADQgFACgFAAQgJAAgGgFQgGgEgDgGQgEgHAAgJQAAgFACgGQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFADAEAFIAAAAIAAgGIABgCIACgBIAFAAIACABIABACIAAA8QAAAPgIAHQgIAHgPAAIgHAAgAgJgiQgEAEgCAEQgCAFAAAGQAAAFACAFQACAFAEACQAEAEAFAAQAJgBAFgFQAFgFAAgKQAAgHgDgEQgCgFgEgEQgFgCgFAAQgFAAgEADg");
	this.shape_186.setTransform(-177.8,-185.4);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#000000").s().p("AATAfIgBgBIgBgCIAAgfQAAgIgEgFQgCgFgJAAQgEAAgFADQgEAEgCAFQgCAFgBAGIAAAaIAAACIgCABIgGAAIgBgBIgBgCIAAg1IABgDIABgBIAFAAIADABIAAADIAAAFIABAAQADgFAGgDQAFgCAGAAQAHAAAFACQAEACACAEQADAEABAFIABAJIAAAgIgBACIgCABg");
	this.shape_187.setTransform(-185.1,-187.1);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAACgCACQgCACgDABQgCgBgCgCg");
	this.shape_188.setTransform(-190.3,-188.5);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#000000").s().p("AAlAfIgDgBIAAgCIAAgfIgBgJQgBgEgCgDQgDgCgFAAQgFAAgDADIgGAGIgCAIIAAAHIAAAZIgBACIgCABIgFAAIgBgBIgBgCIAAgfIgBgJQgBgEgDgDQgDgCgFAAQgFAAgEADQgDADgCAFQgCAGAAAFIAAAbIgBACIgCABIgFAAIgCgBIgBgCIAAg1IABgDIACgBIAEAAIADABIABADIAAAFIAEgFIAGgEQADgBAGAAQAIAAAEADQAEADACAGIAEgGQADgDAEgCQAEgBAFAAQAHAAAEACQAFACACAEQACAEAAAFIABAJIAAAgIgBACIgCABg");
	this.shape_189.setTransform(-197.3,-187.1);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#000000").s().p("AgCAtIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIAAADIAAA1IAAACIgCABgAgEghQgCgCAAgCQAAgDACgDQACgCACAAQADAAACACQACADAAADQAAACgCACQgCACgDABQgCgBgCgCg");
	this.shape_190.setTransform(-204.3,-188.5);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#000000").s().p("AgQAcQgGgGgDgHQgEgHAAgIQAAgFACgHQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFACADADIABAAIAAgCIABgDIACgBIAFAAIACABIABADIAAA1IgBACIgCABIgFAAIgCgBIgBgCIAAgGIAAAAQgEAGgFACQgFADgGAAQgJAAgGgEgAgJgSQgEADgCAFQgCAFAAAFQAAAFACAFQACAGAEADQAEAEAFgBQAGAAAEgCQAEgEACgFQADgEAAgHQAAgGgDgFQgCgFgEgDQgFgDgFAAQgFAAgEAEg");
	this.shape_191.setTransform(-209.7,-187);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#000000").s().p("AgOAfIgCgBIgBgCIAAg1IABgDIACgBIAFAAIACABIABADIAAAFQADgGAEgCQADgCAGAAIADAAIACAAIACABIABACIAAAFIAAACIgCAAIgDAAIgDAAQgHAAgDADQgDAEgCAGQgBAFAAAFIAAAZIAAACIgDABg");
	this.shape_192.setTransform(-225.2,-187.1);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#000000").s().p("AgQAcQgGgGgDgHQgEgHAAgIQAAgFACgHQACgFADgFQAEgEAFgDQAFgCAHAAQAGAAAFACQAFACADADIABAAIAAgCIABgDIACgBIAFAAIACABIABADIAAA1IgBACIgCABIgFAAIgCgBIgBgCIAAgGIAAAAQgEAGgFACQgFADgGAAQgJAAgGgEgAgJgSQgEADgCAFQgCAFAAAFQAAAFACAFQACAGAEADQAEAEAFgBQAGAAAEgCQAEgEACgFQADgEAAgHQAAgGgDgFQgCgFgEgDQgFgDgFAAQgFAAgEAEg");
	this.shape_193.setTransform(-232,-187);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#000000").s().p("AgPAdQgEgCgDgEQgCgEgCgFIgBgJIAAggIABgDIADAAIAEAAIADAAIABADIAAAeQAAAFABAEQABAFADACQADADAFAAQAGAAAEgEQAEgDACgGQACgFAAgGIAAgZIABgDIADAAIAFAAIACAAIAAADIAAA1IAAADIgCABIgFAAIgCgBIgBgDIAAgGIgBAAQgEAGgFADQgFACgFAAQgIAAgEgCg");
	this.shape_194.setTransform(-242.6,-186.9);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#000000").s().p("AgOAcQgIgEgEgGQgEgIgBgKQABgKAEgGQAEgIAIgDQAGgEAIAAQAIAAAIAEQAHADAFAIQAEAGAAAKQAAAKgEAIQgFAGgHAEQgIAEgIAAQgIAAgGgEgAgKgSQgEADgCAEQgDAGAAAFQAAAGADAFQACAFAEAEQAFACAFAAQAHAAAEgCQAEgEADgFQACgFAAgGQAAgFgCgGQgDgEgEgDQgEgEgHAAQgFAAgFAEg");
	this.shape_195.setTransform(-250.1,-187);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#000000").s().p("AgCArIgCgBIgBgCIAAgiIgfgsIgBgBIAAgBIAAgCIABAAIAIAAIADAAIABACIAYAkIAYgkIACgCIADAAIAIAAIABAAIAAACIAAABIgBABIgfAsIAAAiQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAAAAAIgCABg");
	this.shape_196.setTransform(-257.9,-188.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.instance_3},{t:this.shape_117,p:{x:-258.4,y:-188.3}},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112,p:{x:-218.6,y:-187.1}},{t:this.shape_111},{t:this.shape_110,p:{x:-202,y:-186.9}},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107,p:{x:-184.3,y:-187.1}},{t:this.shape_106,p:{x:-177.5}},{t:this.shape_105},{t:this.shape_104,p:{x:-165.2}},{t:this.shape_103},{t:this.shape_102,p:{x:-153.9}},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99,p:{x:-137.1}},{t:this.shape_98,p:{x:-131.9}},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94,p:{x:-98.3}},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90,p:{x:-66.5,y:-187.9}},{t:this.shape_89,p:{x:-60.8}},{t:this.shape_88,p:{x:-54.6,y:-187.1}},{t:this.shape_87},{t:this.shape_86,p:{x:-39.5}},{t:this.shape_85,p:{x:-32.1,y:-186.9}},{t:this.shape_84,p:{x:-22.9,y:-187.1}},{t:this.shape_83,p:{x:-13.5,y:-188.5}},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73,p:{x:57.7}},{t:this.shape_72,p:{x:62.5}},{t:this.shape_71,p:{x:67.5,y:-186.9}},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68,p:{y:-171.5}},{t:this.shape_67},{t:this.shape_66,p:{x:-242.9}},{t:this.shape_65},{t:this.shape_64,p:{x:-230.2}},{t:this.shape_63,p:{x:-225,y:-169.1}},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58,p:{x:-179.8}},{t:this.shape_57,p:{x:-173.3,y:-170.6}},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51,p:{x:-128.6}},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47,p:{x:-99.2}},{t:this.shape_46,p:{x:-94.2}},{t:this.shape_45,p:{x:-88.7}},{t:this.shape_44,p:{x:-85}},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:-63.2,y:-171.5}},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38,p:{x:-39.5,y:-170.6}},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35,p:{x:-13.6,y:-172.1}},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30,p:{x:17.9}},{t:this.shape_29,p:{x:20.7}},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26,p:{x:39.8,y:-171.5}},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19,p:{x:-231,y:-154.1}},{t:this.shape_18},{t:this.shape_17,p:{x:-217.7,y:-155}},{t:this.shape_16,p:{x:-212}},{t:this.shape_15},{t:this.shape_14,p:{x:-190.7,y:-155.6}},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10,p:{x:-171.1,y:-155}},{t:this.shape_9},{t:this.shape_8,p:{x:-154.1}},{t:this.shape_7,p:{x:-144.8}},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3,p:{x:-114.6}},{t:this.shape_2},{t:this.shape_1,p:{x:-106.3,y:-155.6}},{t:this.shape},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.instance_3},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_89,p:{x:-220.1}},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_106,p:{x:-129.3}},{t:this.shape_86,p:{x:-124.1}},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_72,p:{x:-85.1}},{t:this.shape_174},{t:this.shape_173},{t:this.shape_104,p:{x:-63.4}},{t:this.shape_172},{t:this.shape_98,p:{x:-46.4}},{t:this.shape_171},{t:this.shape_14,p:{x:-28.9,y:-188.5}},{t:this.shape_102,p:{x:-23.5}},{t:this.shape_170},{t:this.shape_169},{t:this.shape_26,p:{x:-9.3,y:-187.9}},{t:this.shape_99,p:{x:-2}},{t:this.shape_38,p:{x:3.2,y:-187.1}},{t:this.shape_168},{t:this.shape_94,p:{x:20.7}},{t:this.shape_73,p:{x:27.5}},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_64,p:{x:-246.7}},{t:this.shape_164},{t:this.shape_112,p:{x:-232.6,y:-170.6}},{t:this.shape_19,p:{x:-223.4,y:-170.6}},{t:this.shape_163},{t:this.shape_117,p:{x:-209.3,y:-171.8}},{t:this.shape_66,p:{x:-201.9}},{t:this.shape_162},{t:this.shape_30,p:{x:-185.8}},{t:this.shape_161},{t:this.shape_160},{t:this.shape_10,p:{x:-169.7,y:-171.5}},{t:this.shape_1,p:{x:-160.4,y:-172.1}},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_17,p:{x:-140.8,y:-171.5}},{t:this.shape_83,p:{x:-131.1,y:-172.1}},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_58,p:{x:-71.4}},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_85,p:{x:-41.1,y:-170.5}},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_88,p:{x:-2,y:-170.6}},{t:this.shape_141},{t:this.shape_140},{t:this.shape_51,p:{x:18.7}},{t:this.shape_44,p:{x:24.8}},{t:this.shape_139},{t:this.shape_47,p:{x:39.5}},{t:this.shape_46,p:{x:44.5}},{t:this.shape_45,p:{x:50}},{t:this.shape_90,p:{x:53.7,y:-171.5}},{t:this.shape_29,p:{x:60.9}},{t:this.shape_138},{t:this.shape_68,p:{y:-155}},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_84,p:{x:-221.3,y:-154.1}},{t:this.shape_63,p:{x:-211.9,y:-152.6}},{t:this.shape_110,p:{x:-204.7,y:-154}},{t:this.shape_7,p:{x:-198.8}},{t:this.shape_16,p:{x:-193.1}},{t:this.shape_107,p:{x:-187,y:-154.1}},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_41,p:{x:-148.7,y:-155}},{t:this.shape_128},{t:this.shape_57,p:{x:-136.9,y:-154.1}},{t:this.shape_127},{t:this.shape_8,p:{x:-121.7}},{t:this.shape_71,p:{x:-114.3,y:-154}},{t:this.shape_126},{t:this.shape_35,p:{x:-95.8,y:-155.6}},{t:this.shape_125},{t:this.shape_3,p:{x:-82.7}},{t:this.shape_124},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},148).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.instance_3},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_89,p:{x:-220.1}},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_106,p:{x:-129.3}},{t:this.shape_86,p:{x:-124.1}},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_72,p:{x:-85.1}},{t:this.shape_174},{t:this.shape_173},{t:this.shape_104,p:{x:-63.4}},{t:this.shape_172},{t:this.shape_98,p:{x:-46.4}},{t:this.shape_171},{t:this.shape_14,p:{x:-28.9,y:-188.5}},{t:this.shape_102,p:{x:-23.5}},{t:this.shape_170},{t:this.shape_169},{t:this.shape_26,p:{x:-9.3,y:-187.9}},{t:this.shape_99,p:{x:-2}},{t:this.shape_38,p:{x:3.2,y:-187.1}},{t:this.shape_168},{t:this.shape_94,p:{x:20.7}},{t:this.shape_73,p:{x:27.5}},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_64,p:{x:-246.7}},{t:this.shape_164},{t:this.shape_112,p:{x:-232.6,y:-170.6}},{t:this.shape_19,p:{x:-223.4,y:-170.6}},{t:this.shape_163},{t:this.shape_117,p:{x:-209.3,y:-171.8}},{t:this.shape_66,p:{x:-201.9}},{t:this.shape_162},{t:this.shape_30,p:{x:-185.8}},{t:this.shape_161},{t:this.shape_160},{t:this.shape_10,p:{x:-169.7,y:-171.5}},{t:this.shape_1,p:{x:-160.4,y:-172.1}},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_17,p:{x:-140.8,y:-171.5}},{t:this.shape_83,p:{x:-131.1,y:-172.1}},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_58,p:{x:-71.4}},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_85,p:{x:-41.1,y:-170.5}},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_88,p:{x:-2,y:-170.6}},{t:this.shape_141},{t:this.shape_140},{t:this.shape_51,p:{x:18.7}},{t:this.shape_44,p:{x:24.8}},{t:this.shape_139},{t:this.shape_47,p:{x:39.5}},{t:this.shape_46,p:{x:44.5}},{t:this.shape_45,p:{x:50}},{t:this.shape_90,p:{x:53.7,y:-171.5}},{t:this.shape_29,p:{x:60.9}},{t:this.shape_138},{t:this.shape_68,p:{y:-155}},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_84,p:{x:-221.3,y:-154.1}},{t:this.shape_63,p:{x:-211.9,y:-152.6}},{t:this.shape_110,p:{x:-204.7,y:-154}},{t:this.shape_7,p:{x:-198.8}},{t:this.shape_16,p:{x:-193.1}},{t:this.shape_107,p:{x:-187,y:-154.1}},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_41,p:{x:-148.7,y:-155}},{t:this.shape_128},{t:this.shape_57,p:{x:-136.9,y:-154.1}},{t:this.shape_127},{t:this.shape_8,p:{x:-121.7}},{t:this.shape_71,p:{x:-114.3,y:-154}},{t:this.shape_126},{t:this.shape_35,p:{x:-95.8,y:-155.6}},{t:this.shape_125},{t:this.shape_3,p:{x:-82.7}},{t:this.shape_124},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},178).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.instance_3},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_89,p:{x:-220.1}},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_106,p:{x:-129.3}},{t:this.shape_86,p:{x:-124.1}},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_72,p:{x:-85.1}},{t:this.shape_174},{t:this.shape_173},{t:this.shape_104,p:{x:-63.4}},{t:this.shape_172},{t:this.shape_98,p:{x:-46.4}},{t:this.shape_171},{t:this.shape_14,p:{x:-28.9,y:-188.5}},{t:this.shape_102,p:{x:-23.5}},{t:this.shape_170},{t:this.shape_169},{t:this.shape_26,p:{x:-9.3,y:-187.9}},{t:this.shape_99,p:{x:-2}},{t:this.shape_38,p:{x:3.2,y:-187.1}},{t:this.shape_168},{t:this.shape_94,p:{x:20.7}},{t:this.shape_73,p:{x:27.5}},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_64,p:{x:-246.7}},{t:this.shape_164},{t:this.shape_112,p:{x:-232.6,y:-170.6}},{t:this.shape_19,p:{x:-223.4,y:-170.6}},{t:this.shape_163},{t:this.shape_117,p:{x:-209.3,y:-171.8}},{t:this.shape_66,p:{x:-201.9}},{t:this.shape_162},{t:this.shape_30,p:{x:-185.8}},{t:this.shape_161},{t:this.shape_160},{t:this.shape_10,p:{x:-169.7,y:-171.5}},{t:this.shape_1,p:{x:-160.4,y:-172.1}},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_17,p:{x:-140.8,y:-171.5}},{t:this.shape_83,p:{x:-131.1,y:-172.1}},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_58,p:{x:-71.4}},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_85,p:{x:-41.1,y:-170.5}},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_88,p:{x:-2,y:-170.6}},{t:this.shape_141},{t:this.shape_140},{t:this.shape_51,p:{x:18.7}},{t:this.shape_44,p:{x:24.8}},{t:this.shape_139},{t:this.shape_47,p:{x:39.5}},{t:this.shape_46,p:{x:44.5}},{t:this.shape_45,p:{x:50}},{t:this.shape_90,p:{x:53.7,y:-171.5}},{t:this.shape_29,p:{x:60.9}},{t:this.shape_138},{t:this.shape_68,p:{y:-155}},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_84,p:{x:-221.3,y:-154.1}},{t:this.shape_63,p:{x:-211.9,y:-152.6}},{t:this.shape_110,p:{x:-204.7,y:-154}},{t:this.shape_7,p:{x:-198.8}},{t:this.shape_16,p:{x:-193.1}},{t:this.shape_107,p:{x:-187,y:-154.1}},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_41,p:{x:-148.7,y:-155}},{t:this.shape_128},{t:this.shape_57,p:{x:-136.9,y:-154.1}},{t:this.shape_127},{t:this.shape_8,p:{x:-121.7}},{t:this.shape_71,p:{x:-114.3,y:-154}},{t:this.shape_126},{t:this.shape_35,p:{x:-95.8,y:-155.6}},{t:this.shape_125},{t:this.shape_3,p:{x:-82.7}},{t:this.shape_124},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},237).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_6},{t:this.text_5},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.text},{t:this.instance_3},{t:this.shape_117,p:{x:-258.4,y:-188.3}},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112,p:{x:-218.6,y:-187.1}},{t:this.shape_111},{t:this.shape_110,p:{x:-202,y:-186.9}},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107,p:{x:-184.3,y:-187.1}},{t:this.shape_106,p:{x:-177.5}},{t:this.shape_105},{t:this.shape_104,p:{x:-165.2}},{t:this.shape_103},{t:this.shape_102,p:{x:-153.9}},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99,p:{x:-137.1}},{t:this.shape_98,p:{x:-131.9}},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94,p:{x:-98.3}},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90,p:{x:-66.5,y:-187.9}},{t:this.shape_89,p:{x:-60.8}},{t:this.shape_88,p:{x:-54.6,y:-187.1}},{t:this.shape_87},{t:this.shape_86,p:{x:-39.5}},{t:this.shape_85,p:{x:-32.1,y:-186.9}},{t:this.shape_84,p:{x:-22.9,y:-187.1}},{t:this.shape_83,p:{x:-13.5,y:-188.5}},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73,p:{x:57.7}},{t:this.shape_72,p:{x:62.5}},{t:this.shape_71,p:{x:67.5,y:-186.9}},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68,p:{y:-171.5}},{t:this.shape_67},{t:this.shape_66,p:{x:-242.9}},{t:this.shape_65},{t:this.shape_64,p:{x:-230.2}},{t:this.shape_63,p:{x:-225,y:-169.1}},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58,p:{x:-179.8}},{t:this.shape_57,p:{x:-173.3,y:-170.6}},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51,p:{x:-128.6}},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47,p:{x:-99.2}},{t:this.shape_46,p:{x:-94.2}},{t:this.shape_45,p:{x:-88.7}},{t:this.shape_44,p:{x:-85}},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41,p:{x:-63.2,y:-171.5}},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38,p:{x:-39.5,y:-170.6}},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35,p:{x:-13.6,y:-172.1}},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30,p:{x:17.9}},{t:this.shape_29,p:{x:20.7}},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26,p:{x:39.8,y:-171.5}},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19,p:{x:-231,y:-154.1}},{t:this.shape_18},{t:this.shape_17,p:{x:-217.7,y:-155}},{t:this.shape_16,p:{x:-212}},{t:this.shape_15},{t:this.shape_14,p:{x:-190.7,y:-155.6}},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10,p:{x:-171.1,y:-155}},{t:this.shape_9},{t:this.shape_8,p:{x:-154.1}},{t:this.shape_7,p:{x:-144.8}},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3,p:{x:-114.6}},{t:this.shape_2},{t:this.shape_1,p:{x:-106.3,y:-155.6}},{t:this.shape},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]},179).wait(111));

	// how to play button
	this.instance_6 = new lib.HM_harhowtoplay("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-260.1,196.5,0.75,0.75,0,0,0,2.4,-2.5);

	this.instance_7 = new lib.HM_harhowtoplayhighlight("synched",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(-260.1,196.5,0.75,0.75,0,0,0,2.4,-2.5);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6}]}).to({state:[{t:this.instance_7}]},778).to({state:[{t:this.instance_7}]},3).to({state:[{t:this.instance_7}]},6).to({state:[{t:this.instance_7}]},3).to({state:[{t:this.instance_7}]},6).to({state:[{t:this.instance_7}]},3).to({state:[{t:this.instance_7}]},6).to({state:[{t:this.instance_6}]},1).wait(47));
	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(778).to({_off:false},0).to({scaleX:0.86,scaleY:0.86,x:-260.2},3).to({scaleX:0.75,scaleY:0.75,x:-260.1},6).to({scaleX:0.86,scaleY:0.86,x:-260.2},3).to({scaleX:0.75,scaleY:0.75,x:-260.1},6).to({scaleX:0.86,scaleY:0.86,x:-260.2},3).to({scaleX:0.75,scaleY:0.75,x:-260.1},6).to({_off:true},1).wait(47));

	// blue tiles
	this.instance_8 = new lib.HM_mysteryNumberhilite();
	this.instance_8.parent = this;
	this.instance_8.setTransform(0.6,-24,1,1,0,0,0,58.9,13.7);
	this.instance_8._off = true;

	this.instance_9 = new lib.HM_digithilite5("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(-44.4,68.6,1,1.194,0,0,0,13.4,48.9);
	this.instance_9._off = true;

	this.instance_10 = new lib.HM_Headinghilite("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(-1.5,1.3,1,1,0,0,0,57.1,11);
	this.instance_10._off = true;

	this.instance_11 = new lib.HM_HAR_harnextcluesbuttonhilite("single",0);
	this.instance_11.parent = this;
	this.instance_11.setTransform(-1.5,-91.9,0.75,0.75);
	this.instance_11._off = true;

	this.mysteryDigitClip = new lib.HM_mcmysteryDigitCliphilitecopy();
	this.mysteryDigitClip.name = "mysteryDigitClip";
	this.mysteryDigitClip.parent = this;
	this.mysteryDigitClip.setTransform(-44.5,-24.8,0.75,0.75,0,0,0,25,15);

	this.mysteryDigitClip_1 = new lib.HM_mcmysteryDigitCliphilite();
	this.mysteryDigitClip_1.name = "mysteryDigitClip_1";
	this.mysteryDigitClip_1.parent = this;
	this.mysteryDigitClip_1.setTransform(-44.5,-24.8,0.75,0.75,0,0,0,25,15);
	this.mysteryDigitClip_1._off = true;

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#000000").s().p("AgLBAQgEgEAAgFQAAgFAEgEQADgDAFAAQAEAAAEADQADAEAAAFQAAAFgDAEQgEADgEAAQgFAAgDgDgAgHAcQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIAAgPIABgGQAAgCADgBIAJgJIAJgKQAEgGABgHQgBgIgFgEQgFgEgHAAQgIAAgFABIgJADIgFACIgCgBIgBgCIgBgJIABgEIADgCIAJgCIAKgCIAKgBQAJAAAIAEQAHADAFAHQAEAHABAKQgBAJgDAHQgEAHgFAGIgMAKIgDAEIgBAEIAAALIgCAEIgDABg");
	this.shape_197.setTransform(-44.5,-24.2);

	this.instance_12 = new lib.HM_mcmystnumdigitbackwhite();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-44.3,-24.2,0.75,0.75,0,0,0,14,18.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_8}]},31).to({state:[{t:this.instance_8}]},3).to({state:[{t:this.instance_8}]},6).to({state:[{t:this.instance_8}]},3).to({state:[{t:this.instance_8}]},6).to({state:[{t:this.instance_8}]},3).to({state:[{t:this.instance_8}]},6).to({state:[]},1).to({state:[{t:this.instance_9}]},107).to({state:[{t:this.instance_9}]},3).to({state:[{t:this.instance_9}]},6).to({state:[{t:this.instance_9}]},3).to({state:[{t:this.instance_9}]},6).to({state:[{t:this.instance_9}]},3).to({state:[{t:this.instance_9}]},6).to({state:[]},1).to({state:[{t:this.instance_10}]},69).to({state:[{t:this.instance_10}]},3).to({state:[{t:this.instance_10}]},6).to({state:[{t:this.instance_10}]},3).to({state:[{t:this.instance_10}]},6).to({state:[{t:this.instance_10}]},3).to({state:[{t:this.instance_10}]},6).to({state:[]},1).to({state:[{t:this.instance_11}]},75).to({state:[{t:this.instance_11}]},3).to({state:[{t:this.instance_11}]},6).to({state:[{t:this.instance_11}]},3).to({state:[{t:this.instance_11}]},6).to({state:[{t:this.instance_11}]},3).to({state:[{t:this.instance_11}]},6).to({state:[]},1).to({state:[{t:this.mysteryDigitClip}]},169).to({state:[{t:this.mysteryDigitClip_1}]},55).to({state:[{t:this.mysteryDigitClip_1}]},3).to({state:[{t:this.mysteryDigitClip_1}]},6).to({state:[{t:this.mysteryDigitClip_1}]},3).to({state:[{t:this.mysteryDigitClip_1}]},6).to({state:[{t:this.mysteryDigitClip_1}]},3).to({state:[{t:this.mysteryDigitClip_1}]},6).to({state:[{t:this.mysteryDigitClip}]},1).to({state:[{t:this.instance_12},{t:this.shape_197}]},96).wait(111));
	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(31).to({_off:false},0).to({scaleX:1.13,scaleY:1.13},3).to({scaleX:1,scaleY:1},6).to({scaleX:1.13,scaleY:1.13},3).to({scaleX:1,scaleY:1},6).to({scaleX:1.13,scaleY:1.13},3).to({scaleX:1,scaleY:1},6).to({_off:true},1).wait(794));
	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(166).to({_off:false},0).to({scaleX:1.3,scaleY:1.25},3).to({scaleX:1,scaleY:1.19},6).to({scaleX:1.3,scaleY:1.25},3).to({scaleX:1,scaleY:1.19},6).to({scaleX:1.3,scaleY:1.25},3).to({scaleX:1,scaleY:1.19},6).to({_off:true},1).wait(659));
	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(263).to({_off:false},0).to({scaleX:1.08,scaleY:1.25},3).to({scaleX:1,scaleY:1},6).to({scaleX:1.08,scaleY:1.25},3).to({scaleX:1,scaleY:1},6).to({scaleX:1.08,scaleY:1.25},3).to({scaleX:1,scaleY:1},6).to({_off:true},1).wait(562));
	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(366).to({_off:false},0).to({scaleX:0.85,scaleY:0.85},3).to({scaleX:0.75,scaleY:0.75},6).to({scaleX:0.85,scaleY:0.85},3).to({scaleX:0.75,scaleY:0.75},6).to({scaleX:0.85,scaleY:0.85},3).to({scaleX:0.75,scaleY:0.75},6).to({_off:true},1).wait(459));
	this.timeline.addTween(cjs.Tween.get(this.mysteryDigitClip_1).wait(618).to({_off:false},0).to({scaleX:0.85,scaleY:0.85},3).to({scaleX:0.75,scaleY:0.75},6).to({scaleX:0.85,scaleY:0.85},3).to({scaleX:0.75,scaleY:0.75},6).to({scaleX:0.85,scaleY:0.85},3).to({scaleX:0.75,scaleY:0.75},6).to({_off:true},1).wait(207));

	// next clue button
	this.instance_13 = new lib.HM_HAR_harnextcluesbutton("single",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(-1.5,-91.9,0.75,0.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(853));

	// clues
	this.HM_clues = new lib.HM_mccluesclip();
	this.HM_clues.name = "HM_clues";
	this.HM_clues.parent = this;
	this.HM_clues.setTransform(10.8,138,0.75,0.75,0,0,0,327.8,27.4);

	this.timeline.addTween(cjs.Tween.get(this.HM_clues).wait(853));

	// Hilite
	this.instance_14 = new lib.HM_HAR_harmystnumcluepanelhilite("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(-1.9,-96.3,0.75,0.75,0,0,0,0.6,-0.1);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(75).to({_off:false},0).to({regX:0.5,scaleX:0.78,scaleY:1,y:-96.4},3).to({regX:0.6,scaleX:0.75,scaleY:0.75,y:-96.3},6).to({regX:0.5,scaleX:0.78,scaleY:1,y:-96.4},3).to({regX:0.6,scaleX:0.75,scaleY:0.75,y:-96.3},6).to({regX:0.5,scaleX:0.78,scaleY:1,y:-96.4},3).to({regX:0.6,scaleX:0.75,scaleY:0.75,y:-96.3},6).to({_off:true},1).wait(750));

	// Layer 25
	this.stripLoader = new lib.Symbol2();
	this.stripLoader.name = "stripLoader";
	this.stripLoader.parent = this;
	this.stripLoader.setTransform(-297.9,-222.7,1,1,0,0,0,2.5,2.5);

	this.timeline.addTween(cjs.Tween.get(this.stripLoader).wait(853));

	// Background
	this.HM_table = new lib.HM_mctable_6cols();
	this.HM_table.name = "HM_table";
	this.HM_table.parent = this;
	this.HM_table.setTransform(-3.4,63.6,0.75,0.75,0,0,0,150,127.8);

	this.instance_15 = new lib.HM_HAR_harmystnumcluepanel("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(-1.9,-96.3,0.75,0.75,0,0,0,0.6,-0.1);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#000000").s().p("AgYAjQgJgKAAgSIAAgvIAAgDIADgBIAGAAIACABIAAADIAAAtQAAAOAHAHQAFAIAKAAQALAAAGgIQAFgHAAgOIAAgtIABgDIADgBIAFAAIADABIAAADIAAAvQAAASgJAKQgIAKgRAAQgQAAgIgKg");
	this.shape_198.setTransform(-15.3,1);

	this.instance_16 = new lib.HM_HAR_harthousandsbuttonnew("single",0);
	this.instance_16.parent = this;
	this.instance_16.setTransform(-15.3,1.4,0.75,0.75);

	this.mysteryDigitClip_2 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_2.name = "mysteryDigitClip_2";
	this.mysteryDigitClip_2.parent = this;
	this.mysteryDigitClip_2.setTransform(-15.4,-24.7,0.75,0.75,0,0,0,25,15);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#000000").s().p("AAYA3IgDgBIgBgEIAAgsIgBAAQgEAFgFACQgEACgHAAQgLAAgGgFQgIgEgEgHQgEgHAAgKQABgKADgIQAEgIAHgFQAIgFALAAQAFAAAFACQAGACAEAEIAAgCIABgDIADgBIAHAAIADABIABADIAABiIgBAEIgDABgAgIgmQgFADgCAFQgDAFABAGQgBAGADAFQACAFAEADQAEACAFAAQAJAAAFgEQAGgGAAgKQAAgHgCgFQgDgFgEgDQgEgDgGAAQgFAAgEADg");
	this.shape_199.setTransform(-15.4,192.4);

	this.instance_17 = new lib.HM_mcclipwhite();
	this.instance_17.parent = this;
	this.instance_17.setTransform(-14.8,191.9,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#000000").s().p("AgRA0QgJgDgFgGQgFgHAAgLQAAgGADgGQADgGAFgEQAFgDAHgCIAAAAQgKgEgFgHQgFgGAAgKQAAgJAFgGQAFgFAIgDQAIgDAIAAQAIAAAHADQAIACAFAGQAFAGAAAIQAAAKgFAGQgFAGgJAFIAAAAIALAFQAFAEADAFQADAGAAAHQAAALgFAHQgFAHgJADQgIAEgKAAQgJAAgIgEgAgKAIQgFADgCAEQgDAEAAAGQAAAGADAEQADAEAFACQAFACAFAAQAFAAAFgCQAEgCADgEQADgEAAgFQAAgHgDgEQgDgEgFgDIgMgFIgIAFgAgIgpIgHAFQgDADAAAFQAAAFADAEIAJAGIAJAGIAHgGIAFgGQACgEABgFQgBgFgCgDQgDgDgEgCIgIgBIgIABg");
	this.shape_200.setTransform(-15,173.5);

	this.instance_18 = new lib.HM_mcclipwhite();
	this.instance_18.parent = this;
	this.instance_18.setTransform(-14.8,173,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#000000").s().p("AgTA2IgCgBIAAgBIAAgBIAAgBIAlhZIgtAAIgCgBIgBgEIAAgEIABgEIACgBIA7AAIADABIAAAEIAAACIAAADIgBAEIgkBZIgDADIgDABg");
	this.shape_201.setTransform(-15,154.5);

	this.instance_19 = new lib.HM_mcclipwhite();
	this.instance_19.parent = this;
	this.instance_19.setTransform(-14.8,154,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#000000").s().p("AgSAyQgIgGgEgMQgFgNAAgTQAAgQAFgMQAGgMAKgIQAJgHANAAIALABIAIACIACACIAAADIAAAHIgBACIgBAAIgEgBIgFgCIgIgBQgJAAgEAEQgGADgEAGQgDAFgCAHQgCAHAAAHQAFgFAGgDQAGgCAGAAQAKAAAHAEQAHAEAFAGQAEAIAAALQAAAKgEAIQgFAIgHAFQgIAFgLAAQgLAAgIgGgAgIABQgEADgDAFQgCAFAAAHQAAAGACAFQACAFAFADQAEADAFAAQAGAAAFgDQAEgDACgGQACgFAAgGQAAgFgCgFQgCgFgEgDQgEgCgGAAQgFAAgFABg");
	this.shape_202.setTransform(-14.9,135.5);

	this.instance_20 = new lib.HM_mcclipwhite();
	this.instance_20.parent = this;
	this.instance_20.setTransform(-14.8,135,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#000000").s().p("AgTA2IgKgDIgCgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAgIIABgBIABAAIAFABIAGACIAKABQAHAAAFgDQAGgCADgFQADgFAAgHQAAgMgHgFQgHgFgLAAIgIABIgFABIgEAAIgDAAIgBgEIABguIABgDIACgBIAzAAIACABIABADIAAAGIgBADIgCABIgnAAIgBAcIAHgCIAHAAQAIAAAIAEQAIAEAFAHQAEAGAAAMQAAALgFAIQgFAJgKADQgJAFgLAAIgLgBg");
	this.shape_203.setTransform(-14.9,116.7);

	this.instance_21 = new lib.HM_mcclipwhite();
	this.instance_21.parent = this;
	this.instance_21.setTransform(-14.8,116,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#000000").s().p("AAOA2IgDgBIgBgDIAAgUIgtAAIgDgBQAAAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBIAAgFIABgEIABgCIAnhAIACgDIAEgBIAJAAIACABIABABIgBACIAAABIgpBAIAgAAIAAgVIABgEIADgBIAHAAIADABIABAEIAAAVIALAAIADABIABAEIAAAEIgBAEIgDABIgLAAIAAAUIgBADIgDABg");
	this.shape_204.setTransform(-15.1,97.6);

	this.instance_22 = new lib.HM_mcclipwhite();
	this.instance_22.parent = this;
	this.instance_22.setTransform(-14.8,97.1,0.75,0.75,0,0,0,15.7,11.8);

	this.clip3 = new lib.HM_mcnumberToggle();
	this.clip3.name = "clip3";
	this.clip3.parent = this;
	this.clip3.setTransform(-15.4,78,0.75,0.75,0,0,0,25,10.1);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#000000").s().p("AgdA3IgDgBIgBgEIAAgFIABgEIADgEIAPgOIAOgOQAGgHAFgHQAEgHABgJQgBgHgCgEQgDgEgFgCQgFgCgEAAIgLABIgHADIgFABIgBgBIgBgCIgBgHIABgDIACgCIAIgCIAJgBIAJgBQAJAAAIAEQAHADAFAHQAEAHAAAKQAAAKgEAIQgEAHgHAJIgPAPIgPAPIArAAIADABQABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAIAAAFQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBABIgDABg");
	this.shape_205.setTransform(-15.3,59.5);

	this.instance_23 = new lib.HM_mcclipwhite();
	this.instance_23.parent = this;
	this.instance_23.setTransform(-14.8,59.1,0.75,0.75,0,0,0,15.7,11.8);

	this.clip1 = new lib.HM_mcnumberToggle();
	this.clip1.name = "clip1";
	this.clip1.parent = this;
	this.clip1.setTransform(-15.4,40.1,0.75,0.75,0,0,0,25,10.1);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#000000").s().p("AgRAyQgIgFgDgIQgEgIgCgKQgCgJABgKIABgTQACgJAEgJQADgIAIgFQAHgFAKAAQALAAAIAFQAGAFAEAIQAEAJACAJIACATQgBAKgBAJQgCAKgEAIQgEAIgGAFQgIAFgLABQgKgBgHgFgAgLgkQgFAFgCAJQgCAKAAAMQAAANACAJQACAKAFAFQAFAFAGAAQAHAAAEgFQAFgFADgKQACgJAAgNQAAgMgCgKQgDgJgFgFQgEgFgHAAQgGAAgFAFg");
	this.shape_206.setTransform(-15,21.7);

	this.instance_24 = new lib.HM_mcclipwhite();
	this.instance_24.parent = this;
	this.instance_24.setTransform(-14.8,21.2,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#000000").s().p("AAMAqQgLAAgEgGQgFgFABgLIAAggIgKAAIgCAAIgBgDIAAgCIABgDIACgBIAKAAIAAgRIAAgCIADgBIAEAAIACABIABACIAAARIAOAAIACABIABADIAAACIgBADIgCAAIgOAAIAAAeQAAAHACAEQADADAEABIAEgBIADAAIABAAIABABIAAAGIgBACIgBAAIgDABIgEAAg");
	this.shape_207.setTransform(13.1,1.3);

	this.instance_25 = new lib.HM_HAR_harthousandsbuttonnew("single",0);
	this.instance_25.parent = this;
	this.instance_25.setTransform(13.2,1.4,0.75,0.75);

	this.mysteryDigitClip_3 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_3.name = "mysteryDigitClip_3";
	this.mysteryDigitClip_3.parent = this;
	this.mysteryDigitClip_3.setTransform(13.1,-24.7,0.75,0.75,0,0,0,25,15);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#000000").s().p("AAYA3IgDgBIgBgEIAAgsIgBAAQgEAFgFACQgEACgHAAQgLAAgGgFQgIgEgDgHQgFgHAAgKQABgKADgIQAEgIAHgFQAIgFALAAQAFAAAFACQAGACAEAEIAAgCIABgDIADgBIAHAAIADABIABADIAABiIgBAEIgDABgAgIgmQgFADgCAFQgDAFABAGQgBAGADAFQACAFAEADQAEACAFAAQAJAAAGgEQAFgGAAgKQAAgHgCgFQgCgFgFgDQgEgDgGAAQgGAAgDADg");
	this.shape_208.setTransform(13,192.4);

	this.instance_26 = new lib.HM_mcclipwhite();
	this.instance_26.parent = this;
	this.instance_26.setTransform(13.7,191.9,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#000000").s().p("AgRA0QgJgDgFgGQgFgHAAgLQAAgGADgGQADgGAFgEQAFgDAHgCIAAAAQgKgEgFgHQgFgGAAgKQAAgJAFgGQAFgFAIgDQAIgDAIAAQAIAAAHADQAIACAFAGQAFAGAAAIQAAAKgFAGQgFAGgJAFIAAAAIALAFQAFAEADAFQADAGAAAHQAAALgFAHQgFAHgJADQgIAEgKAAQgJAAgIgEgAgKAIQgFADgCAEQgDAEAAAGQAAAGADAEQADAEAFACQAFACAFAAQAFAAAFgCQAEgCADgEQADgEAAgFQAAgHgDgEQgDgEgFgDIgMgFIgIAFgAgIgpIgHAFQgDADAAAFQAAAFADAEIAJAGIAJAGIAHgGIAFgGQACgEABgFQgBgFgCgDQgDgDgEgCIgIgBIgIABg");
	this.shape_209.setTransform(13.5,173.5);

	this.instance_27 = new lib.HM_mcclipwhite();
	this.instance_27.parent = this;
	this.instance_27.setTransform(13.7,173,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#000000").s().p("AgTA2IgCgBIAAgBIAAgBIAAgBIAlhZIgtAAIgCgBIgBgEIAAgEIABgEIACgBIA7AAIACABIABAEIAAACIAAADIgBAEIgkBZIgCADIgEABg");
	this.shape_210.setTransform(13.4,154.5);

	this.instance_28 = new lib.HM_mcclipwhite();
	this.instance_28.parent = this;
	this.instance_28.setTransform(13.7,154,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#000000").s().p("AgSAyQgIgGgEgMQgFgNAAgTQAAgQAFgMQAGgMAKgIQAJgHANAAIALABIAIACIACACIAAADIAAAHIgBACIgBAAIgEgBIgFgCIgIgBQgJAAgEAEQgGADgEAGQgDAFgCAHQgCAHAAAHQAFgFAGgDQAGgCAGAAQAKAAAHAEQAHAEAFAGQAEAIAAALQAAAKgEAIQgFAIgHAFQgIAFgLAAQgLAAgIgGgAgIABQgEADgDAFQgCAFAAAHQAAAGACAFQACAFAFADQAEADAFAAQAGAAAFgDQAEgDACgGQACgFAAgGQAAgFgCgFQgCgFgEgDQgEgCgGAAQgFAAgFABg");
	this.shape_211.setTransform(13.5,135.5);

	this.instance_29 = new lib.HM_mcclipwhite();
	this.instance_29.parent = this;
	this.instance_29.setTransform(13.7,135,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#000000").s().p("AgTA2IgKgDIgCgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAgIIABgBIABAAIAFABIAGACIAKABQAHAAAFgDQAGgCADgFQADgFAAgHQAAgMgHgFQgHgFgLAAIgIABIgFABIgEAAIgDAAIgBgEIABguIABgDIACgBIAzAAIACABIABADIAAAGIgBADIgCABIgnAAIgBAcIAHgCIAHAAQAIAAAIAEQAIAEAFAHQAEAGAAAMQAAALgFAIQgFAJgKADQgJAFgLAAIgLgBg");
	this.shape_212.setTransform(13.5,116.7);

	this.instance_30 = new lib.HM_mcclipwhite();
	this.instance_30.parent = this;
	this.instance_30.setTransform(13.7,116,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#000000").s().p("AAOA2IgDgBIgBgDIAAgUIgtAAIgDgBQAAAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBIAAgFIABgEIABgCIAnhAIACgDIAEgBIAJAAIACABIABABIgBACIAAABIgpBAIAgAAIAAgVIABgEIADgBIAHAAIADABIABAEIAAAVIALAAIADABIABAEIAAAEIgBAEIgDABIgLAAIAAAUIgBADIgDABg");
	this.shape_213.setTransform(13.4,97.6);

	this.instance_31 = new lib.HM_mcclipwhite();
	this.instance_31.parent = this;
	this.instance_31.setTransform(13.7,97.1,0.75,0.75,0,0,0,15.8,11.8);

	this.clip3_1 = new lib.HM_mcnumberToggle();
	this.clip3_1.name = "clip3_1";
	this.clip3_1.parent = this;
	this.clip3_1.setTransform(13.1,78,0.75,0.75,0,0,0,25,10.1);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#000000").s().p("AgdA3IgDgBIgBgEIAAgFIABgEIADgEIAPgOIAOgOQAGgHAFgHQAEgHABgJQgBgHgCgEQgDgEgFgCQgFgCgEAAIgLABIgHADIgFABIgBgBIgBgCIgBgHIABgDIACgCIAIgCIAJgBIAJgBQAJAAAIAEQAHADAFAHQAEAHAAAKQAAAKgEAIQgEAHgHAJIgPAPIgPAPIArAAIADABQABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAIAAAFQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBABIgDABg");
	this.shape_214.setTransform(13.2,59.5);

	this.instance_32 = new lib.HM_mcclipwhite();
	this.instance_32.parent = this;
	this.instance_32.setTransform(13.7,59.1,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#000000").s().p("AgCA2IgEgBIgBgDIAAhiIABgEIAEgBIAFAAIAEABIABAEIAABiIgBADIgEABg");
	this.shape_215.setTransform(13.5,40.7);

	this.instance_33 = new lib.HM_mcclipwhite();
	this.instance_33.parent = this;
	this.instance_33.setTransform(13.7,40.1,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#000000").s().p("AgRAyQgIgFgDgIQgFgIgBgKQgCgJABgKIABgTQABgJAFgJQADgIAIgFQAHgFAKAAQALAAAIAFQAHAFADAIQAFAJABAJIACATQgBAKgBAJQgBAKgFAIQgDAIgHAFQgIAFgLABQgKgBgHgFgAgLgkQgEAFgDAJQgCAKAAAMQAAANACAJQADAKAEAFQAFAFAGAAQAHAAAEgFQAGgFACgKQACgJAAgNQAAgMgCgKQgCgJgGgFQgEgFgHAAQgGAAgFAFg");
	this.shape_216.setTransform(13.5,21.7);

	this.instance_34 = new lib.HM_mcclipwhite();
	this.instance_34.parent = this;
	this.instance_34.setTransform(13.7,21.2,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#000000").s().p("AgCAsIgDgBIAAgDIAAhHIgYAAIgDgBIgBgDIAAgFIABgCIADgBIA7AAIADABIABACIAAAFIgBADIgDABIgYAAIAABHIgBADIgCABg");
	this.shape_217.setTransform(-44.5,0.9);

	this.instance_35 = new lib.HM_HAR_harthousandsbuttonnew("single",0);
	this.instance_35.parent = this;
	this.instance_35.setTransform(-44.5,1.4,0.75,0.75);

	this.mysteryDigitClip_4 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_4.name = "mysteryDigitClip_4";
	this.mysteryDigitClip_4.parent = this;
	this.mysteryDigitClip_4.setTransform(-44.7,-24.7,0.75,0.75,0,0,0,25,15);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#000000").s().p("AAYA3IgDgBIgBgEIAAgsIgBAAQgEAFgFACQgEACgHAAQgLAAgGgFQgIgEgEgHQgEgHAAgKQABgKADgIQAEgIAHgFQAIgFALAAQAFAAAFACQAGACAEAEIAAgCIABgDIADgBIAHAAIADABIABADIAABiIgBAEIgDABgAgIgmQgFADgCAFQgDAFABAGQgBAGADAFQACAFAEADQAEACAFAAQAJAAAFgEQAGgGAAgKQAAgHgCgFQgDgFgEgDQgEgDgGAAQgFAAgEADg");
	this.shape_218.setTransform(-44.7,192.4);

	this.instance_36 = new lib.HM_mcclipwhite();
	this.instance_36.parent = this;
	this.instance_36.setTransform(-44.1,191.9,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#000000").s().p("AgRA0QgJgDgFgGQgFgHAAgLQAAgGADgGQADgGAFgEQAFgDAHgCIAAAAQgKgEgFgHQgFgGAAgKQAAgJAFgGQAFgFAIgDQAIgDAIAAQAIAAAHADQAIACAFAGQAFAGAAAIQAAAKgFAGQgFAGgJAFIAAAAIALAFQAFAEADAFQADAGAAAHQAAALgFAHQgFAHgJADQgIAEgKAAQgJAAgIgEgAgKAIQgFADgCAEQgDAEAAAGQAAAGADAEQADAEAFACQAFACAFAAQAFAAAFgCQAEgCADgEQADgEAAgFQAAgHgDgEQgDgEgFgDIgMgFIgIAFgAgIgpIgHAFQgDADAAAFQAAAFADAEIAJAGIAJAGIAHgGIAFgGQACgEABgFQgBgFgCgDQgDgDgEgCIgIgBIgIABg");
	this.shape_219.setTransform(-44.3,173.5);

	this.instance_37 = new lib.HM_mcclipwhite();
	this.instance_37.parent = this;
	this.instance_37.setTransform(-44.1,173,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#000000").s().p("AgTA2IgCgBIAAgBIAAgBIAAgBIAlhZIgtAAIgCgBIgBgEIAAgEIABgEIACgBIA7AAIADABIAAAEIAAACIAAADIgBAEIgkBZIgDADIgDABg");
	this.shape_220.setTransform(-44.3,154.5);

	this.instance_38 = new lib.HM_mcclipwhite();
	this.instance_38.parent = this;
	this.instance_38.setTransform(-44.1,154,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#000000").s().p("AgSAyQgIgGgEgMQgFgNAAgTQAAgQAFgMQAGgMAKgIQAJgHANAAIALABIAIACIACACIAAADIAAAHIgBACIgBAAIgEgBIgFgCIgIgBQgJAAgEAEQgGADgEAGQgDAFgCAHQgCAHAAAHQAFgFAGgDQAGgCAGAAQAKAAAHAEQAHAEAFAGQAEAIAAALQAAAKgEAIQgFAIgHAFQgIAFgLAAQgLAAgIgGgAgIABQgEADgDAFQgCAFAAAHQAAAGACAFQACAFAFADQAEADAFAAQAGAAAFgDQAEgDACgGQACgFAAgGQAAgFgCgFQgCgFgEgDQgEgCgGAAQgFAAgFABg");
	this.shape_221.setTransform(-44.2,135.5);

	this.instance_39 = new lib.HM_mcclipwhite();
	this.instance_39.parent = this;
	this.instance_39.setTransform(-44.1,135,0.75,0.75,0,0,0,15.7,11.8);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#000000").s().p("AgTA2IgKgDIgCgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAgIIABgBIABAAIAFABIAGACIAKABQAHAAAFgDQAGgCADgFQADgFAAgHQAAgMgHgFQgHgFgLAAIgIABIgFABIgEAAIgDAAIgBgEIABguIABgDIACgBIAzAAIACABIABADIAAAGIgBADIgCABIgnAAIgBAcIAHgCIAHAAQAIAAAIAEQAIAEAFAHQAEAGAAAMQAAALgFAIQgFAJgKADQgJAFgLAAIgLgBg");
	this.shape_222.setTransform(-44.2,116.7);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#9C9C9C").s().p("AhWBPQgIAAgGgGQgGgFAAgJIAAh1QAAgIAGgGQAGgGAIAAICuAAQAIAAAFAGQAGAGAAAIIAAB1QAAAJgGAFQgFAGgIAAg");
	this.shape_223.setTransform(-44.2,116.1);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-9.5,-9.5,9.6,9.6).s().p("AhbBZQgLAAgHgIQgHgHAAgKIAAh/QAAgKAHgHQAHgIALAAIC3AAQAKAAAIAIQAHAHAAAKIAAB/QAAAKgHAHQgIAIgKAAg");
	this.shape_224.setTransform(-44.1,116.1);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#000000").s().p("AAOA2IgDgBIgBgDIAAgUIgtAAIgDgBQAAAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBIAAgFIABgEIABgCIAnhAIACgDIAEgBIAJAAIACABIABABIgBACIAAABIgpBAIAgAAIAAgVIABgEIADgBIAHAAIADABIABAEIAAAVIALAAIADABIABAEIAAAEIgBAEIgDABIgLAAIAAAUIgBADIgDABg");
	this.shape_225.setTransform(-44.3,97.6);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#9C9C9C").s().p("AhWBPQgIAAgGgGQgGgFAAgJIAAh1QAAgIAGgGQAGgGAIAAICuAAQAIAAAFAGQAGAGAAAIIAAB1QAAAJgGAFQgFAGgIAAg");
	this.shape_226.setTransform(-44.2,97.1);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-9.5,-9.5,9.6,9.6).s().p("AhbBZQgLAAgHgIQgHgGAAgLIAAh/QAAgKAHgIQAHgHALAAIC3AAQAKAAAIAHQAHAIAAAKIAAB/QAAALgHAGQgIAIgKAAg");
	this.shape_227.setTransform(-44.1,97.1);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#000000").s().p("AgTA3IgKgDIgCgBIgBgDIABgIIABgBIABgBIAEABIAGADIALABQAHAAAFgCQAGgCAEgEQAEgEAAgHQAAgKgHgEQgHgFgLAAIgHAAIgDgBQgBgBAAAAQAAAAAAgBQgBAAAAAAQAAgBAAAAIAAgEQAAgBAAAAQAAgBABAAQAAAAAAgBQAAAAABAAIADgBIAGAAQAGAAAEgCQAGgBAEgEQAEgEAAgHQAAgGgDgEQgDgDgFgCQgEgCgFABIgKABIgIADIgEABIgCgBIAAgBIgBgIQAAAAAAAAQAAgBAAAAQAAAAAAgBQABAAAAAAIACgCIALgEIANgBQAJAAAIADQAHADAFAGQAFAGAAALQAAAGgDAGQgDAFgGADQgFAEgGABQAHABAFACQAGADADAGQADAFAAAJQAAAIgEAGQgDAGgGAEQgGADgIACQgGACgIAAIgLgBg");
	this.shape_228.setTransform(-44.4,78.6);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#9C9C9C").s().p("AhWBPQgIAAgGgGQgGgGAAgIIAAh1QAAgIAGgGQAGgGAIAAICuAAQAIAAAFAGQAGAGAAAIIAAB1QAAAIgGAGQgFAGgIAAg");
	this.shape_229.setTransform(-44.2,78.1);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-9.5,-9.5,9.6,9.6).s().p("AhbBZQgLAAgHgIQgHgGAAgLIAAh/QAAgKAHgIQAHgHALAAIC3AAQAKAAAIAHQAHAIAAAKIAAB/QAAALgHAGQgIAIgKAAg");
	this.shape_230.setTransform(-44.1,78.1);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#000000").s().p("AgdA3IgDgBIgBgEIAAgFIABgEIADgEIAPgOIAOgOQAGgHAFgHQAEgHABgJQgBgHgCgEQgDgEgFgCQgFgCgEAAIgLABIgHADIgFABIgBgBIgBgCIgBgHIABgDIACgCIAIgCIAJgBIAJgBQAJAAAIAEQAHADAFAHQAEAHAAAKQAAAKgEAIQgEAHgHAJIgPAPIgPAPIArAAIADABQABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAIAAAFQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBABIgDABg");
	this.shape_231.setTransform(-44.6,59.5);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#9C9C9C").s().p("AhWBPQgIAAgGgGQgGgGAAgIIAAh1QAAgIAGgGQAGgGAIAAICuAAQAIAAAFAGQAGAGAAAIIAAB1QAAAIgGAGQgFAGgIAAg");
	this.shape_232.setTransform(-44.2,59.2);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-9.5,-9.5,9.6,9.6).s().p("AhbBZQgLAAgHgHQgHgIAAgKIAAh/QAAgLAHgGQAHgIALAAIC3AAQAKAAAIAIQAHAGAAALIAAB/QAAAKgHAIQgIAHgKAAg");
	this.shape_233.setTransform(-44.1,59.2);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#000000").s().p("AgDA2IgDgBIgBgDIAAhiIABgEIADgBIAGAAIAEABIABAEIAABiIgBADIgEABg");
	this.shape_234.setTransform(-44.2,40.7);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#9C9C9C").s().p("AhWBPQgIAAgGgGQgGgGAAgIIAAh1QAAgIAGgGQAGgGAIAAICuAAQAIAAAFAGQAGAGAAAIIAAB1QAAAIgGAGQgFAGgIAAg");
	this.shape_235.setTransform(-44.2,40.2);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-9.5,-9.5,9.6,9.6).s().p("AhbBZQgLAAgHgHQgHgIAAgKIAAh/QAAgLAHgGQAHgIALAAIC3AAQAKAAAIAIQAHAGAAALIAAB/QAAAKgHAIQgIAHgKAAg");
	this.shape_236.setTransform(-44.1,40.2);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#000000").s().p("AgRAyQgIgFgDgIQgEgIgCgKQgCgJABgKIABgTQACgJAEgJQADgIAIgFQAHgFAKAAQALAAAIAFQAGAFAEAIQAEAJACAJIACATQgBAKgBAJQgCAKgEAIQgEAIgGAFQgIAFgLABQgKgBgHgFgAgLgkQgFAFgCAJQgCAKAAAMQAAANACAJQACAKAFAFQAFAFAGAAQAHAAAEgFQAFgFADgKQACgJAAgNQAAgMgCgKQgDgJgFgFQgEgFgHAAQgGAAgFAFg");
	this.shape_237.setTransform(-44.2,21.7);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#9C9C9C").s().p("AhWBPQgIAAgGgGQgGgGAAgIIAAh1QAAgIAGgGQAGgGAIAAICuAAQAIAAAFAGQAGAGAAAIIAAB1QAAAIgGAGQgFAGgIAAg");
	this.shape_238.setTransform(-44.2,21.2);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-9.5,-9.5,9.6,9.6).s().p("AhbBZQgLAAgHgIQgHgHAAgKIAAh/QAAgKAHgHQAHgIALAAIC3AAQAKAAAIAIQAHAHAAAKIAAB/QAAAKgHAHQgIAIgKAAg");
	this.shape_239.setTransform(-44.1,21.2);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#000000").s().p("AATAvIgCgBIgBgCIAAghQAAgIgCgEQgEgFgHAAQgGAAgEADQgEADgCAFQgDAGAAAGIAAAbIgBACIgCABIgFAAIgDgBIAAgCIAAhXIAAgDIADAAIAFAAIACAAIABADIAAAmIAAAAQAEgFAFgDQAFgDAHAAQAHAAAEADQAFACADAEQACAEABAEIABAJIAAAiIgBACIgCABg");
	this.shape_240.setTransform(41.7,0.6);

	this.instance_40 = new lib.HM_HAR_harthousandsbuttonnew("single",0);
	this.instance_40.parent = this;
	this.instance_40.setTransform(41.7,1.4,0.75,0.75);

	this.mysteryDigitClip_5 = new lib.HM_mcmysteryDigitClip();
	this.mysteryDigitClip_5.name = "mysteryDigitClip_5";
	this.mysteryDigitClip_5.parent = this;
	this.mysteryDigitClip_5.setTransform(41.6,-24.7,0.75,0.75,0,0,0,25,15);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f("#000000").s().p("AAYA3IgDgBIgBgEIAAgsIgBAAQgDAFgGACQgEACgHAAQgKAAgHgFQgIgEgDgHQgFgHAAgKQABgKADgIQAEgIAHgFQAIgFALAAQAFAAAFACQAGACAEAEIAAgCIABgDIADgBIAHAAIADABIABADIAABiIgBAEIgDABgAgJgmQgEADgCAFQgCAFgBAGQABAGACAFQACAFAEADQAEACAFAAQAJAAAGgEQAFgGAAgKQAAgHgCgFQgDgFgEgDQgEgDgGAAQgGAAgEADg");
	this.shape_241.setTransform(41.5,192.4);

	this.instance_41 = new lib.HM_mcclipwhite();
	this.instance_41.parent = this;
	this.instance_41.setTransform(42.2,191.9,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#000000").s().p("AgRA0QgJgDgFgGQgFgHAAgLQAAgGADgGQADgGAFgEQAFgDAHgCIAAAAQgKgEgFgHQgFgGAAgKQAAgJAFgGQAFgFAIgDQAIgDAIAAQAIAAAHADQAIACAFAGQAFAGAAAIQAAAKgFAGQgFAGgJAFIAAAAIALAFQAFAEADAFQADAGAAAHQAAALgFAHQgFAHgJADQgIAEgKAAQgJAAgIgEgAgKAIQgFADgCAEQgDAEAAAGQAAAGADAEQADAEAFACQAFACAFAAQAFAAAFgCQAEgCADgEQADgEAAgFQAAgHgDgEQgDgEgFgDIgMgFIgIAFgAgIgpIgHAFQgDADAAAFQAAAFADAEIAJAGIAJAGIAHgGIAFgGQACgEABgFQgBgFgCgDQgDgDgEgCIgIgBIgIABg");
	this.shape_242.setTransform(41.9,173.5);

	this.instance_42 = new lib.HM_mcclipwhite();
	this.instance_42.parent = this;
	this.instance_42.setTransform(42.2,173,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#000000").s().p("AgTA2IgCgBIgBgBIAAgBIAAgBIAmhZIgtAAIgCgBIgBgEIAAgEIABgEIACgBIA7AAIACABIABAEIAAACIAAADIgBAEIgkBZIgCADIgEABg");
	this.shape_243.setTransform(41.9,154.5);

	this.instance_43 = new lib.HM_mcclipwhite();
	this.instance_43.parent = this;
	this.instance_43.setTransform(42.2,154,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#000000").s().p("AgSAyQgIgGgEgMQgFgNAAgTQAAgQAFgMQAGgMAKgIQAJgHANAAIALABIAIACIACACIAAADIAAAHIgBACIgBAAIgEgBIgFgCIgIgBQgJAAgEAEQgGADgEAGQgDAFgCAHQgCAHAAAHQAFgFAGgDQAGgCAGAAQAKAAAHAEQAHAEAFAGQAEAIAAALQAAAKgEAIQgFAIgHAFQgIAFgLAAQgLAAgIgGgAgIABQgEADgDAFQgCAFAAAHQAAAGACAFQACAFAFADQAEADAFAAQAGAAAFgDQAEgDACgGQACgFAAgGQAAgFgCgFQgCgFgEgDQgEgCgGAAQgFAAgFABg");
	this.shape_244.setTransform(42,135.5);

	this.instance_44 = new lib.HM_mcclipwhite();
	this.instance_44.parent = this;
	this.instance_44.setTransform(42.2,135,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#000000").s().p("AgTA2IgKgDIgCgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBAAAAIAAgIIABgBIABAAIAFABIAGACIAKABQAHAAAFgDQAGgCADgFQADgFAAgHQAAgMgHgFQgHgFgLAAIgIABIgFABIgEAAIgDAAIgBgEIABguIABgDIACgBIAzAAIACABIABADIAAAGIgBADIgCABIgnAAIgBAcIAHgCIAHAAQAIAAAIAEQAIAEAFAHQAEAGAAAMQAAALgFAIQgFAJgKADQgJAFgLAAIgLgBg");
	this.shape_245.setTransform(42,116.7);

	this.instance_45 = new lib.HM_mcclipwhite();
	this.instance_45.parent = this;
	this.instance_45.setTransform(42.2,116,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f("#000000").s().p("AAOA2IgDgBIgBgDIAAgUIgtAAIgDgBQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAgBIAAgFIABgEIABgCIAnhAIACgDIAEgBIAJAAIACABIABABIgBACIAAABIgpBAIAgAAIAAgVIABgEIADgBIAHAAIADABIABAEIAAAVIALAAIADABIABAEIAAAEIgBAEIgDABIgLAAIAAAUIgBADIgDABg");
	this.shape_246.setTransform(41.8,97.6);

	this.instance_46 = new lib.HM_mcclipwhite();
	this.instance_46.parent = this;
	this.instance_46.setTransform(42.2,97.1,0.75,0.75,0,0,0,15.8,11.8);

	this.clip3_2 = new lib.HM_mcnumberToggle();
	this.clip3_2.name = "clip3_2";
	this.clip3_2.parent = this;
	this.clip3_2.setTransform(41.6,78,0.75,0.75,0,0,0,25,10.1);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#000000").s().p("AgdA3IgDgBIgBgEIAAgFIABgEIADgEIAPgOIAOgOQAGgHAFgHQAEgHABgJQgBgHgCgEQgDgEgFgCQgFgCgEAAIgLABIgHADIgFABIgBgBIgBgCIgBgHIABgDIACgCIAIgCIAJgBIAJgBQAJAAAIAEQAHADAFAHQAEAHAAAKQAAAKgEAIQgEAHgHAJIgPAPIgPAPIArAAIADABQABAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAIAAAFQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBABIgDABg");
	this.shape_247.setTransform(41.6,59.5);

	this.instance_47 = new lib.HM_mcclipwhite();
	this.instance_47.parent = this;
	this.instance_47.setTransform(42.2,59.1,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#000000").s().p("AgCA2IgEgBIgBgDIAAhiIABgEIAEgBIAFAAIAEABIABAEIAABiIgBADIgEABg");
	this.shape_248.setTransform(41.9,40.7);

	this.instance_48 = new lib.HM_mcclipwhite();
	this.instance_48.parent = this;
	this.instance_48.setTransform(42.2,40.1,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f("#000000").s().p("AgSAyQgHgFgDgIQgFgIgBgKQgBgJAAgKIABgTQABgJAFgJQADgIAHgFQAIgFAKAAQALAAAHAFQAIAFADAIQAFAJABAJIABATQABAKgCAJQgBAKgFAIQgDAIgIAFQgHAFgLABQgKgBgIgFgAgLgkQgEAFgDAJQgCAKAAAMQAAANACAJQADAKAEAFQAFAFAGAAQAHAAAEgFQAGgFABgKQADgJAAgNQAAgMgDgKQgBgJgGgFQgEgFgHAAQgGAAgFAFg");
	this.shape_249.setTransform(41.9,21.7);

	this.instance_49 = new lib.HM_mcclipwhite();
	this.instance_49.parent = this;
	this.instance_49.setTransform(42.2,21.2,0.75,0.75,0,0,0,15.8,11.8);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#000000").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_250.setTransform(-1.1,1.8);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#000000").s().p("AgIAJIAAgRIARAAIAAARg");
	this.shape_251.setTransform(-1.1,-24.1);

	this.instance_50 = new lib.HM_HAR_harmystnumgamepanel("synched",0);
	this.instance_50.parent = this;
	this.instance_50.setTransform(-1.5,82.1,0.75,0.75,0,0,0,0.5,0);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f().s("#720D09").ss(1,1,1).p("EAoWAD6QgbAcglAAMhOrAAAQglAAgbgcQgbgbAAglIAAl0QAAgmAbgaQAagbAmAAMBOrAAAQAlAAAbAbQAbAaAAAmIAAF0QAAAlgbAbg");
	this.shape_252.setTransform(-2.1,-96.3);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#FFFFCC").s().p("EgnUAEWQgmAAgbgbQgbgbABgmIAAl0QgBgmAbgaQAagaAngBMBOpAAAQAmABAbAaQAaAaAAAmIAAF0QAAAmgaAbQgbAbgmAAg");
	this.shape_253.setTransform(-2.1,-96.3);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.lf(["#BC9A85","#FFFFCC"],[0,1],-145.9,-145.9,145.9,145.9).s().p("EgnoAFKQgzAAgkgkQgjgkgBgzIAAmdQABgzAjgkQAkgkAzAAMBPRAAAQAzAAAjAkQAkAkAAAzIAAGdQAAAzgkAkQgjAkgzAAg");
	this.shape_254.setTransform(-1.9,-96.3);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-9.5,-9.5,9.6,9.6).s().p("AhbBZQgLAAgHgIQgHgGAAgLIAAh/QAAgKAHgIQAHgHALAAIC3AAQAKAAAIAHQAHAIAAAKIAAB/QAAALgHAGQgIAIgKAAg");
	this.shape_255.setTransform(-44.1,78.1);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#9C9C9C").s().p("AhWBPQgIAAgGgGQgGgGAAgIIAAh1QAAgIAGgGQAGgGAIAAICuAAQAIAAAFAGQAGAGAAAIIAAB1QAAAIgGAGQgFAGgIAAg");
	this.shape_256.setTransform(-44.2,59.2);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-9.5,-9.5,9.6,9.6).s().p("AhbBZQgLAAgHgHQgHgIAAgKIAAh/QAAgLAHgGQAHgIALAAIC3AAQAKAAAIAIQAHAGAAALIAAB/QAAAKgHAIQgIAHgKAAg");
	this.shape_257.setTransform(-44.1,59.2);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#9C9C9C").s().p("AhWBPQgIAAgGgGQgGgGAAgIIAAh1QAAgIAGgGQAGgGAIAAICuAAQAIAAAFAGQAGAGAAAIIAAB1QAAAIgGAGQgFAGgIAAg");
	this.shape_258.setTransform(-44.2,40.2);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.lf(["#C56400","#FF8D00","#FFFFB3"],[0,0.459,1],-9.5,-9.5,9.6,9.6).s().p("AhbBZQgLAAgHgHQgHgIAAgKIAAh/QAAgLAHgGQAHgIALAAIC3AAQAKAAAIAIQAHAGAAALIAAB/QAAAKgHAIQgIAHgKAAg");
	this.shape_259.setTransform(-44.1,40.2);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#9C9C9C").s().p("AhWBPQgIAAgGgGQgGgGAAgIIAAh1QAAgIAGgGQAGgGAIAAICuAAQAIAAAFAGQAGAGAAAIIAAB1QAAAIgGAGQgFAGgIAAg");
	this.shape_260.setTransform(-44.2,21.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_15},{t:this.HM_table}]}).to({state:[{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.instance_50},{t:this.shape_251},{t:this.shape_250},{t:this.instance_49},{t:this.shape_249},{t:this.instance_48},{t:this.shape_248},{t:this.instance_47},{t:this.shape_247},{t:this.clip3_2},{t:this.instance_46,p:{y:97.1}},{t:this.shape_246},{t:this.instance_45,p:{y:116}},{t:this.shape_245},{t:this.instance_44,p:{y:135}},{t:this.shape_244},{t:this.instance_43,p:{y:154}},{t:this.shape_243},{t:this.instance_42,p:{y:173}},{t:this.shape_242},{t:this.instance_41,p:{y:191.9}},{t:this.shape_241},{t:this.mysteryDigitClip_5},{t:this.instance_40},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238,p:{y:21.2}},{t:this.shape_237},{t:this.shape_236,p:{y:40.2}},{t:this.shape_235,p:{y:40.2}},{t:this.shape_234},{t:this.shape_233,p:{y:59.2}},{t:this.shape_232,p:{y:59.2}},{t:this.shape_231},{t:this.shape_230,p:{y:78.1}},{t:this.shape_229,p:{y:78.1}},{t:this.shape_228},{t:this.shape_227,p:{y:97.1}},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.instance_39,p:{regX:15.7,x:-44.1,y:135}},{t:this.shape_221},{t:this.instance_38,p:{regX:15.7,x:-44.1,y:154}},{t:this.shape_220},{t:this.instance_37,p:{regX:15.7,x:-44.1,y:173}},{t:this.shape_219},{t:this.instance_36,p:{y:191.9}},{t:this.shape_218},{t:this.mysteryDigitClip_4},{t:this.instance_35},{t:this.shape_217},{t:this.instance_34},{t:this.shape_216},{t:this.instance_33},{t:this.shape_215},{t:this.instance_32},{t:this.shape_214},{t:this.clip3_1},{t:this.instance_31},{t:this.shape_213},{t:this.instance_30},{t:this.shape_212},{t:this.instance_29},{t:this.shape_211},{t:this.instance_28},{t:this.shape_210},{t:this.instance_27},{t:this.shape_209},{t:this.instance_26},{t:this.shape_208},{t:this.mysteryDigitClip_3},{t:this.instance_25},{t:this.shape_207},{t:this.instance_24},{t:this.shape_206},{t:this.clip1},{t:this.instance_23},{t:this.shape_205},{t:this.clip3},{t:this.instance_22},{t:this.shape_204},{t:this.instance_21},{t:this.shape_203},{t:this.instance_20},{t:this.shape_202},{t:this.instance_19},{t:this.shape_201},{t:this.instance_18},{t:this.shape_200},{t:this.instance_17},{t:this.shape_199},{t:this.mysteryDigitClip_2},{t:this.instance_16},{t:this.shape_198}]},166).to({state:[{t:this.shape_254},{t:this.shape_253},{t:this.shape_252},{t:this.instance_50},{t:this.shape_251},{t:this.shape_250},{t:this.instance_46,p:{y:21.2}},{t:this.shape_249},{t:this.instance_45,p:{y:40.1}},{t:this.shape_248},{t:this.instance_44,p:{y:59.1}},{t:this.shape_247},{t:this.clip3_2},{t:this.instance_43,p:{y:97.1}},{t:this.shape_246},{t:this.instance_42,p:{y:116}},{t:this.shape_245},{t:this.instance_41,p:{y:135}},{t:this.shape_244},{t:this.instance_39,p:{regX:15.8,x:42.2,y:154}},{t:this.shape_243},{t:this.instance_38,p:{regX:15.8,x:42.2,y:173}},{t:this.shape_242},{t:this.instance_37,p:{regX:15.8,x:42.2,y:191.9}},{t:this.shape_241},{t:this.mysteryDigitClip_5},{t:this.instance_40},{t:this.shape_240},{t:this.shape_239},{t:this.shape_260},{t:this.shape_237},{t:this.shape_259},{t:this.shape_258},{t:this.shape_234},{t:this.shape_257},{t:this.shape_256},{t:this.shape_231},{t:this.shape_255},{t:this.shape_238,p:{y:78.1}},{t:this.shape_228},{t:this.shape_230,p:{y:97.1}},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.instance_36,p:{y:135}},{t:this.shape_221},{t:this.shape_236,p:{y:154}},{t:this.shape_235,p:{y:154}},{t:this.shape_220},{t:this.shape_233,p:{y:173}},{t:this.shape_232,p:{y:173}},{t:this.shape_219},{t:this.shape_227,p:{y:192}},{t:this.shape_229,p:{y:192}},{t:this.shape_218},{t:this.mysteryDigitClip_4},{t:this.instance_35},{t:this.shape_217},{t:this.instance_34},{t:this.shape_216},{t:this.instance_33},{t:this.shape_215},{t:this.instance_32},{t:this.shape_214},{t:this.clip3_1},{t:this.instance_31},{t:this.shape_213},{t:this.instance_30},{t:this.shape_212},{t:this.instance_29},{t:this.shape_211},{t:this.instance_28},{t:this.shape_210},{t:this.instance_27},{t:this.shape_209},{t:this.instance_26},{t:this.shape_208},{t:this.mysteryDigitClip_3},{t:this.instance_25},{t:this.shape_207},{t:this.instance_24},{t:this.shape_206},{t:this.clip1},{t:this.instance_23},{t:this.shape_205},{t:this.clip3},{t:this.instance_22},{t:this.shape_204},{t:this.instance_21},{t:this.shape_203},{t:this.instance_20},{t:this.shape_202},{t:this.instance_19},{t:this.shape_201},{t:this.instance_18},{t:this.shape_200},{t:this.instance_17},{t:this.shape_199},{t:this.mysteryDigitClip_2},{t:this.instance_16},{t:this.shape_198}]},397).to({state:[{t:this.instance_15},{t:this.HM_table}]},179).wait(111));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-295.1,-218.6,559.2,441.4);


// stage content:
(lib.sl69challengehelpview = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{screen1:1,screen2:149,screen3:327,screen4:564,screen5:743});

	// timeline functions:
	this.frame_0 = function() {
		$(".loader").hide();
		canvasTimeLine = this;
		window.canvasTimeLine = this;
		canvasTimeLine.stop();
		initButtons("visible");
		document.getElementById('game-button').style.display="block";
	}
	this.frame_11 = function() {
		frSound = playSound("HM_MysteryNo_nodecimal_ATT1_HM_NarSound1");
		window.frSound = frSound;
	}
	this.frame_71 = function() {
		frSound = playSound("HM_MysteryNo_nodecimal_ATT1_HM_NarSound2");
		window.frSound = frSound;
	}
	this.frame_159 = function() {
		frSound = playSound("HM_MysteryNo_nodecimal_ATT1_HM_NarSound3");
		window.frSound = frSound;
	}
	this.frame_221 = function() {
		frSound = playSound("HM_MysteryNo_nodecimal_ATT1_HM_NarSound4");
		window.frSound = frSound;
	}
	this.frame_338 = function() {
		frSound = playSound("HM_MysteryNo_nodecimal_ATT1_HM_NarSound5");
		window.frSound = frSound;
	}
	this.frame_410 = function() {
		frSound = playSound("HM_MysteryNo_nodecimal_ATT1_HM_NarSound6");
		window.frSound = frSound;
	}
	this.frame_574 = function() {
		frSound = playSound("HM_MysteryNo_nodecimal_ATT1_HM_NarSound7");
		window.frSound = frSound;
	}
	this.frame_661 = function() {
		frSound = playSound("HM_MysteryNo_nodecimal_ATT1_HM_NarSound8");
		window.frSound = frSound;
	}
	this.frame_748 = function() {
		frSound = playSound("HM_Generic_HM_NarSound1");
		window.frSound = frSound;
	}
	this.frame_771 = function() {
		frSound = playSound("HM_Generic_HM_NarSound2");
		window.frSound = frSound;
	}
	this.frame_817 = function() {
		frSound = playSound("HM_Generic_HM_NarSound3");
		window.frSound = frSound;
	}
	
	this.frame_852 = function() {
		stopAtEnd();
		canvasTimeLine.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(11).call(this.frame_11).wait(60).call(this.frame_71).wait(88).call(this.frame_159).wait(62).call(this.frame_221).wait(117).call(this.frame_338).wait(72).call(this.frame_410).wait(164).call(this.frame_574).wait(87).call(this.frame_661).wait(87).call(this.frame_748).wait(23).call(this.frame_771).wait(46).call(this.frame_817).wait(35).call(this.frame_852).wait(1));

	// control pad
	this.instance = new lib.harconsoleControlShadow("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(366.6,621,1,1,-0.8);
	this.instance.alpha = 0.301;

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFD445").s().p("AgtDGQgpgNghgfQgigfgXgrQgYgsgMgzQAVBAApAvQApAvA1ASQAcAJAagBQAwgBAqgcQAqgdAdgzQAdgzAKhEQALhLgRhIQAOArAFAvQAFAvgHAwQgKBDgdAzQgdAzgqAdQgpAcgxACIgDAAQgZAAgagJg");
	this.shape.setTransform(512.2,600.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D49100").s().p("AjYB1QgBgeAEgeIABgEIAAgDIACgSQAOg9AcguQAdguAogaQAogaAugCIACAAIABAAQAWABAXAGIAGACIACABIABAAQABAAAAAAQAAABAAAAQABAAAAAAQAAAAAAAAIABAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAIADABIAFADIADABIACABIABAAQAEADADABIADACIALAGIAMAJQAKAGAJAJIACACIACACIAAABIACAAIAAABQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAIABAAIABACQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAIABABIABABIABABIACACIABABIABABQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAIABACQAiApAVA1QAVA1AEA8QgJg5gYgwQgYgvgjgjQgjgigsgOQgbgLgaABQgxABgpAdQgrAdgdAzQgdAygLBEQgFArACAqQgDgdgBgeg");
	this.shape_1.setTransform(511.6,579.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F1A500").s().p("AgqEPQgsgPgjgiQgjgigYgwQgYgwgKg5IAAgCQgCgoAEgrQALhFAdgyQAeg0ApgcQAqgdAxgBQAagBAbAKQAtAPAjAiQAjAiAYAxQAXAwAKA5IAAgEQADArgGAuQgKBEgdAzQgdAzgqAdQgqAcgxACIgCAAQgZAAgagKg");
	this.shape_2.setTransform(511.9,593.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFD445").s().p("AAGDfQgqgEgogXQgngVghglQghglgYgxQAlA7AyAlQAyAkA4AGIAQABQA6gDAsgkQArgjAVg9QAWg9gHhNQgDgngKgjQgKgjgQggQAXAlAQAtQAPAtAFAvQAGBNgWA+QgVA9gsAkQgrAjg6ACIgRgBg");
	this.shape_3.setTransform(401.2,605.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D49100").s().p("AjOCDIgBgDIAAgCIgBgCIAAgCIAAgBIgBgDIAAgBQgDgTgCgWQgCgOAAgOQgBhEAXg3QAXg2AoggQApghA2gBIADAAIAOgBIADAAQAAABAAAAQABAAAAAAQAAAAABAAQAAAAABAAIADAAQAAAAAAAAQABAAAAAAQAAABAAAAQABAAAAAAIAEAAQAAAAAAAAQABAAAAAAQAAABAAAAQABAAAAAAIABAAIABAAIABAAIACABIABAAIACAAIAGACIACAAIABABIACAAIABAAQAAAAAAAAQAAABABAAQAAAAAAAAQAAAAABAAIAGACIACABIABAAIACABIABAAIACABQAAAAAAAAQABABAAAAQAAAAABAAQAAAAABAAIADABIAAABIACAAIABABIACAAQAAAAAAAAQAAABAAAAQAAAAABAAQAAgBAAAAIABABIACABIABAAIACABIABABIABAAIABABIACAAQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAIAEIAAABQA0AdAnA1QAnA0AVBCQgWg0gigqQgigqgrgZQgqgZgtgFIgSgBQg6ACgrAkQgrAkgVA9QgWA9AGBNQAFAsAMAoQgNgfgIgjg");
	this.shape_4.setTransform(398.3,589.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#F1A500").s().p("AAUESQgugEgqgaQgrgagigrQgigpgVg0QgMgogFgqQgHhOAWg9QAWg9ArglQArgkA6gBIASABQAtAEAqAZQAqAaAiAqQAiApAXA2QAMAoAFAqQAGBOgWA9QgVA9grAlQgrAkg6ABIgSgBgACCjWIgNgQIAOAQIAMAQIgNgQg");
	this.shape_5.setTransform(399.9,600.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFD445").s().p("AgbDQQgqgLgjgbQgkgdgbgqQgbgpgQgzQAbBAAsArQArArA4AOQAVAGAUAAQA0gBAqggQArgfAbg3QAag2AFhHQAFhNgXhFQASAqAIAtQAJAvgDAwQgFBHgbA3QgbA3grAfQgqAfg0ACQgTAAgWgGg");
	this.shape_6.setTransform(456.1,601.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D49100").s().p("AjYBdIAAgFIAAgDIgBAAIAAgDIAAgGIAAgBIAAgCIAAgDIAAgCIABgBIAAgCIAAgFQAFhFAag2QAbg2ApgfQApgfAzgDIAFgBIABAAQAPABAOACIAGABIAFABIACABIABAAIACABIABAAIACAAIABABIACAAIADABIACABIABABIACAAIABABIABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAABAAAAIACgBIABACQAAgBAAAAQABAAAAABQAAAAAAAAQABAAAAABIABAAIACABIABAAIABABIABAAIACABIABAAIABAAIACABIABABIACABIABAAIABACIABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABABAAAAQAmAVAfAlQAfAkAVAvQAVAuAIA3QgPg5gbgtQgcguglggQgmgfgtgMQgVgFgUAAQg0ACgqAfQgrAfgbA2QgaA2gFBHQgDAtAHApQgMgtAAgug");
	this.shape_7.setTransform(454.9,581.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F1A500").s().p("AgVESQg4gOgsgsQgsgsgbhAQgQgngIgsIAGAZQgHgpADgrQAFhHAag3QAbg2ArgfQAqgfA0gCQAUAAAVAFQAtALAmAgQAlAgAcAuQAbAuAPA4QgEgWgFgVQAGAVADAVQAHAqgDArQgFBIgbA3QgbA2gqAgQgrAfg0ABQgUAAgVgFgACOjdIgOgRIAOARIAIALIgIgLg");
	this.shape_8.setTransform(455.5,595.2);

	this.instance_1 = new lib.harconsoleControlHighlight("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(347.7,544,1,1,-0.8);
	this.instance_1.alpha = 0.852;

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#ED9900").s().p("A4nAdQgRgrASgeQARgeAugUQAtgTBDgNIBngUQBQgPCBgWQCBgVCogVQCpgVDHgPQDHgPDdgEQDcgCDHAJQDIAKCpAQQCpAQCBASQCCARBRAOIBnARQBDAKAuATQAuASASAdQASAegQAsIhSD0QAYhPgDg5QgDhAgegnQgegpg0gWQgzgWhDgJIjrgiQiEgTiigRQihgRi+gKQi9gKjXACQjYAEi9APQi9AQihAWQihAViFAXIjqApQhCAKgzAYQgyAXgdAoQgdApgBBBQgBA8AdBWg");
	this.shape_9.setTransform(506.5,569.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#FFD238","#F78600"],[0,1],-1.1,-66.4,0.3,32.4).s().p("A0VHrQgZgMgQghIjpp+QgRgsASgeQARgeAugTQAtgUBDgMIBngUQBQgQCBgVQCBgVCogVQCpgVDHgPQDHgPDdgEQDcgDDHAKQDIAJCpAQQCpARCBARQCCASBRANIBnARQBDALAuASQAuASASAeQASAdgQAtIjXKEQgPAhgYANQgYANggAAQgcAAgggEQgggGgkgDIhegKQhFgHhpgIQhqgIiHgHQiHgHicgEQiegEirADQirACidAJQidAIiGALQiHAKhpAMQhqALhFAIIheANQgjAEggAGQggAGgcABIgFAAQgcAAgXgMg");
	this.shape_10.setTransform(506.5,591.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.instance_1},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(853));

	// movie
	this.instance_2 = new lib.HM_mchelpMC("synched",0,false);
	this.instance_2.parent = this;
	this.instance_2.setTransform(509.3,322.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(853));

	// red strip
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E5212D").s().p("Egu1ABbIAAi0MBdrAAAIAAC0g");
	this.shape_11.setTransform(508.2,106.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(853));

	// bg
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#666633").ss(1,1,1).p("EAu4gjJMAAABGTMhdvAAAMAAAhGTg");
	this.shape_12.setTransform(508.5,322.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFCC").s().p("Egu3AjKMAAAhGTMBdvAAAMAAABGTg");
	this.shape_13.setTransform(508.5,322.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12}]}).wait(853));

	// Layer 2
	this.instance_3 = new lib.harcontrolpanelshadow("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(512.5,598.9,0.974,0.974,-1.5);
	this.instance_3.alpha = 0.371;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(853));

	// background
	this.text = new cjs.Text("Make 5", "28px 'HeinemannRoman'");
	this.text.textAlign = "center";
	this.text.lineHeight = 37;
	this.text.lineWidth = 146;
	this.text.parent = this;
	this.text.setTransform(510.7,254.3,0.75,0.75);

	this.instance_4 = new lib.harscreenshadow("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(518.5,332.2);
	this.instance_4.alpha = 0.371;

	this.instance_5 = new lib.harbkgframe("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(158,526.8);
	this.instance_5.alpha = 0.25;

	this.instance_6 = new lib.harbackgroundpanel("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(112,54.2,1,0.92);
	this.instance_6.alpha = 0.25;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.text}]}).wait(853));

	// white back
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("Eg+fAu4MAAAhdvMB8/AAAMAAABdvg");
	this.shape_14.setTransform(512,359.9);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(853));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(511.3,330.5,1025.4,659.4);




// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['05319796B0AED94DA79FB1F282F10C70'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}

// library properties:
lib.properties = {
	id: '05319796B0AED94DA79FB1F282F10C70',
	width: 1024,
	height: 660,
	fps: 12,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:audioUrl["help/HM_Generic_HM_NarSound1.mp3"], id:"HM_Generic_HM_NarSound1"},
		{src:audioUrl["help/HM_Generic_HM_NarSound2.mp3"], id:"HM_Generic_HM_NarSound2"},
		{src:audioUrl["help/HM_Generic_HM_NarSound3.mp3"], id:"HM_Generic_HM_NarSound3"},
		{src:audioUrl["help/HM_MysteryNo_nodecimal_ATT1_HM_NarSound1.mp3"], id:"HM_MysteryNo_nodecimal_ATT1_HM_NarSound1"},
		{src:audioUrl["help/HM_MysteryNo_nodecimal_ATT1_HM_NarSound2.mp3"], id:"HM_MysteryNo_nodecimal_ATT1_HM_NarSound2"},
		{src:audioUrl["help/HM_MysteryNo_nodecimal_ATT1_HM_NarSound3.mp3"], id:"HM_MysteryNo_nodecimal_ATT1_HM_NarSound3"},
		{src:audioUrl["help/HM_MysteryNo_nodecimal_ATT1_HM_NarSound4.mp3"], id:"HM_MysteryNo_nodecimal_ATT1_HM_NarSound4"},
		{src:audioUrl["help/HM_MysteryNo_nodecimal_ATT1_HM_NarSound5.mp3"], id:"HM_MysteryNo_nodecimal_ATT1_HM_NarSound5"},
		{src:audioUrl["help/HM_MysteryNo_nodecimal_ATT1_HM_NarSound6.mp3"], id:"HM_MysteryNo_nodecimal_ATT1_HM_NarSound6"},
		{src:audioUrl["help/HM_MysteryNo_nodecimal_ATT1_HM_NarSound7.mp3"], id:"HM_MysteryNo_nodecimal_ATT1_HM_NarSound7"},
		{src:audioUrl["help/HM_MysteryNo_nodecimal_ATT1_HM_NarSound8.mp3"], id:"HM_MysteryNo_nodecimal_ATT1_HM_NarSound8"}
	],
	preloads: []
};
console.log(audioUrl)

})(lib = window.lib||{}, images = window.images||{}, createjs = window.createjs||{}, ss = window.ss||{}, AdobeAn = window.AdobeAn||{});


var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;
function init() {
	initButtons('hidden');
	canvas = document.getElementById("canvas");
	anim_container = document.getElementById("animation_container");
	dom_overlay_container = document.getElementById("dom_overlay_container");	
	try {
	
		var comp=AdobeAn.getComposition("05319796B0AED94DA79FB1F282F10C70");
	} catch (e) {
		
		setTimeout(function() {init();}, 100);
		return;
	} finally {
	}
	var lib=comp.getLibrary();
	try {
		var loader = new createjs.LoadQueue(false);
		console.log(lib);
		loader.installPlugin(createjs.Sound);
	    loader.addEventListener("complete", function(evt){handleComplete(evt,comp)});
	    loader.loadManifest(lib.properties.manifest);
	} catch (e) {
		setTimeout(function() {init();}, 100);
		return;
	} finally {
	}
	
}
window.init= init;
function handleComplete(evt,comp) {
	//This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
	$("#helpInst").hide();
	var lib=comp.getLibrary();
	var ss=comp.getSpriteSheet();
	var queue = evt.target;
	var ssMetadata = lib.ssMetadata;
	for(i=0; i<ssMetadata.length; i++) {
		ss[ssMetadata[i].name] = new createjs.SpriteSheet( {"images": [queue.getResult(ssMetadata[i].name)], "frames": ssMetadata[i].frames} )
	}
	exportRoot = new lib.sl69challengehelpview();
	stage = new lib.Stage(canvas);	
	//Registers the "tick" event listener.
	fnStartAnimation = function() {
		stage.addChild(exportRoot);
		createjs.Ticker.setFPS(lib.properties.fps);
		createjs.Ticker.addEventListener("tick", stage);
	}	    
	//Code to support hidpi screens and responsive scaling.
	function makeResponsive(isResp, respDim, isScale, scaleType) {		
		var lastW, lastH, lastS=1;		
		window.addEventListener('resize', resizeCanvas);		
		resizeCanvas();		
		function resizeCanvas() {			
			var w = lib.properties.width, h = lib.properties.height;			
			var iw = window.innerWidth, ih=window.innerHeight;			
			var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
			if(isResp) {                
				if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
					sRatio = lastS;                
				}				
				else if(!isScale) {					
					if(iw<w || ih<h)						
						sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==1) {					
					sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==2) {					
					sRatio = Math.max(xRatio, yRatio);				
				}			
			}			
			canvas.width = w*pRatio*sRatio;			
			canvas.height = h*pRatio*sRatio;
			canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  w*sRatio+'px';				
			canvas.style.height = anim_container.style.height = dom_overlay_container.style.height = h*sRatio+'px';
			stage.scaleX = pRatio*sRatio;			
			stage.scaleY = pRatio*sRatio;			
			lastW = iw; lastH = ih; lastS = sRatio;            
			stage.tickOnUpdate = false;            
			stage.update();            
			stage.tickOnUpdate = true;		
		}
	}
	makeResponsive(false,'both',false,1);	
	AdobeAn.compositionLoaded(lib.properties.id);
	fnStartAnimation();
}
function playSound(id, loop, pos) {
	pos = (pos) ? pos : 0;
	currSound = id;
	return createjs.Sound.play(id, createjs.Sound.INTERRUPT_EARLY, 0, pos, loop);
}
window.playSound = playSound;
var chapterFrames = [
	{start: 1, end: 148},
	{start: 149, end: 326},
	{start: 327, end: 563},
	{start: 564, end: 742},
	{start: 743, end: 853}
];
window.chapterFrames = chapterFrames;
function stopAtEnd() {
	currPos = 0;
	currSound = "";
	canvasTimeLine.gotoAndStop(0);
	$("#prev").attr("disabled", true);
	$("#next").attr("disabled", true);
	$("#next").find("img").attr('src', "../assets/images/help/forward_btn_inactive.png");
	$("#prev").find("img").attr('src', "../assets/images/help/replay_btn_inactive.png");
	$("#prev").removeClass("enabled");
	$("#next").removeClass("enabled");
	//$("#pause").hide();
	//$("#play").show();
	$("#pause").css('opacity',0);
	$("#play").css('opacity',1);
	$("#pause").css('pointer-events','none');
	$("#play").css('pointer-events','auto');
}
function loadCompleted() {
	$(".loader").hide();
	//$(".button-set").css("display", "block");
}
function initButtons(val){
	var prevEle = document.getElementById("prev").style.visibility = val;
	var nextEle = document.getElementById("next").style.visibility = val;
	var pauseEle = document.getElementById("pause").style.visibility = val;
	var playEle = document.getElementById("play").style.visibility = val;
	var helpInstEle = document.getElementById("helpInst").style.visibility = val;
	


}
initButtons('hidden');
window.initButtons = initButtons;
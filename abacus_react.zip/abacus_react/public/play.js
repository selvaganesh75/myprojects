alert();
import $ from "jquery";
import {audioUrl} from '../../../preload.js';

var frSound, currSound,  isPrevDoubleClicked,isNextDoubleClicked,canvasTimeLine,chapterFrames,playSound,currPos = 0;
canvasTimeLine = window.canvasTimeLine;
$(document).ready(function() {
	var ishelpDevice;
		ishelpDevice = (navigator.userAgent.indexOf("iPad") != -1 || navigator.userAgent.indexOf("Android") != -1 || navigator.userAgent.indexOf("Macintosh") != -1) ? true : false;
	//alert(ishelpDevice)
	function addDeviceClass(){
		if(ishelpDevice){
			$('.page').addClass('helpdevice')
		}
	}
	addDeviceClass();
	//chapterFrames
	var audioElement = document.createElement('audio');
    audioElement.setAttribute('src', audioUrl['button-click.mp3']);
	var audioElement1 = document.createElement('audio');
    audioElement1.setAttribute('src', audioUrl['button-click.mp3']);
	var touchtime = 0;
	$("#prev").attr("disabled", true);
	$("#next").attr("disabled", true);
	//$("#pause").hide();
	$("#pause").css('opacity',0);
	$("#pause").css('pointer-events','none');

	$("body").on("click",'#pause', function() {
		canvasTimeLine = window.canvasTimeLine;
		audioElement.play();
		//$("#pause").hide();
		//$("#play").show();
		$("#pause").css('opacity',0);
		$("#pause").attr('tabindex',-1);
		$("#play").attr('tabindex',0);
		$("#pause").css('pointer-events','none');
		$("#play").css('opacity',1).focus();
		$("#play").css('pointer-events','auto');
		$("#play").find("img").attr('src', "../assets/images/help/play_btn_up.png");
		frSound = window.frSound;
		console.log(frSound);
		currPos = frSound.position;
		canvasTimeLine.stop();
		frSound.stop();
	});

	$("#play").on("click", function() {
		canvasTimeLine = window.canvasTimeLine;
		console.log(canvasTimeLine,window);
		
		$("#video-alert").html('<span class="sr-only">The alternate of video is provided within help-keyboard instructions</span>');
		audioElement.play();
		$("#prev").attr("disabled", false);
		$("#prev").addClass("enabled");
		$("#next").attr("disabled", false);
		$("#next").addClass("enabled");
		$("#pause").attr('tabindex',0);
		$("#play").attr('tabindex',-1);
		$("#next").find("img").attr('src', "../assets/images/help/forward_btn_up.png");
		$("#prev").find("img").attr('src', "../assets/images/help/replay_btn_up.png");
		if (canvasTimeLine.currentFrame >= canvasTimeLine.totalFrames-1) {
			canvasTimeLine.gotoAndPlay(1);
		} else {
			canvasTimeLine.play();
		}
		$("#pause").find("img").attr('src', "../assets/images/help/pause_btn_up.png");
		//$("#pause").show();
		//$("#play").hide();
		$("#pause").css('opacity',1);
		$("#pause").css('pointer-events','auto');
		$("#play").css('opacity',0);
		$("#play").css('pointer-events','none');
		frSound = window.frSound;
		playSound = window.playSound;
		if(currPos != 0) {
			frSound = playSound(currSound, 0, currPos);
		}
		prevChapter = false;
		$("#pause").focus();
	});
	$("#pause").find("img").attr('src', "../assets/images/help/pause_btn_up.png");
		$("#pause").on('mouseenter',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/pause_btn_over.png");
			}).on('mouseleave',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/pause_btn_up.png");
			}).on('mousedown',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/pause_btn_down.png");
			});

		$("#play").find("img").attr('src', "../assets/images/help/play_btn_up.png");
		$("#play").on('mouseenter',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/play_btn_over.png");
			}).on('mouseleave',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/play_btn_up.png");
			}).on('mousedown',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/play_btn_down.png");
			});



		$("#next").find("img").attr('src', "../assets/images/help/forward_btn_inactive.png");
		$("#next").on('mouseenter',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/forward_btn_over.png");
			}).on('mouseleave',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/forward_btn_up.png");
			}).on('mousedown',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/forward_btn_down.png");
			});

		$("#prev").find("img").attr('src', "../assets/images/help/replay_btn_inactive.png");
		$("#prev").on('mouseenter',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/replay_btn_over.png");
			}).on('mouseleave',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/replay_btn_up.png");
			}).on('mousedown',function() {
					var elem = $(this).find("img")[0];
					$(elem).attr('src', "../assets/images/help/replay_btn_down.png");
			});
	function singleClick(){
		//audioElement.play();
		setTimeout(function() {
			if(!isPrevDoubleClicked) {
				//$("#pause").show();
				//$("#play").hide();
				$("#pause").css('opacity',1);
				$("#play").css('opacity',0);
				$("#pause").attr('tabindex',0);
				$("#play").attr('tabindex',-1);
				$("#pause").css('pointer-events','auto');
				$("#play").css('pointer-events','none');
				frSound = window.frSound;
				frSound.stop();
			gotoChapter(getChapter());
			prevChapter = false;
			}
		}, 500);

	}


	function doubleClick(){
		isPrevDoubleClicked = true;
		setTimeout(function() {
			isPrevDoubleClicked = false;
		}, 600);
		//$("#pause").show();
		//$("#play").hide();
		$("#pause").css('opacity',1);
		$("#play").css('opacity',0);
		$("#pause").attr('tabindex',0);
		$("#play").attr('tabindex',-1);
		$("#pause").css('pointer-events','auto');
		$("#play").css('pointer-events','none');
		frSound = window.frSound;
		frSound.stop();
		var i = getChapter();
		if(i >= 1) {i--;}
		gotoChapter(i);
		prevChapter = false;
	}

    var prevChapter = false;
	function nextSingleClick(){
		//audioElement.play();
		setTimeout(function() {
			if(!isNextDoubleClicked) {
				//$("#pause").show();
				//$("#play").hide();
				$("#pause").css('opacity',1);
				$("#play").css('opacity',0);
				$("#pause").attr('tabindex',0);
				$("#play").attr('tabindex',-1);
				$("#pause").css('pointer-events','auto');
				$("#play").css('pointer-events','none');
				var chap = getChapter()+1;
				/*Added*/				
				frSound = window.frSound;
				console.log(window);
	                if(!prevChapter) {
					  frSound.stop();	
	                  console.log("Chapter" + chap);				
					  gotoChapter(chap);				  
					}
					if(chap == chapterFrames.length-1) {prevChapter = true;}
                /*Added*/	
			}
		}, 500);

	}


	function nextDoubleClick(){
		isNextDoubleClicked = true;
		setTimeout(function() {
			isNextDoubleClicked = false;
		}, 600);
		//$("#pause").show();
		//$("#play").hide();
		$("#pause").css('opacity',1);
		$("#play").css('opacity',0);
		$("#pause").css('pointer-events','auto');
		$("#play").css('pointer-events','none');
		var i = getChapter();
		frSound = window.frSound;
		if(i > 1) {i--;}
		var chap = i+2;
		// if(i >= 1) {i++;}
		/*Added*/
			if(!prevChapter) {
				
			     frSound.stop();	
	             //console.log(prevChapter);				
				 gotoChapter(chap);				  
		     }
			if(chap == chapterFrames.length-1) {prevChapter = true;}	
		/*Added*/
	}

	$("body").on("mousedown touchstart", "*", function(e) {
		if (($(this).is(":focus") || $(this).is(e.target)) && $(this).css("outline-style") == "none") {
			$(this).css("outline", "none").on("blur", function() {
				$(this).off("blur").css("outline", "");
			});
		}
	});
	$("#prev").on("click", function() {
	    if (touchtime == 0) {
		    audioElement.play();
	        singleClick()
	        touchtime = new Date().getTime();
	    } else {
	        // compare first click to this click and see if they occurred within double click threshold
	        if (((new Date().getTime()) - touchtime) < 800) {
	            // double click occurred
			   audioElement1.play();
			   setTimeout(function(){ audioElement.play();}, 200);
				doubleClick();
	            touchtime = 0;
	        } else {
	            // not a double click so set as a new first click
				audioElement.play();
				singleClick()
	            touchtime = new Date().getTime();
	        }
	    }
	});

	$("#next").on("click", function() {
		// audioElement.play();
		// $("#pause").show();
		// $("#play").hide();
		// var chap = getChapter()+1;
		// if(chap < chapterFrames.length) {
		// 	frSound.stop();
		// 	gotoChapter(chap);
		// }
		if (touchtime == 0) {
			audioElement.play();
				nextSingleClick();
				touchtime = new Date().getTime();
		} else {
				// compare first click to this click and see if they occurred within double click threshold
				if (((new Date().getTime()) - touchtime) < 800) {
						// double click occurred
			 audioElement1.play();
			 setTimeout(function(){ audioElement.play();}, 200);
			nextDoubleClick();
						touchtime = 0;
				} else {
						// not a double click so set as a new first click
			audioElement.play();
			nextSingleClick();
						touchtime = new Date().getTime();
				}
		}
	});

	function gotoChapter(n) {
		try {
			canvasTimeLine.gotoAndPlay(chapterFrames[n].start);
		} catch (e) {	}
	}

	function getChapter() {
		chapterFrames = window.chapterFrames;
		for (var i = 0; i < chapterFrames.length; i++) {
			if (canvasTimeLine.currentFrame > chapterFrames[i].start && canvasTimeLine.currentFrame < chapterFrames[i].end) {
				return i;
			}
		}
	}

/******************************************************************/
	var shifted;
	var keyPressed;
	$(document).on('keyup keydown', function(e) {
		shifted = e.shiftKey;
		keyPressed = e.keyCode;
		setTimeout(function(){
			keyPressed = "";
		},100);
	});

	$(".help-clicked").hide();
	$(".help_button").on("click", function(e) {
		audioElement.play();
		//$(".page").attr("aria-hidden", true);
		$(".dis-ass").attr("aria-hidden", true);
		$(".dis-ass").attr("tabindex",-1);
		var instContEle = document.getElementById("instCont").style.visibility = "visible";
		document.getElementById("game-btn").style.visibility = "hidden";
		document.getElementById("rootCloseBtn").setAttribute("aria-hidden", true);
		document.getElementById("rootCloseBtn").setAttribute("tabindex", -1);
		$(".help-clicked").show();
		$("#game-button").css("display","block");
		if(keyPressed) {
			setTimeout(function(){
				$("#helpbox").focus();
			},100);

		}
	});

$(".help-box").on('blur',function(e){
	if(shifted) {
		$(".no_btn").focus();
	}})

var mouseClicked=true;
$(".no_btn").on("mousedown",function(){
	mouseClicked=false;
});

$(".no_btn").on("click",function(event){
	audioElement.play();
	//$(".page").attr("aria-hidden", false);
	$(".dis-ass").attr("aria-hidden", false);
	var instContEle = document.getElementById("instCont").style.visibility = "hidden";
	window.parent.document.getElementById("game-btn").style.visibility = "visible";
	$(".dis-ass").attr("tabindex",0);
	window.parent.document.getElementById("rootCloseBtn").setAttribute("aria-hidden", false);
	window.parent.document.getElementById("rootCloseBtn").setAttribute("tabindex", 0);
	$("#game-button").css("display","none");
	$(".help-clicked").hide();
	// $(this).css("outline", "none");
	// $(this).find('span').css("outline", "none");
	if(mouseClicked){
		$(".help_button").focus();
	}

	mouseClicked = true;

});
    
});
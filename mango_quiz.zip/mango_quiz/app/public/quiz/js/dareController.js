var dareController = function()
{
	var scope = this;
	scope.data = [];
	scope.imgPath = "images/";
	scope.questionIndex = 0;
	scope.init = function(data)
	{
		scope.data = data.DareDataSent;
		scope.resultData = data.dareDataRecieved;
		scope.result = [];	
		$('#maincontent').html("");
		scope.loadContent();	
	}
	scope.loadContent = function()
	{
		if(scope.questionIndex != scope.data.length)
		{
			$('#maincontent').html("");
				$('#maincontent').append("<div class='questions'><h1 id='question_id'>"+scope.data[scope.questionIndex].question+"</h1><div class='options' id='optionContainer' class='options'></div>");
				scope.data[scope.questionIndex].option.forEach(function(option,optionIndex)
				{
					$('#optionContainer').append("<img src='"+scope.imgPath+option+".jpg' data-value='"+scope.data[scope.questionIndex].alt[optionIndex]+"' class='img optionsImg'></img></div>");
				});
				scope.questionIndex++;
				scope.bindEvents();
		}
		else
		{
			$('#maincontent').html("");
		}
	}
	scope.bindEvents = function()
	{
		$('.optionsImg').unbind('click').bind('click',scope.generateValue);
	}
	scope.generateValue = function()
	{
		$('.optionsImg').unbind('click');
		if(scope.resultData.length == 0)
		scope.createData(this);
		else
		scope.compareData(this);

		scope.navigate();
	}
	scope.createData = function(ele)
	{
		$(ele).css('background','green');
		if(scope.result.indexOf($(ele).data('value') == -1))
		scope.result.push($(ele).data('value'))	
	}
	scope.compareData = function(ele)
	{
		var color = "";
		for(var i=0;i<scope.resultData.length;i++)
		{
			
			if(scope.resultData[i] == $(ele).data('value'))
			color = "green";
			else
			{	
			if(color != "green")
				color = "red";
			}
		}
		$(ele).css('background',color);
	}
	scope.navigate = function()
	{
		console.log(scope.result);
		setTimeout(function(){
			$('#maincontent').html("");
			scope.loadContent();},1000);
			
		}
		
}
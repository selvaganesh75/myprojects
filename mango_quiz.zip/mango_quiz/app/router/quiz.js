var router = require('express').Router();
var AM = require('../modules/account-manager');
var json = require('../public/assets/data/configuration.json');

router.get('/',function(req,res){
    console.log('---->',req.cookies.guessUser)
    if(req.cookies.guessUser == undefined){

        res.render('quiz');

    }else{    
        AM.validateLoginKey(req.cookies.guessUser, req.ip, function(e,o){
            if(o){
                res.redirect('/quiz/'+o.userId);
            }else{
                //user login page
                res.render('quiz');
            }

        })
    }
    
});


router.post('/',function(req,res){
    var o = {};
    o.user = req.body['uname'];
    o.ip = req.ip;
   
    if(req.cookies.guessUser == req.session.guessUser){
        res.redirect('/quiz/'+req.cookies.userId);
    }else{
        AM.addNewAccount(o, function(o,key){
            req.session.guessUser = key;
            res.cookie('guessUser', key, { maxAge: 900000 });
            res.cookie('userId', o.userId, { maxAge: 900000 });
            res.redirect('/quiz/'+o.userId);
    
        });
    }
    
   
});

router.get('/:id',function(req,res){
   
    console.log('sending',req.params.id);
    AM.getUserData(req.params.id, function(e,o){
        if(e) throw e;
        console.log('after',o);
        
        if(o){
            if(o.cookie == req.cookies.guessUser){
                if(o.questions && o.questions.length){
                    res.send(o)
                    // render output screen 
                }else{
                    res.send(o)
                // render make questions page.
                }
            }else{
                res.send(o);
                // render answer page.
            }
            
        }else{
            res.clearCookie('guessUser');
            res.render('quiz');
        }

        

    })
    
  
   
});

router.post('/get_question',function(req,res){
    res.send(res)
})

router.post('/answer_question',function(req,res){
    res.send(res);
})

module.exports = router;
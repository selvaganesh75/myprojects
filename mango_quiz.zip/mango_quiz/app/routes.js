var AM = require('./modules/account-manager');
var quiz = require('./router/quiz');
module.exports = function(app) {
    app.get('/',function(req,res){

        if(req.cookies.guessUser == null){
            //res.cookie('guessUser', "selva", { maxAge: 900000 });
            res.render('quiz');

        }else{
            res.send("its working");
        }
    });
    app.use('/quiz',quiz)
    app.get('/home',function(req,res){
        res.send("home loaded");
    })

}
var Resume = function(data) {
    var self = this;
    this.$ = function(ele) {
        return document.querySelector(ele);
    }
    this.cls = function(ele) {
        return document.getElementsByClassName(ele);
    }
    this.showDetail = function(index) {
        switch (index) {
            case 0:
                new profile(data.profile, data);
                break;
            case 1:
                new resume(data.Resume, data);
                break;
            case 2:
                new skills(data.Skills, data);
                break;
            case 3:
                new contact(data.Contact, data);
                break;
        }

    }
    this.closeprofile = function() {
        self.$('.intro_left').style.right = '0%';
        self.$('.menuScreen').style.left = '0%';
        setTimeout(function(e) {
            self.$('.screen').style.opacity = 0;
            self.$('.close').style.opacity = 0;

        }, 20);
        self.$('.data_container').style.zIndex = 0;
    }

    this.openprofile = function() {
        self.$('.intro_left').style.right = '100%';
        self.$('.menuScreen').style.left = '100%';
        setTimeout(function(e) {
            self.$('.screen').style.opacity = 1;
            self.$('.close').style.opacity = 1;

        }, 50);

        self.$('.data_container').style.zIndex = 15;
        self.$('.close').style.zIndex = 20;


    }


    this.canvas = function(bg) {
        function draw(ctx, value) {

            let self = this;
            this.h = ctx.canvas.height;
            this.w = ctx.canvas.width;
            this.count = 0;
            this.end = value;
            ctx.clearRect(0, 0, this.w, this.h);
            ctx.textAlign = 'center';
            ctx.textBaseline = "middle";
            ctx.strokeStyle = bg.color;
            ctx.font = '20px Florence';
            ctx.lineWidth = '7';
            ctx.lineCap = 'round';
            this.loop = function() {
                if (self.count <= self.end) {

                    ctx.clearRect(0, 0, self.w, self.h);
                    ctx.save();
                    ctx.lineWidth = '10';
                    ctx.strokeStyle = '#c6c6c6';
                    ctx.beginPath();
                    ctx.arc(self.w / 2, self.h / 2, self.h / 2.2, 0, 6.28);
                    ctx.stroke();
                    ctx.closePath();
                    ctx.restore();
                    ctx.beginPath();
                    ctx.fillText("" + self.count + "%", self.w / 2, self.h / 2);

                    ctx.arc(self.w / 2, self.h / 2, self.h / 2.2, 1.5 * Math.PI, 1.5 * Math.PI + (0.0628 * self.count));
                    ctx.stroke();
                    self.count++;
                    setTimeout(self.loop, 1000 / 60);
                }

            }
            self.loop();
        };
        for (let i = 0; i < self.cls('canvas').length; i++) {
            let indx = i;
            let id = self.$('#canvas_' + indx).getContext('2d');
            let value = self.$('#canvas_' + indx).dataset.max;
            new draw(id, value);
        }

    }


    this.listener = function() {
        for (let i = 0; i < this.cls('menu').length; i++) {
            this.cls('overlay')[i].addEventListener('click', this.showDetail.bind(null, i));
        }
        self.$('.close').addEventListener('click', this.closeprofile);
    }
    this.background = function() {
        color(data);
    }

};

(function() {
    makeRequest({
            method: 'GET',
            url: '/data',
            headers: {
                "Content-Type": "text/json",
                "Access-Control-Allow-Origin": "*"
            }

        })
        .then(function(data) {
            var main = new Resume(JSON.parse(data));
            main.listener();
            main.background();
        })
        .catch(function(err) {
            console.log(err);
		});

})();
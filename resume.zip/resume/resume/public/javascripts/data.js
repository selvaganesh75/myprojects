function getClass(ele){
	return document.getElementsByClassName(ele);
}
function getId(ele){
	return document.getElementById(ele);
}

function ajax(method,url){
	return makeRequest({
				method: method,
				url:url,
				headers:{
					"Content-Type": "text/html",
					"Access-Control-Allow-Origin":"*"
				}
			
			})
		.then(function (data) {
			//var main = new about(JSON.parse(data));	
			//main.listener();
			return data;
		})
		.catch(function (err) {
			console.log(err);
			//id("PageNtfnd").style.display="block";
		});
}

var color = function(data){
		Object.values(getClass('textClr')).forEach(function(v, i){v.style.color=data.backgroundStyle.color});
		Object.values(getClass('bgClr')).forEach(function(v, i){v.style.backgroundColor=data.backgroundStyle.backgroundColor})
		Object.values(getClass('borderClr')).forEach(function(v, i){v.style.borderColor=data.backgroundStyle.color})
		document.styleSheets[1].addRule('.bgClr::before','border-color: '+data.backgroundStyle.backgroundColor,1);
		
		document.styleSheets[1].insertRule('.bgClr::before { border-color:'+data.backgroundStyle.backgroundColor+'}', 1);
		document.styleSheets[1].insertRule('.bgClr_h3::before{border-right-color:'+data.backgroundStyle.backgroundColor+'}', 1);
		document.styleSheets[1].insertRule('.overlay:hover .nav i{color:'+data.backgroundStyle.color+'!important}', 1);
		document.styleSheets[1].insertRule('.contact>button:hover,.dl:hover, .contact>button:focus{background-color:'+data.backgroundStyle.backgroundColor+'!important;color:#fff!important}', 1);
		document.styleSheets[1].insertRule('.contact>[type=text]:hover,.top_div::after,.bottom_div::after ,.contact>[type=text]:focus{box-shadow:0 0 3px 0'+data.backgroundStyle.color+'!important}', 1);
		
		
}
function profile(data,bg){
	let container = '<h4 class="txt">'+data[1].content+'</h4>';
	let container_1;
	container += '<a class="borderClr dl textClr" href="./document/resume.pdf" download>Download</a><a class="borderClr dl textClr" target="blank" href="./document/resume.pdf">View my CV</a>';
	let resume = new Resume(bg);
	console.log(resume)
	Object.keys(data[0]).forEach(function(val,key,arr){
		container_1 += '<div class="left_ques"><h4 class="textClr">'+val+'</h4></div><div class="right_ques"><h4 class="textClr">'+data[0][val]+'</h4></div>';
	});
	Promise.resolve(ajax('GET','./pages/profile.html')).then(function(val){
		getClass('data_container')[0].innerHTML = val;
		getId('profileImage').src = '/images/'+data[2].image;
		getId('profile').innerHTML = container;
		//getId('profile1').innerHTML = container_1;
		resume.openprofile();
		color(bg);
		function translate(){
			getClass('move')[0].style.opacity=1;
			getId('profileImage').style.opacity=1;
			getId('profile').classList.add('translate') ;
			getClass('intro_left')[0].removeEventListener('transitionend',translate);
		}
		getClass('intro_left')[0].addEventListener('transitionend',translate);
			
		
	});
}


function resume(data,bg){
	let container = '<h1 class="textClr">'+data.Education.heading+'</h1>';
	let container_1 = ' <h1>'+data.Experience.heading+'</h1>';
	let resume = new Resume(bg);
	Object.values(data.Education.content).forEach(function(val,key,arr){
		container += '<div class="education container borderClr"><div class="circleDraw bgClr"></div><div class="education_content"><div class="education_detail"><h3 class="bgClr bgClr_h3 edu_bg">'+val.heading+'</h3><p>'+val.content+'</p></div></div></div>';
	})
	Object.values(data.Experience.content).forEach(function(val,key,arr){
		container_1 += '<div class="education container"><div class="circleDraw borderClr"></div><div class="education_content"><div class="education_detail"><h3 class="textClr exp_bg">'+val.heading+'</h3><p>'+val.content+'</p></div></div></div>';
	})
	Promise.resolve(ajax('GET','./pages/resume.html')).then(function(val){
		getClass('data_container')[0].innerHTML = val;
		getId('resume-ed').innerHTML = container;
		getId('resume-ex').innerHTML = container_1;
		resume.openprofile();
		color(bg);
		function skew(){
			Object.values(getClass('education_detail')).forEach(function(v, i){v.classList.add('skew')});
			getClass('move')[0].style.opacity=1;
			getClass('intro_left')[0].removeEventListener('transitionend',skew);
		}
		getClass('intro_left')[0].addEventListener('transitionend',skew);
	});

}

function skills(data,bg){
	let resume = new Resume(bg);
	let container = '<h1>'+data.heading+'</h1>';
	Object.keys(data.content).forEach(function(val,key,arr){
		container += '<div class="skill_container"><h3>'+val+'</h3><canvas class= "canvas" id="canvas_'+key+'" height="150" width="150" data-max='+data.content[val]+'></canvas></div>';
	});
	Promise.resolve(ajax('GET','./pages/skills.html')).then(function(val){
		getClass('data_container')[0].innerHTML = val;
		getId('skills').innerHTML = container;
		resume.openprofile();
		getClass('move')[0].style.opacity=1;
		color(bg);
		resume.canvas(bg.backgroundStyle);
	});
}

function contact(data,bg){
	let container = ' <h1 class="textClr">CONTACT DETAILS</h1>';
	let resume = new Resume(bg);
	console.log(data)
	Object.values(data.content).forEach(function(val,key,arr){
		console.log(val.fontAwesome)
		container += '<p><i class="fa '+val.fontAwesome+' textClr"></i><br><span>'+val.content+'</span></p>'});
	Promise.resolve(ajax('GET','./pages/contact.html')).then(function(val){
		getClass('data_container')[0].innerHTML = val;
		getId('contact').innerHTML = container;
		resume.openprofile();
		getClass('move')[0].style.opacity=1;
		color(bg);
		getId('send').onclick = function(e){
			e.preventDefault();
			makeRequest({
				method: 'GET',
				url:'/data/mail',
				
			
			})
			.then(function (data) {
			console.log(data);
			})
			.catch(function (err) {
				console.log(err);
			});
		}
	});
		
	
}
var app = require('express')(),
    mailer = require('express-mailer');
 
 var mail = mailer.extend(app, {
  from: 'ganesh5632@gmail.com',
  host: 'smtp.gmail.com', // hostname 
  secureConnection: true, // use SSL 
  port: 465, // port for secure SMTP 
  transportMethod: 'SMTP', // default is SMTP. Accepts anything that nodemailer accepts 
  auth: {
    user: 'ganesh5632@gmail.com',
    pass: '75845632'
  }
});
module.exports = mail; 
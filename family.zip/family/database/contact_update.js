var mysql = require('mysql');
var myDB = require('./db');
var express = require('express');
var router = express.Router();
var app = express();
function contact_update(req, res) {
	console.log(req);
	var check_sql = "select * from contacts where name = ? and mobile = ?";
	 myDB.query(check_sql,[req.body.name,req.body.mobile], function(err, rows, fields){
		 if (err) throw err;
		 if(rows.length>0)
		 {
			  var sql = "update contacts SET ? where name = ? and mobile= ? ";  
			  var values = {name:req.body.name,
					    mobile:req.body.mobile,
						alternate_mobile:req.body.alternate_mobile,
						email:req.body.email,
						address:req.body.address
						}; 
			myDB.query(sql,[values,req.body.name,req.body.mobile], function(err, rows, fields)
				{	
					if (err) throw err;
					res.writeHead(200, { 'Content-Type': 'application/json'});
					res.end(JSON.stringify("updated successfully")); 
					res.end();
				});   
			 
			}
		 
		});
	
	 
		
		
};
module.exports = contact_update;
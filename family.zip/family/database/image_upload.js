var fs = require('fs');
const path = require('path');
var multer = require('multer');
var mysql = require('mysql');
var myDB = require('./db');
var Storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "./Images");
    },
    filename: function (req, file, callback) {
        callback(null, file.fieldname + "_" + Date.now() + "_" + file.originalname);
    }
});
var upload = multer({ storage: Storage }).array("imgUploader", 10);

var dir = '../public/images/eventImages';
// create folder if folder not available
if (!fs.existsSync(dir)){
    fs.mkdirSync(dir);
}
const fileSizeInBytes = fs.statSync('file.html').size;
function image_upload(req, res){
	
	upload(req, res, function (err) {
        if (err) {
            return res.end("Something went wrong!");
        }
        return res.end("File uploaded sucessfully!.");
    });
}
exports.image=function(req,res){
	
};
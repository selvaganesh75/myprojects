var mysql = require('mysql');
var myDB = require('./db');
var express = require('express');
var router = express.Router();
var app = express();
function getdata(req, res) {
	console.log(req);
    myDB.query('select * from contacts', function(err, rows, fields)
        {
                console.log('Connection result error '+err);
                console.log('no of records is '+rows.length);
                res.writeHead(200, { 'Content-Type': 'application/json'});
                res.end(JSON.stringify(rows));
                res.end();
        }); 
};
module.exports = getdata;
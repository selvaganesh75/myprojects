function getClass(ele){
	return document.getElementsByClassName(ele);
}
var color = function(data){
		Object.values(getClass('textClr')).forEach(function(v, i){
		getClass('textClr')[i].style.color=data.backgroundStyle.color});
		Object.keys(getClass('bgClr')).forEach(function(v, i){getClass('bgClr')[i].style.backgroundColor=data.backgroundStyle.backgroundColor})
		Object.keys(getClass('borderClr')).forEach(function(v, i){getClass('borderClr')[i].style.borderColor=data.backgroundStyle.color})
		document.styleSheets[1].addRule('.bgClr::before','border-color: '+data.backgroundStyle.backgroundColor,1);
		
		document.styleSheets[1].insertRule('.bgClr::before { border-color:'+data.backgroundStyle.backgroundColor+'}', 1);
		document.styleSheets[1].insertRule('.bgClr_h3::before{border-right-color:'+data.backgroundStyle.backgroundColor+'}', 1);
		document.styleSheets[1].insertRule('.overlay:hover .nav i{color:'+data.backgroundStyle.color+'!important}', 1);
		document.styleSheets[1].insertRule('.contact>button:hover, .contact>button:focus{background-color:'+data.backgroundStyle.backgroundColor+'!important;color:#fff!important}', 1);
		document.styleSheets[1].insertRule('.contact>[type=text]:hover, .contact>[type=text]:focus{box-shadow:0 0 3px 0'+data.backgroundStyle.color+'!important}', 1);
		
}
function profile(data,bg){
	let container = '';
	Object.keys(data[0]).forEach(function(val,key,arr){
		container += '<div class="left_ques"><h4 class="textClr">'+val+'</h4></div><div class="right_ques"><h4 class="textClr">'+data[0][val]+'</h4></div>';
	});
	getClass('data_container')[0].innerHTML = '<section class="profile screen"><div class="profile_left ovrly"><div class="profile_content"><h1><span class="myColor textClr">P</span>ROFILE</h1></div></div> 	<div class="profile_right scroll"><div class="profile_bio"> <h1 class="textClr">Bio - Data</h1><div class="bio"> <div class="bio_pic"><img src="/images/'+data[1].image+'" width="100%" height="50%"/> </div><div class="bio_data"><div class = "bio_ques">'+container+'  </div></div></div></div></div> </section>';
	color(bg);

}


function resume(data,bg){
	let container = '';
	let container_1 = '';
	console.log(data)
	Object.values(data.Education.content).forEach(function(val,key,arr){
		container += '<div class="education container borderClr"><div class="circleDraw bgClr"></div><div class="education_content"><div class="education_detail"><h3 class=bgClr bgClr_h3>'+val.heading+'</h3><p>'+val.content+'</p></div></div></div>';
	})
	Object.values(data.Experience.content).forEach(function(val,key,arr){
		container_1 += '<div class="education container"><div class="circleDraw borderClr"></div><div class="education_content"><div class="education_detail"><h3 class="textClr">'+val.heading+'</h3><p>'+val.content+'</p></div></div></div>';
	})
	getClass('data_container')[0].innerHTML = '<section class="resume screen overallContainer"><div class="left_container ovrly"> 		<div class="profile_content"><h1><span class="myColor textClr">P</span>ROFILE</h1> 	</div> </div> 	<div class="right_container scroll"><div class="resume_bio"><h1 class="textClr">'+data.Education.heading+'</h1>'+container+'</div><div class="resume_Experience bgClr"><h1>'+data.Experience.heading+'</h1>	'+container_1+'</div> </section>';
	color(bg);

}

function skills(data,bg){
	console.log('hi');
	let skill = new about(bg).canvas;
	console.log(skill);
	let container = '';
	
	Object.keys(data.content).forEach(function(val,key,arr){
		container += '<div class="skill_container"><h3>'+val+'</h3><canvas class= "canvas" id="canvas_'+key+'" height="150" width="150" data-max='+data.content[val]+'></canvas></div>';
	});
	getClass('data_container')[0].innerHTML = '<section class="profile screen skills"> <div class="left_container ovrly"><div class="profile_content"><h1><span class="myColor textClr">S</span>KILLS</h1> 	</div> </div> 	<div class="right_container scroll"> <div class="skill_bio"> <h1>'+data.heading+'</h1>'+container+'</div> </section>';
	color(bg);
	setTimeout(skill.bind(null,bg.backgroundStyle),100);
}

function contact(data,bg){
	let container = '';
	getClass('data_container')[0].innerHTML = '<section class="contact screen"> <div class="left_container ovrly"> <div class="profile_content"> <h1><span class="myColor textClr">C</span>ONTACT</h1> </div> </div> <div class="right_container scroll"> <div class="contact_bio"> <h1>Contact</h1> <div class="contact container"><input type="text" placeholder="Enter Your Name" class="borderClr"></input><input type="text" class="borderClr" placeholder="Enter Your Email"></input><textarea type="text" cols="5" rows=10 class="borderClr" placeholder="Enter Your Comment Here"></textarea><button class="textClr borderClr">Send</button></div> </div> <div id="map" style="width:100%;height:500px"></div> <script> function myMap() { var myCenter = new google.maps.LatLng(51.508742,-0.120850); var mapCanvas = document.getElementById("map"); var mapOptions = {center: myCenter, zoom: 5}; var map = new google.maps.Map(mapCanvas, mapOptions); var marker = new google.maps.Marker({position:myCenter}); marker.setMap(map); // Zoom to 9 when clicking on marker google.maps.event.addListener(marker,"click",function() { map.setZoom(9); map.setCenter(marker.getPosition()); }); } </script> <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBu-916DdpKAjTmJNIgngS6HL_kDIKU0aU&callback=myMap"></script> <div class="contact_bio contact_detail"> <h1>CONTACT DETAILS</h1> <p><i class="fa fa-map-marker textClr"></i><br><span>sivalvilaiputhur, udangudi.</span></p> <p><i class="fa fa-phone textClr"></i><br><span>9788546014</span></p> <p><i class="fa fa-envelope textClr"></i><br><span>ganesh5632@gmail.com</span></p> <p><i class="fa fa-globe textClr"></i><br><span>ganesh5632@gmail.com</span></p> </div> </div> </section>';
	color(bg);
}
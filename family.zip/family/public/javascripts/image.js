var canvas=function(imageList,bg){
        var ctx = document.getElementById("canvas").getContext("2d"),myReq
            images = [],
			textSize=40,
			canvasText="Choose Any Circle";
			ctx.font=textSize+"px Florence";
		    var count = imageList.length;
			ctx.canvas.width = window.innerWidth || document.documentElement.offsetWidth;
			ctx.canvas.height = window.innerHeight || document.documentElement.offsetHeight;
	
        var imgObj = function(imageArray, src) {
            this.radius = Math.floor(Math.random() * 30) + 30;
            this.x = Math.ceil(Math.random() * (ctx.canvas.width - this.radius * 2)) + this.radius;
            this.y = Math.ceil(Math.random() * (ctx.canvas.height - this.radius * 2)) + this.radius;
            this.color = "rgba(" + Math.floor(Math.random() * 255) + "," + Math.floor(Math.random() * 255) + "," + Math.floor(Math.random() * 255) + ",1)";
            this.dx = Math.floor(Math.random() * 1) + 1;
            this.dy = Math.floor(Math.random() * 1) + 1;
            this.img = function(imageArray, src) {
                var tempName = new Image();
                tempName.src = imageArray[src].image;
                return tempName;
            }
            this.url = function(imageArray, src) {
                return imageArray[src].imageUrl;
            }
        }

        for (var i = 0; i < imageList.length; i++) {
            images[i] = new imgObj();
            images[i].getImage = images[i].img(imageList, i);
            images[i].getImage.onload = imageLoaded;
        }

        function imageLoaded() {
            count--;
            if (count === 0) {
                window.RAF(imageLoad);
            }

        }

        console.log(images);
        var bg = new imgObj().img(bg, 0);
        var inc = 0;

        function imageLoad() {
            ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
            ctx.drawImage(bg, 0, 0, ctx.canvas.width, ctx.canvas.height);
            for (var i = 0; i < images.length; i++) {
                var n = images[i];
                ctx.save();
                ctx.beginPath();
                ctx.strokeStyle = n.color;
                ctx.shadowBlur = "10";
                ctx.shadowColor = n.color;
                ctx.lineWidth = "5";
                ctx.arc(n.x, n.y, n.radius, 0, 2 * Math.PI);
                ctx.stroke();
                ctx.closePath();
                ctx.clip();
			
                if (n.x <= n.radius || n.x + n.radius >= ctx.canvas.width ) {
                    n.dx = -n.dx
                };
                if (n.y <= n.radius || n.y + n.radius >= ctx.canvas.height ||  (n.x + n.radius>(ctx.canvas.width/2-ctx.measureText(canvasText).width/2) && (n.x + n.radius < ctx.canvas.width/2+ctx.measureText(canvasText).width/2))&&(n.y + n.radius>(ctx.canvas.height/2-textSize/2) && (n.y-n.radius < (ctx.canvas.height/2)))) {
                    n.dy = -n.dy
                };
				
                n.x += n.dx;
                n.y += n.dy;
                ctx.beginPath();
                ctx.translate(n.x, n.y);

                ctx.rotate(inc * Math.PI / 180);

                inc += .2;
                ctx.translate(-n.x, -n.y);
                ctx.drawImage(n.getImage, n.x - n.radius, n.y - n.radius, n.radius * 2, n.radius * 2);
                ctx.closePath();
                ctx.restore();
            }
			
			ctx.font=textSize+"px Florence";
			ctx.fillStyle="#fff";
			ctx.textAlign="center";
			ctx.fillText(canvasText,ctx.canvas.width/2,ctx.canvas.height/2);
			
           myReq = window.RAF(imageLoad);

        }
        ctx.canvas.addEventListener("click", imageCheck);
       ctx.canvas.addEventListener("mousemove", imageCheck); 

        function imageCheck(e) {
            var mouseX = e.pageX - ctx.canvas.getBoundingClientRect().left;
            var mouseY = e.pageY - ctx.canvas.getBoundingClientRect().top;
            for (var i = 0; i < images.length; i++) {
                var check = images[i];
                var dx = mouseX - check.x,
                    dy = mouseY - check.y,
                    dist = Math.sqrt(dx * dx + dy * dy);
                if (dist <= check.radius && e.type == "click") {
                    initialRequest(check.url(imageList, i).toLowerCase());
					
                }
				if(dist <= check.radius && e.type == "mousemove"){
					ctx.canvas.style.cursor="pointer";
				}
				else if(dist > check.radius && e.type == "mousemove"){
					ctx.canvas.style.cursor="auto";
				}
            }

        }
		window.onresize = function() {
			ctx.canvas.width = window.innerWidth || document.documentElement.offsetWidth;
			ctx.canvas.height = window.innerHeight || document.documentElement.offsetHeight;
			for (var i = 0; i < imageList.length; i++) {
				images[i] = new imgObj();
				images[i].getImage = images[i].img(imageList, i);
				images[i].getImage.onload = imageLoaded;
			}
			
		}
    }


    

    var imageScroll = function(imageFromDB) {
        var scrollCount = 0,
            classCount = 0,
            scrollTime, rolled, screen_top = 0;
        var imgList, imgList_Left, imgList_right, imgLeft, imgRight_top, imgRight_bottom;
        if (window.addEventListener) { // all browsers except IE before version 9
            // Internet Explorer, Opera, Google Chrome and Safari
            window.addEventListener("mousewheel", MouseScroll, false);
            // Firefox
            window.addEventListener("DOMMouseScroll", MouseScroll, false);
        } else {
            if (window.attachEvent) { // IE before version 9
                window.attachEvent("onmousewheel", MouseScroll);
            }
        }

        function MouseScroll(e) {
            clearTimeout(scrollTime);
            if ('wheelDelta' in e) {
                rolled = e.wheelDelta;
            } else { // Firefox
                // The measurement units of the detail and wheelDelta properties are different.
                rolled = -40 * e.detail;
            }
            scrollTime = setTimeout(function() {
                if (rolled < 0 && scrollCount < imgList.length - 1) {
                    var inc = scrollCount;
                    scrollCount += 1;
                    changeImage(inc, true);
                } else if (rolled > 0 && scrollCount > 0) {
                    var dec = scrollCount;
                    scrollCount -= 1;
                    changeImage(dec, false);
                } else {

                }
            }, 400);

        }

        function addRemoveClass(firstClass, second, third, fourth, scrollChange) {
            imgList[scrollCount].style.visibility = "visible";
            imgList[scrollChange].style.visibility = "visible";
            imgList_Left[scrollChange].classList.add(firstClass);
            imgList_Left[scrollCount].classList.add(second);
            imgList_right[scrollChange].classList.add(third);
            imgList_right[scrollCount].classList.add(fourth);
            imgList[scrollCount].style.zIndex = "100";

        }

        function changeImage(scrollChange, upDown) {

            for (var i = 0; i < imgList.length; i++) {
                imgList[i].style.visibility = "hidden";
                imgList_Left[i].classList.remove("animate_left_backward", "animate_left_forward", "animate_right_backward", "animate_right_forward");
                imgList_right[i].classList.remove("animate_left_backward", "animate_left_forward", "animate_right_backward", "animate_right_forward");
                imgList[i].style.zIndex = "0";
            }

            if (upDown) {
                addRemoveClass("animate_left_backward", "animate_left_forward", "animate_right_backward", "animate_right_forward", scrollChange);
            } else {
                addRemoveClass("animate_right_backward", "animate_right_forward", "animate_left_backward", "animate_left_forward", scrollChange);
            }
        }

        function Getpos(imgPos, change, e) {
            this.bounding = imgPos[change].getBoundingClientRect();
            this.XPosition = function() {
                return e.clientX - this.bounding.left
            };
            this.YPosition = function() {
                return e.clientY - this.bounding.top
            };
            this.width = imgPos[change].offsetWidth;
            this.height = imgPos[change].offsetHeight;
            this.calculateTranslate = this.XPosition() / (this.width / 100) + "% " + this.YPosition() / (this.height / 100) + "%";
        }
        document.getElementsByClassName("main")[0].style.display = "block";
		document.getElementsByClassName("main")[0].innerHTML = '';
        for (var i = 0; i < imageFromDB.length; i += 3) {
			if(i<imageFromDB.length-2){document.getElementsByClassName("main")[0].innerHTML += "<section class='subsection'> <div class='left_container'> <div class='left' style='background-image:url(" + imageFromDB[i].image + ")' ><div class='overlay'></div> </div> </div> <div class='right'> <div class='right_top_image' style='background-image:url(" + imageFromDB[i + 1].image + ")' > <div class='overlay'></div> </div> <div class='right_bottom_image' style='background-image:url(" + imageFromDB[i + 2].image + ")'> <div class='overlay'></div> </div> </div></section><div class=closeOverlay>X</div> ";}
			else if(i<imageFromDB.length-1){document.getElementsByClassName("main")[0].innerHTML += "<section class='subsection'> <div class='left_container'> <div class='left' style='background-image:url(" + imageFromDB[i].image + ")' ><div class='overlay'></div> </div> </div> <div class='right'> <div class='left' style='background-image:url(" + imageFromDB[i + 1].image + ")' > <div class='overlay'></div> </div></div> </section><div class=closeOverlay>X</div>";}
		}
		
		imgList = document.getElementsByClassName("subsection");
		console.log(imgList);
		if(imgList!="undefined"){
			
			imgList_Left = document.getElementsByClassName("left_container");
			imgList_right = document.getElementsByClassName("right");
			imgLeft = document.getElementsByClassName("left");
			imgRight_top = document.getElementsByClassName("right_top_image");
			imgRight_bottom = document.getElementsByClassName("right_bottom_image");
        for (var i = 0; i < imgList.length; i++) {
            (function(change) {
                    imgLeft[change].onmousemove = function(e) {
                        var pos = new Getpos(imgLeft, change, e);
                        imgLeft[change].style.backgroundPosition = pos.calculateTranslate;
                    }
                    imgRight_top[change].onmousemove = function(e) {
                        var pos = new Getpos(imgRight_top, change, e);
                        imgRight_top[change].style.backgroundPosition = pos.calculateTranslate;
                    }
                    imgRight_top[change].onclick = function(e) {
                        imgRight_top[change].classList.toggle("fullImage");
                    }
                    imgRight_bottom[change].onmousemove = function(e) {
                        var pos = new Getpos(imgRight_bottom, change, e);
                        imgRight_bottom[change].style.backgroundPosition = pos.calculateTranslate;
                    }
                    imgRight_bottom[change].onclick = function(e) {
                        imgRight_bottom[change].classList.toggle("fullImage");
                    }
                }

            )(i);
        }
		document.getElementsByClassName('closeOverlay')[0].onclick = function(){
			document.getElementsByClassName("main")[0].style.display = "none";
		}
        imgList[0].style.visibility = "visible";
		var DBimageLength;
		if(imageFromDB.length>10){DBimageLength = 10}else{DBimageLength = imageFromDB.length}
		for (var i = 0; i < imageFromDB.length; i++) {
            let img = new Image();
            img.src = imageFromDB[i].image;
            img.onload = isimageLoaded;
        }

        function isimageLoaded() {
            DBimageLength--;
            if (DBimageLength === 0) {
               document.getElementsByClassName("preLoader")[0].style.display = "none";
            }

        }
    }
}

 	function initialRequest(getID){
		makeRequest({
				method: 'POST',
				url:'/images/getuser',
				headers:{
					'Cache-Control': 'no-cache, must-revalidate',
					"Content-Type": "application/x-www-form-urlencoded"
				},
				params:{
					id:getID
				}
			
			})
	.then(function (data) {
		
		var imageList = JSON.parse(data);
        console.log(imageList);
        document.getElementsByClassName("preLoader")[0].style.display = "block";
        new imageScroll(imageList);
	})
	.catch(function (err) {
		console.log(err);
	});
}
	window.RAF = function(){
    return (
        window.requestAnimationFrame       || 
        window.webkitRequestAnimationFrame || 
        window.mozRequestAnimationFrame    || 
        window.oRequestAnimationFrame      || 
        window.msRequestAnimationFrame     || 
        function(/* function */ callback){
            window.setTimeout(callback, 1000 / 60);
        }
    );
}();
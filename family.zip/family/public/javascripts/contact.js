var list;
var edit;
var createContact=document.getElementsByClassName("createContact")[0];
var contact=document.getElementsByClassName("contact")[0];
var chooseContact=id("chooseContact");
function id(getId){
  return document.getElementById(getId);
}
function init(){

id("text").addEventListener("keyup",searchValidator);
id("text").addEventListener("click",contactShow);
var contactSelector=id("contactSelector");

var contactList=id("contactList");
var contactSearch=id("contactSearch");
var incre=0;
var text;
var parseInt_check=""||0;
var lis = Array.prototype.slice.call(document.getElementById("chooseContact").getElementsByTagName("li"));
for (var i = 0, len = chooseContact.children.length; i < len; i++)
{

chooseContact.children[i].addEventListener("click",contactShow);

}

	contactSelector.onclick=function(e){
	clearTimeout(animateContact);
	for(var i=0; i<chooseContact.childElementCount;i++){
		if(chooseContact.children[i].innerHTML.charAt(0)==e.target.innerHTML){
		text = e.target.innerHTML;
			contactList.scrollTop=contactList.scrollTop-(contactList.scrollTop%10);
			animateContact(contactList.scrollTop,chooseContact.children[i].offsetTop);
			clearTimeout(animateContact);
			lis.forEach(addColor);
			break;
			}
	}


}
	function addColor(value,index){
		if(value.innerHTML.charAt(0).toUpperCase()==text.toUpperCase() || value.innerHTML.toUpperCase()==text.toUpperCase())
		chooseContact.children[index].style.color="red";
		else chooseContact.children[index].style.color="black";
	}
	function animateContact(top,position){
		clearTimeout(animateContact);
		if(top!=position &&contactList.scrollTop<contactList.scrollHeight-contactList.offsetHeight){
			
			if(top<(position-(position%10))){
			contactList.scrollTop+=5;
			console.log(position-(position%10))
			
			}
			else if(top>(position-(position%10))){
			contactList.scrollTop-=5;  
			}
			else{
				clearTimeout(animateContact);
				return false;
			}
			setTimeout('animateContact('+contactList.scrollTop+','+position+')',10);
			
		}
		else{
		clearTimeout(animateContact);
		return false;
		}
	}
	
	
	function contactShow(e){
		contactSearch.innerHTML="";
		text="";
		id("text").value="";
		var clickEnable = e || window.event;
		var str = clickEnable.target.innerHTML.replace(/<\/?span[^>]*>/g,"");
		text = clickEnable.target.innerHTML;

 		lis.forEach(addColor);
			for(var listdetails in list){
				console.log(list[listdetails])
				if(list[listdetails].name.toUpperCase()==str.toUpperCase()){
				edit=list[listdetails];
				id("contactView").innerHTML="<h2>Name: "+edit.name.toUpperCase()+"</h2><h2>"+edit.mobile+"</h2><h2>"+edit.address+"</h2><h2>"+edit.email+"</h2><h4>if want to update or delete please click <i class='fa fa-pencil-square-o'></i> or <i class='fa fa-trash-o'></i> bottom of page</h4>";
				
			}
		}
	
	}
	function searchValidator(){
		id("contactSearch").innerHTML="";
		var value=id("text").value;
		for(var k=0;k<chooseContact.childElementCount;k++){
			if(chooseContact.children[k].innerHTML.toUpperCase().search(value.toUpperCase())>=0 && value!=""){
				var name=chooseContact.children[k].innerHTML;
			    var regEx =	new RegExp(value, "ig");
				id("contactSearch").innerHTML+='<h4>'+name.toUpperCase().replace(regEx,"<span class=checkList>"+value.toUpperCase()+"</span>")+"</h4>";
				
			  }
			  document.querySelectorAll("#contactSearch h4").forEach(function(values,index){
				  document.querySelectorAll("#contactSearch h4")[index].addEventListener("click",contactShow);
			  });
				  
       };
	}
	
	contactSubmit.onsubmit = function(e){
		e.preventDefault();
		if(validate(this)){
			requestServer("/contacts/contact_insert");
			id("submit").style.display="block";
		}
	};
	function requestServer(Request){
		 makeRequest({
			method: 'POST',
			url: Request,
			params: {
				name:document.getElementsByName("name")[0].value,
				mobile:document.getElementsByName("mobile")[0].value,
				alternate_mobile:document.getElementsByName("alternate_mobile")[0].value,
				email:document.getElementsByName("email")[0].value,
				address:document.getElementsByName("address")[0].value
			},
			headers: {
				'Cache-Control': 'no-cache, must-revalidate',
				'Content-type': 'application/x-www-form-urlencoded'
			}
		}).then(function(result){
			document.getElementById("contactSubmit").reset();
			id("output").style.display="block";
			console.log(result);
			id("output").innerHTML=result;
			setTimeout(function(){id("output").style.display="none"},2000); 
		}).catch(function (err) {
		alert('Augh, there was an error!', err.statusText);
		console.log('Augh, there was an error!', err);
	});
		
	}
	var addContact=document.getElementsByClassName("addContact")[0];
	var addContact_i=document.querySelectorAll(".addContact>i")[0];
	addContact.onclick=function(){
		hide();
		id("submit").style.display="block";
		id("form_head").innerHTML="add Contact";
		id("menuClose").style.display="block";
		if(edit!=null){
		var sliced = Array.prototype.slice.call(Object.values(edit));
		sliced.forEach(function(values,index){
					document.querySelectorAll("[data-update=update]")[index].value="";
					document.querySelectorAll("[data-update=update]")[index].readOnly = false;
				});
		}
	}
	id("menuShow").addEventListener("click",function(){
		id("menuShowIcon").classList.toggle("fa-folder-open-o");
		document.getElementsByClassName("menuContainer")[0].classList.toggle("hideMenu");
	});
	id("menuClose").addEventListener("click",function(){
		id("menuClose").style.display="none";
		contact.classList.toggle("hide");
		createContact.classList.toggle("hide");
		id("search").classList.toggle("hide_search");
		location.reload();
		});
		
	id("modifyContact").addEventListener("click",function(){
		hide();
		id("form_head").innerHTML="update Contact";
		id("menuClose").style.display="block";
		if(edit!=null){
			
			var sliced = Array.prototype.slice.call(Object.values(edit));
			console.log(sliced);
			sliced.forEach(function(values,index){
					document.querySelectorAll("[data-update=update]")[index].value=values;
					document.querySelectorAll("[data-update=update]")[index].readOnly = false;
				});
			id("update").style.display="block";
		}
		if(id("update").style.display=="none"){id("output").innerHTML="Please Choose Any One Of Contact from main menu";
		}
	})
	id("deleteContact").addEventListener("click",function(){
		hide();
		id("form_head").innerHTML="Delete Contact";
		id("menuClose").style.display="block";
		
		if(edit!=null){
			var sliced = Array.prototype.slice.call(Object.values(edit));
			sliced.forEach(function(values,index){
				document.querySelectorAll("[data-update=update]")[index].value=values;
				document.querySelectorAll("[data-update=update]")[index].readOnly = true;
			});
			id("delete").style.display="block";
		}
		if(id("delete").style.display=="none"){id("output").innerHTML="Please Choose Any One Of Contact from main menu";
		}
	})
	function hide(){
		id("submit").style.display="none";
		id("update").style.display="none";
		id("delete").style.display="none";
		id("search").classList.add("hide_search");
		createContact.classList.remove("hide");
		contact.classList.add("hide");
		id("output").innerHTML="";
	}
	id("delete").addEventListener("click",function(){
		if(validate(document.contact)){
			requestServer("/contacts/contact_delete");
		}
	});
	id("update").addEventListener("click",function(){
		if(validate(document.contact)){
			requestServer("/contacts/contact_update");
		}
	});
	
	document.onclick=function(e){
		if(e.target.id!="text"){
			contactSearch.innerHTML="";
			id("text").value="";
		}
	}
	
	}
function initialRequest(){
	makeRequest({
			method: 'GET',
			url:'/contacts/getdata',
			headers:{
				"X-Test-Header": "test-value"
			}
		
		})
	.then(function (data) {
		list=JSON.parse(data);
		for(let i=0;i<list.length;i++){
			chooseContact.innerHTML+="<li>"+list[i].name+"</li>";
		}
		init();
	})
	.catch(function (err) {
		console.log(err);
		id("PageNtfnd").style.display="block";
	});
}
initialRequest();
var event = function() {
    var classLists = ["ourEvents_text", "text_animate", 'event_subtext'];
    var aChildren = ["our_events", "mainText", 'event_subtext'];
    var navClass = document.getElementsByClassName('navigation');

    window.onscroll = function() {

        var windowPos = window.pageYOffset || document.documentElement.scrollTop; // get the offset of the window from the top of page
        var windowHeight = window.innerHeight;
        var middle = (windowPos + windowHeight) / 2.5;

        // get the height of the window
        (windowPos > 100) ? navClass[0].classList.add('newNav'): navClass[0].classList.remove('newNav');
        for (var i = 0; i < aChildren.length; i++) {
            var theID = aChildren[i];
            var currentId = document.getElementById(theID);
            var currentPos = currentId.getBoundingClientRect();

            var divPos = currentPos.top; // get the offset of the div from the top of page
            var getClass = currentId.className;
            var res = getClass.indexOf(classLists[i]) > -1;
            if (middle > divPos && !res && divPos > 0) {
                currentId.classList.add(classLists[i]);

            } else if (res && divPos >= middle + (windowHeight) / 2) {
                currentId.classList.remove(classLists[i]);
            } else if (res && divPos < 0) {
                currentId.classList.remove(classLists[i]);
            }
        }

    }


    document.getElementById("addEvent").onclick = function() {
        document.getElementsByClassName('newEvent')[0].style.transform = 'scale(1)';
    };
};

document.getElementsByName('btnSubmit')[0].addEventListener('click', uploadFiles);
document.getElementById('close').addEventListener('click', hide_Addevent);

document.addEventListener('click', document_click);

function hide_Addevent() {
    document.getElementsByClassName('newEvent')[0].style.transform = 'scale(0)';
    document.formUploadFile.reset();
}

function document_click(e) {
    if (e.target.id == "newEvent") {
        hide_Addevent();
    }
}

function uploadFiles(e) {
    e.preventDefault();
    if (validate(document.formUploadFile)) {
        alert();
    }
}
var menuIcon = function(x) {
    x.classList.toggle("change");
    document.getElementsByClassName("mobile_menu")[0].classList.toggle("menu");


}
var scroll_width = [];
var offset_width = [];
var scrollable = document.getElementsByClassName('scrollable');
var Imgcontainer = document.getElementsByClassName('imageContainer');
for (let i = 0; i < Imgcontainer.length; i++) {
    scroll_width[i] = Imgcontainer[i].scrollWidth;
    offset_width[i] = Imgcontainer[i].offsetWidth;
    scrollable[i].style.left = '0px';
    Imgcontainer[i].addEventListener('mouseover', function() {
        let k = 'm' + (i + 1);
        window[k].hover = true;
        console.log(k)
    })
    Imgcontainer[i].addEventListener('mouseout', function() {
        let k = 'm' + (i + 1);
        window[k].hover = false;
    })
}
var hover = false;

function MovingItems(index, inc) {
    var _this = this;
    this.hover = false;
    this.index = index;
    this.inc = inc;
    this.ckwidth = scroll_width[this.index] - offset_width[this.index];
    this.move = function() {
        if (!this.hover && this.ckwidth > 50) {
            scrollable[this.index].style.left = parseInt(scrollable[this.index].style.left) - this.inc + 'px';
            scrollable[this.index].style.transition = 'all .1s';

        }
        if (this.ckwidth < Math.abs(parseInt(scrollable[this.index].style.left))) {
            this.hover = true;
            this.index = index;
            setTimeout(function() {
                _this.hover = false;
                scrollable[_this.index].style.transition = 'all .5s';
                scrollable[_this.index].style.left = '0px';
            }, 1000)
        }
    }

}
window.onresize = function() {
    setTimeout(function() {
        for (let i = 0; i < Imgcontainer.length; i++) {
            scroll_width[i] = Imgcontainer[i].scrollWidth;
            offset_width[i] = Imgcontainer[i].offsetWidth;
            let k = 'm' + (i + 1);
            window[k].ckwidth = scroll_width[i] - offset_width[i];
        }
    }, 60);

}
var m1 = new MovingItems(0, 2);
var m2 = new MovingItems(1, -2);

function movingAllItems() {
    m1.move();
    m2.move();
}

var pauseInterval = setInterval(movingAllItems, 60);
var ck_name = /^[A-Za-z0-9 ]{3,20}$/;
var ck_email = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
var ck_mobile = /^\d{10}$/;
var ck_dateReg = /^\d{4}([./-])\d{2}\1\d{2}$/;
var ck_file = ['jpg','jpeg','png','gif'];

function validate(form){
	console.log(form.formUploadFile);
	var name,email,phone,date,files;
	if(arguments[0] === undefined) {alert('value is empty');return false;}
	this.check = function(name){
		if(({}).hasOwnProperty.call(form, name)) return true ;
		return false;
	}
console.log(typeof date)
var errors = [];
 if(this.check('name')){
	 name = form.name.value ;
	 if (!ck_name.test(name)) {
		errors[errors.length] = "Provide valid Name.";
	}
 }
  if(this.check('email')){
	  email = form.email.value;
		if (!ck_email.test(email)) {
			errors[errors.length] = "You must enter a valid email address.";
		}
  }
   if(this.check('mobile')){
	  phone=form.mobile.value; 
		if (!ck_mobile.test(phone)) {
			errors[errors.length] = "You must enter a valid Phone Number.";
		}
   }
  if(this.check('date')){
		date=form.date.value;
		if(!date.match(ck_dateReg)){
			errors[errors.length] = "You must select a proper date.";
		}
	}
  if(this.check('files')){
		files = form.files.files;
		for (var i = 0; i < files.length; i++) {
			let type = files[i].type.split('/')[1];
			if(ck_file.indexOf(type)==-1){
				errors[errors.length] = "You must select a proper Image like jpg,png. Error at Filename: " + files[i].name;
			}
  		}
		if(files.length<1){errors[errors.length] = "You must select a Image to upload";}
	}
  if (errors.length > 0) {
	reportErrors(errors);
		return false;
 }
  return true;
}
function reportErrors(errors){
 var msg = "Please Enter Valide Data...\n";
 for (var i = 0; i<errors.length; i++) {
 var numError = i + 1;
  msg += "\n" + numError + ". " + errors[i];
}
 alert(msg);
}
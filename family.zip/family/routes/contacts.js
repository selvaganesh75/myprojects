var express = require('express');
var router = express.Router();
var mysql = require('mysql');

var myDB = require('../database/db');
var app = express();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.render('contact', { title: 'Contacts' });
});
router.get('/getdata', function(req, res, next) {
    myDB.query('select * from contacts', function(err, rows, fields)
        {
                console.log('Connection result error '+err);
                console.log('no of records is '+rows.length);
                res.writeHead(200, { 'Content-Type': 'application/json'});
                res.end(JSON.stringify(rows));
                res.end();
        }); 

});
router.post('/contact_insert', function(req, res, next) {
   var check_sql = "select * from contacts where name = ? OR mobile = ?";
	 myDB.query(check_sql,[req.body.name,req.body.mobile], function(err, rows, fields){
		 if (err) throw err;
		 if(!rows.length>0)
		 {
			  var sql = "INSERT INTO contacts SET ? ";  
			  var values = {name:req.body.name,
					    mobile:req.body.mobile,
						alternate_mobile:req.body.alternate_mobile,
						email:req.body.email,
						address:req.body.address
						}; 
			myDB.query(sql,[values], function(err, rows, fields)
				{	
					if (err) throw err;
					res.writeHead(200, { 'Content-Type': 'application/json'});
					res.end(JSON.stringify("Inserted successfully")); 
					res.end();
				});   
			 
			}
			else{
				res.end(JSON.stringify("Mobile number or Name Already in Database")); 
			}
		 
		});

});
router.post('/contact_update', function(req, res, next) {
  var check_sql = "select * from contacts where name = ? and mobile = ?";
	 myDB.query(check_sql,[req.body.name,req.body.mobile], function(err, rows, fields){
		 if (err) throw err;
		 if(rows.length>0)
		 {
			  var sql = "update contacts SET ? where name = ? and mobile= ? ";  
			  var values = {name:req.body.name,
					    mobile:req.body.mobile,
						alternate_mobile:req.body.alternate_mobile,
						email:req.body.email,
						address:req.body.address
						}; 
			myDB.query(sql,[values,req.body.name,req.body.mobile], function(err, rows, fields)
				{	
					if (err) throw err;
					res.writeHead(200, { 'Content-Type': 'application/json'});
					res.end(JSON.stringify("updated successfully")); 
					res.end();
				});   
			 
			}
		 
		});

});
router.post('/contact_delete', function(req, res, next) {
 var check_sql = "select * from contacts where name = ? and mobile = ?";
	 myDB.query(check_sql,[req.body.name,req.body.mobile], function(err, rows, fields){
		 if (err) throw err;
		 if(rows.length>0)
		 {
			  var sql = "DELETE from  contacts  where name = ? and mobile= ? ";  
			  var values = {name:req.body.name,
					    mobile:req.body.mobile,
						alternate_mobile:req.body.alternate_mobile,
						email:req.body.email,
						address:req.body.address
						}; 
			myDB.query(sql,[req.body.name,req.body.mobile], function(err, rows, fields)
				{	
					if (err) throw err;
					res.writeHead(200, { 'Content-Type': 'application/json'});
					res.end(JSON.stringify("deleted successfully")); 
					res.end();
				});   
			 
			}
		 
		});

});
module.exports = router;

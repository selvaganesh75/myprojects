var express = require('express');
var router = express.Router();
var path = require('path');
const data = require('../public/resume/data.json')
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('about', { title: 'About' });
});
router.get('/data', function(req, res, next) {
	console.log(data)
	 res.setHeader('Content-Type', 'application/json');
	res.send(JSON.stringify(data));
	
});
module.exports = router;

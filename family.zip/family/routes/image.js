var express = require('express');
var router = express.Router();
var mysql = require('mysql');
var myDB = require('../database/db');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('image', { title: 'Images' });
});

router.post('/getuser', function(req, res, next) {
	var check_sql = "SELECT image FROM images WHERE type = ?";
	myDB.query(check_sql,[req.body.id], function(err, rows, fields)
       {
			 if (err) throw err; 
			res.writeHead(200, { "Content-Type": "application/x-www-form-urlencoded"});
            res.end(JSON.stringify(rows));
		});
});
module.exports = router;
